"""Encrypting a transfer file with a passphrase, the same way the phone does with WebCrypto.

Format: the line "FINPACK1", a JSON header line, then AES-256-GCM ciphertext.
The key comes from the passphrase through PBKDF2-SHA256 with a random salt;
the header (with the salt and nonce) is authenticated as associated data, so
it cannot be changed without the decryption failing. The `cryptography`
package is imported only when needed: the phone does not ship it.
"""

import base64
import json
import os
from dataclasses import dataclass, field

MAGIC = b"FINPACK1\n"
ITERATIONS = 600_000
SALT_BYTES = 16
NONCE_BYTES = 12


class SealError(ValueError):
    """Wrong passphrase, or a damaged or foreign file."""


def _key(passphrase: str, salt: bytes, iterations: int) -> bytes:
    from cryptography.hazmat.primitives import hashes  # noqa: PLC0415 - Mac only
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC  # noqa: PLC0415

    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations)
    return kdf.derive(passphrase.encode("utf-8"))


@dataclass(frozen=True)
class AccountKey:
    """A key derived once from the passphrase and the account's fixed salt (automatic sync).

    Files sealed with it carry that salt in their header, so `unseal` with the
    passphrase still opens them; only the nonce is new for every file.
    """

    key: bytes = field(repr=False)
    salt: bytes
    iterations: int


def derive_account_key(passphrase: str, salt: bytes, iterations: int = ITERATIONS) -> AccountKey:
    if not passphrase:
        raise SealError("a passphrase is required")
    if len(salt) != SALT_BYTES:
        raise SealError("the account salt has the wrong length")
    return AccountKey(_key(passphrase, salt, iterations), salt, iterations)


def _seal(plain: bytes, key: bytes, salt: bytes, iterations: int) -> bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: PLC0415

    nonce = os.urandom(NONCE_BYTES)
    header = json.dumps(
        {
            "cipher": "AES-256-GCM",
            "iterations": iterations,
            "kdf": "PBKDF2-SHA256",
            "nonce": base64.b64encode(nonce).decode(),
            "salt": base64.b64encode(salt).decode(),
        },
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return MAGIC + header + b"\n" + AESGCM(key).encrypt(nonce, plain, header)


def seal(plain: bytes, passphrase: str, iterations: int = ITERATIONS) -> bytes:
    """Encrypt the plain pack. A new random salt and nonce every time."""
    if not passphrase:
        raise SealError("a passphrase is required")
    salt = os.urandom(SALT_BYTES)
    return _seal(plain, _key(passphrase, salt, iterations), salt, iterations)


def seal_with(plain: bytes, account: AccountKey) -> bytes:
    """Encrypt with an account key: its salt, a new random nonce."""
    return _seal(plain, account.key, account.salt, account.iterations)


def _parse(blob: bytes) -> tuple[bytes, bytes, bytes, int, bytes]:
    """Header bytes, salt, nonce, iterations and ciphertext of a sealed file."""
    if not blob.startswith(MAGIC):
        raise SealError("this is not a transfer file from this app")
    header, sep, sealed = blob[len(MAGIC) :].partition(b"\n")
    try:
        fields = json.loads(header)
        salt = base64.b64decode(fields["salt"])
        nonce = base64.b64decode(fields["nonce"])
        iterations = int(fields["iterations"])
        valid = (
            sep
            and fields.get("kdf") == "PBKDF2-SHA256"
            and fields.get("cipher") == "AES-256-GCM"
            and 100_000 <= iterations <= 5_000_000
            and len(salt) == SALT_BYTES
            and len(nonce) == NONCE_BYTES
        )
    except (ValueError, KeyError, TypeError) as exc:
        raise SealError("this is not a transfer file from this app") from exc
    if not valid:
        raise SealError("this is not a transfer file from this app")
    return header, salt, nonce, iterations, sealed


def _open(key: bytes, nonce: bytes, sealed: bytes, header: bytes) -> bytes:
    from cryptography.exceptions import InvalidTag  # noqa: PLC0415
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: PLC0415

    try:
        return AESGCM(key).decrypt(nonce, sealed, header)
    except InvalidTag as exc:
        raise SealError("wrong passphrase, or the file is damaged") from exc


def unseal(blob: bytes, passphrase: str) -> bytes:
    """Decrypt a transfer file. Raises SealError on a wrong passphrase or a damaged file."""
    header, salt, nonce, iterations, sealed = _parse(blob)
    return _open(_key(passphrase, salt, iterations), nonce, sealed, header)


def unseal_with(blob: bytes, account: AccountKey) -> bytes:
    """Decrypt a file sealed with this account key (same salt and iteration count)."""
    header, salt, nonce, iterations, sealed = _parse(blob)
    if salt != account.salt or iterations != account.iterations:
        raise SealError("wrong passphrase, or the file is damaged")
    return _open(account.key, nonce, sealed, header)
