"""Sealing log entries and snapshots with the account's data key.

An entry is JSON, compressed (zlib, which browsers read as 'deflate'), then
encrypted with AES-256-GCM under the data key with a new random nonce. The
relay stores base64(nonce + ciphertext) and nothing else of the content. The
associated data says what the blob is, so an entry cannot pose as a snapshot.
`fin/web/account.js` does the same with WebCrypto.
"""

import base64
import json
import os
import zlib
from typing import Any

from fin.sync.crypto import SealError

ENTRY = b"fin log v1"
SNAPSHOT = b"fin snapshot v1"
NONCE_BYTES = 12
MAX_PLAIN_BYTES = 200 * 1024 * 1024


def seal_json(value: Any, dek: bytes, kind: bytes = ENTRY) -> str:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: PLC0415

    plain = zlib.compress(json.dumps(value, ensure_ascii=False).encode("utf-8"), 6)
    nonce = os.urandom(NONCE_BYTES)
    return base64.b64encode(nonce + AESGCM(dek).encrypt(nonce, plain, kind)).decode("ascii")


def open_json(blob: str, dek: bytes, kind: bytes = ENTRY) -> Any:
    from cryptography.exceptions import InvalidTag  # noqa: PLC0415
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: PLC0415

    try:
        raw = base64.b64decode(blob, validate=True)
    except ValueError as exc:
        raise SealError("a damaged entry") from exc
    if len(raw) <= NONCE_BYTES + 16:
        raise SealError("a damaged entry")
    try:
        packed = AESGCM(dek).decrypt(raw[:NONCE_BYTES], raw[NONCE_BYTES:], kind)
    except InvalidTag as exc:
        raise SealError("an entry this key cannot open (another account, or damaged)") from exc
    decompressor = zlib.decompressobj()
    plain = decompressor.decompress(packed, MAX_PLAIN_BYTES)
    if decompressor.unconsumed_tail:
        raise SealError("an entry too large to open")
    return json.loads(plain)
