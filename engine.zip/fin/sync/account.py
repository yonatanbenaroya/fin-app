"""The encrypted account as the home of the data: one password, one shared log.

Signing in derives two keys from the password (fin.sync.vault): the relay sees
only the auth secret; the wrapping key opens the vault record, which holds the
data key. Every log entry and snapshot is sealed with the data key before it
leaves this device. A round pulls what other devices added, applies it, and
pushes what this device made. On the Mac the refresh token, the data key and
the email live in the Keychain; the password itself is never stored.
"""

import json
import threading
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fin.logic import password_problem
from fin.storage import (
    Settings,
    import_settings,
    log_apply,
    log_full_state,
    log_mark_pushed,
    log_outgoing,
    log_position,
)
from fin.sync.crypto import SealError
from fin.sync.entries import SNAPSHOT, open_json, seal_json
from fin.sync.keychain import Secrets
from fin.sync.relay import AuthError, Relay, RelayError, Session
from fin.sync.vault import (
    ITERATIONS,
    create_vault,
    login_keys,
    open_vault,
    replace_recovery,
    wrap_vault,
)

REFRESH_TOKEN = ("fin-account", "refresh-token")
DATA_KEY = ("fin-account", "data-key")
EMAIL = ("fin-account", "email")
SNAPSHOT_FILE = "snapshot.bin"
SNAPSHOT_EVERY = 50  # entries between snapshots, so a new device starts quickly
PULL_PAGE = 100
STATE_FILE = "account-state.json"


class AccountError(ValueError):
    """The account cannot do this (not set up yet, already set up, weak password...)."""


@dataclass(frozen=True)
class SyncResult:
    changes: int  # settings changes taken in
    transactions: int  # new transactions taken in
    sent: bool
    at: str


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def check_password(password: str) -> None:
    problem = password_problem(password)
    if problem is not None:
        raise AccountError(f"the password is too weak ({problem}): use 16+ characters or 4+ words")


class Account:
    """One device's connection to the account. Rounds never run in parallel."""

    def __init__(
        self,
        settings: Settings,
        secrets: Secrets,
        relay: Relay | None = None,
        iterations: int = ITERATIONS,
        writes_snapshots: bool = True,
    ) -> None:
        if not settings.sync_url or not settings.sync_anon_key:
            raise RelayError("sync is not set up: add a sync section to settings.yaml")
        self.settings = settings
        self.secrets = secrets
        self.relay = relay or Relay(settings.sync_url, settings.sync_anon_key)
        self.iterations = iterations
        self.writes_snapshots = writes_snapshots
        self._session: Session | None = None
        self._lock = threading.Lock()  # the session
        self._round = threading.Lock()  # one round at a time

    # ---- state kept on this device (no secrets: positions, times and counts)

    @property
    def _state_path(self) -> Path:
        return self.settings.db_path.parent / STATE_FILE

    def state(self) -> dict[str, Any]:
        try:
            found = json.loads(self._state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return found if isinstance(found, dict) else {}

    def _save_state(self, state: dict[str, Any]) -> None:
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        temp = self._state_path.with_suffix(".tmp")
        temp.write_text(json.dumps(state, sort_keys=True), encoding="utf-8")
        temp.replace(self._state_path)

    # ---- signing in and out

    def signed_in(self) -> bool:
        return (
            self.secrets.get(REFRESH_TOKEN) is not None and self.secrets.get(DATA_KEY) is not None
        )

    def _remember(self, email: str, session: Session, dek: bytes) -> None:
        self.secrets.put(REFRESH_TOKEN, session.refresh_token)
        self.secrets.put(DATA_KEY, dek.hex())
        self.secrets.put(EMAIL, email.strip().lower())
        with self._lock:
            self._session = session

    def create(self, email: str, first_password: str, password: str) -> str:
        """Set up the account once, from this device. Returns the recovery code: show it once.

        `first_password` is the one given when the user was added in the relay's
        dashboard; it is replaced by the auth secret of `password`, so the relay
        never learns the real password. The private YAML files move into the change log.
        """
        check_password(password)
        session = self.relay.sign_in(email, first_password)
        if self.relay.get_vault(session) is not None:
            raise AccountError("this account is already set up; sign in instead")
        keys = login_keys(email, password, self.iterations)
        dek, record, code = create_vault(keys.wrap_key, self.iterations)
        self.relay.put_vault(session, record)
        self.relay.update_password(session, keys.auth_secret)
        session = self.relay.sign_in(email, keys.auth_secret)
        import_settings(self.settings)
        self._remember(email, session, dek)
        return code

    def sign_in(self, email: str, password: str) -> None:
        """Sign in on this device: the data key comes from the vault, opened with the password."""
        keys = login_keys(email, password, self.iterations)
        session = self.relay.sign_in(email, keys.auth_secret)
        record = self.relay.get_vault(session)
        if record is None:
            raise AccountError("this account is not set up yet; create it first")
        self._remember(email, session, open_vault(record, keys.wrap_key))

    def sign_out(self) -> None:
        for item in (REFRESH_TOKEN, DATA_KEY, EMAIL):
            self.secrets.delete(item)
        with self._lock:
            self._session = None

    def _current(self) -> tuple[Session, bytes]:
        """A fresh session (the newest refresh token is read and replaced at once) and the key."""
        with self._lock:
            token, key = self.secrets.get(REFRESH_TOKEN), self.secrets.get(DATA_KEY)
            if token is None or key is None:
                raise AuthError("not signed in")
            if self._session is None or not self._session.fresh():
                self._session = self.relay.refresh(token)
                self.secrets.put(REFRESH_TOKEN, self._session.refresh_token)
            return self._session, bytes.fromhex(key)

    # ---- a round

    def sync(self) -> SyncResult:
        with self._round:
            return self._sync()

    def _sync(self) -> SyncResult:
        session, dek = self._current()
        state = self.state()
        changes = transactions = 0
        position = log_position(self.settings)
        if position == 0:
            blob = self.relay.download(session, SNAPSHOT_FILE)
            if blob is not None:
                snapshot = open_json(blob.decode("ascii"), dek, SNAPSHOT)
                applied = log_apply(self.settings, [snapshot["entry"]], snapshot["upto"])
                changes += applied.changes
                transactions += applied.merged.transactions
                position = int(snapshot["upto"])
                state["snapshot_upto"] = position
        while True:
            rows = self.relay.pull(session, position, PULL_PAGE)
            if not rows:
                break
            entries = [open_json(blob, dek) for _, _, blob in rows]
            position = rows[-1][0]
            applied = log_apply(self.settings, entries, position)
            changes += applied.changes
            transactions += applied.merged.transactions
        out = log_outgoing(self.settings)
        sent = out.entry is not None
        if sent:
            pushed = self.relay.push(session, out.entry["device"], seal_json(out.entry, dek))
            log_mark_pushed(self.settings, out)
            if pushed == position + 1:  # nothing else came in between: this device has it all
                log_apply(self.settings, [], pushed)
            position = pushed
        if (
            self.writes_snapshots
            and position - int(state.get("snapshot_upto", 0)) >= SNAPSHOT_EVERY
        ):
            if self._write_snapshot(session, dek, position):
                state["snapshot_upto"] = position
        at = _now()
        state.update(last_sync=at, last_changes=changes, last_transactions=transactions)
        self._save_state(state)
        return SyncResult(changes, transactions, sent, at)

    def _write_snapshot(self, session: Session, dek: bytes, upto: int) -> bool:
        """Everything up to `upto`, so a new device need not read the whole log."""
        if log_position(self.settings) < upto:
            return False  # not everything before `upto` is here yet: next round
        snapshot = {"upto": upto, "entry": log_full_state(self.settings)}
        self.relay.upload(session, SNAPSHOT_FILE, seal_json(snapshot, dek, SNAPSHOT).encode())
        return True

    # ---- from a signed-in device: the password and the recovery code

    def change_password(self, new_password: str) -> None:
        """A new password without the old one: this device holds the data key."""
        check_password(new_password)
        session, dek = self._current()
        email = self.secrets.get(EMAIL)
        if email is None:
            raise AuthError("not signed in")
        record = self.relay.get_vault(session)
        if record is None:
            raise AccountError("this account is not set up yet")
        keys = login_keys(email, new_password, self.iterations)
        self.relay.put_vault(session, wrap_vault(record, dek, keys.wrap_key, self.iterations))
        self.relay.update_password(session, keys.auth_secret)

    def new_recovery_code(self) -> str:
        """Replace the recovery code; the old one stops working. Show the new one once."""
        session, dek = self._current()
        record = self.relay.get_vault(session)
        if record is None:
            raise AccountError("this account is not set up yet")
        updated, code = replace_recovery(record, dek)
        self.relay.put_vault(session, updated)
        return code


def describe(exc: Exception) -> str:
    """A short code for the app to translate; never the error's own text."""
    from fin.sync.relay import Offline  # noqa: PLC0415

    if isinstance(exc, Offline):
        return "offline"
    if isinstance(exc, AuthError):
        return "signed_out"
    if isinstance(exc, SealError):
        return "key"
    if isinstance(exc, AccountError):
        return "account"
    if isinstance(exc, RelayError):
        return "relay"
    return "failed"
