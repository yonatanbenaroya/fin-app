"""The sync box: moving the ledger between devices, end-to-end encrypted.

Two ways: the encrypted account, whose shared log every device pulls from and
pushes to (`fin sync`, fin.sync.account), and a file the user carries as a
backup (`fin pack`). It may use the logic and
storage boxes through their doors. The encryption module imports its library
only when called, so the phone (which encrypts with WebCrypto) can use the rest.
"""

from fin.sync.account import Account, AccountError, SyncResult, describe
from fin.sync.crypto import SealError, seal, unseal
from fin.sync.keychain import Keychain, MemorySecrets
from fin.sync.pack import PackError
from fin.sync.passphrase import resolve as resolve_passphrase
from fin.sync.passphrase import store_in_keychain
from fin.sync.relay import AuthError, Offline, Relay, RelayError
from fin.sync.transfer import MAC, PHONE, Received, build_plain, outgoing, receive_plain
from fin.sync.vault import (
    LoginKeys,
    create_vault,
    login_keys,
    normalize_recovery_code,
    open_vault,
    open_with_recovery,
    replace_recovery,
    rewrap,
    vault_iterations,
    wrap_vault,
)

__all__ = [
    "MAC",
    "PHONE",
    "Account",
    "AuthError",
    "Keychain",
    "LoginKeys",
    "MemorySecrets",
    "Offline",
    "PackError",
    "Received",
    "Relay",
    "RelayError",
    "SealError",
    "SyncResult",
    "AccountError",
    "describe",
    "build_plain",
    "create_vault",
    "login_keys",
    "normalize_recovery_code",
    "open_vault",
    "open_with_recovery",
    "outgoing",
    "receive_plain",
    "replace_recovery",
    "resolve_passphrase",
    "rewrap",
    "seal",
    "store_in_keychain",
    "unseal",
    "vault_iterations",
    "wrap_vault",
]
