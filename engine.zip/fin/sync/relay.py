"""The sync relay: a Supabase project that stores each device's encrypted file.

Only the standard library (urllib). The account (email and password) only
identifies the user to the relay; everything stored is sealed on the device
first, so the relay holds ciphertext. Each user's files sit in a folder named
after their user id, and the project's access rules let a user reach only
that folder. Errors carry no content from the files.
"""

import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote

BUCKET = "fin-sync"
TIMEOUT_SECONDS = 30
MAX_DOWNLOAD_BYTES = 100 * 1024 * 1024


class RelayError(Exception):
    """The relay could not do what was asked."""


class Offline(RelayError):
    """No network, or the relay did not answer."""


class AuthError(RelayError):
    """Wrong email or password, or the session ended: sign in again."""


REGISTER_ERRORS = frozenset({"input", "invite", "exists", "busy", "relay", "token"})


class RegisterError(RelayError):
    """The relay would not create the account; `code` says why (REGISTER_ERRORS)."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


@dataclass(frozen=True)
class Session:
    user_id: str
    access_token: str = field(repr=False)
    refresh_token: str = field(repr=False)
    expires_at: int

    def fresh(self, now: float | None = None) -> bool:
        """True while the access token has more than a minute left."""
        return self.expires_at - 60 > (time.time() if now is None else now)


class Relay:
    def __init__(self, url: str, anon_key: str, timeout: float = TIMEOUT_SECONDS) -> None:
        self.url = url.rstrip("/")
        self.anon_key = anon_key
        self.timeout = timeout

    def _request(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
        headers: dict[str, str] | None = None,
        token: str | None = None,
    ) -> tuple[int, bytes]:
        request = urllib.request.Request(  # noqa: S310 - the URL is checked in settings
            self.url + path,
            data=body,
            method=method,
            # The client key goes in `apikey` only: the newer publishable keys are not
            # tokens, so Authorization carries the user's token and nothing else.
            headers={
                "apikey": self.anon_key,
                **({"Authorization": f"Bearer {token}"} if token else {}),
                **(headers or {}),
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:  # noqa: S310
                return response.status, response.read(MAX_DOWNLOAD_BYTES + 1)
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read(64 * 1024)
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise Offline("the relay cannot be reached") from exc

    def _token(self, grant: str, payload: dict[str, str]) -> Session:
        status, raw = self._request(
            "POST",
            f"/auth/v1/token?grant_type={grant}",
            json.dumps(payload).encode(),
            {"Content-Type": "application/json"},
        )
        if status in (400, 401, 403, 422):
            raise AuthError(
                "wrong email or password" if grant == "password" else "signed out; sign in again"
            )
        if status != 200:
            raise RelayError(f"the relay answered {status}")
        try:
            data: dict[str, Any] = json.loads(raw)
            expires_at = int(data.get("expires_at") or time.time() + int(data["expires_in"]))
            return Session(
                data["user"]["id"], data["access_token"], data["refresh_token"], expires_at
            )
        except (ValueError, KeyError, TypeError) as exc:
            raise RelayError("the relay sent an unexpected answer") from exc

    def register(self, email: str, auth_secret: str, invite: str | None) -> None:
        """Create the user through the relay's `register` function (relay/functions). The
        relay gets the derived auth secret, never the password. Raises RegisterError."""
        payload = {"email": email, "auth_secret": auth_secret, "invite": invite or ""}
        status, raw = self._request(
            "POST", "/functions/v1/register", json.dumps(payload).encode(),
            {"Content-Type": "application/json"},
        )  # fmt: skip
        if status == 200:
            return
        try:
            code = str(json.loads(raw).get("error", ""))
        except (ValueError, AttributeError):
            code = ""
        raise RegisterError(code if code in REGISTER_ERRORS else "relay")

    def new_invites(self, token: str, count: int = 1) -> list[str]:
        """New invite codes from the relay's `invite` function, with the Mac's own token."""
        status, raw = self._request(
            "POST", "/functions/v1/invite", json.dumps({"count": count}).encode(),
            {"Content-Type": "application/json", "x-invite-token": token},
        )  # fmt: skip
        if status == 403:
            raise RegisterError("token")
        if status != 200:
            raise RelayError(f"the relay answered {status}")
        return [str(code) for code in json.loads(raw)["codes"]]

    def sign_in(self, email: str, password: str) -> Session:
        return self._token("password", {"email": email, "password": password})

    def refresh(self, refresh_token: str) -> Session:
        return self._token("refresh_token", {"refresh_token": refresh_token})

    def _object(self, session: Session, name: str) -> str:
        return f"{quote(BUCKET)}/{quote(session.user_id)}/{quote(name)}"

    def download(self, session: Session, name: str) -> bytes | None:
        """The stored file, or None when there is none yet."""
        status, raw = self._request(
            "GET", f"/storage/v1/object/authenticated/{self._object(session, name)}",
            token=session.access_token,
        )  # fmt: skip
        if status == 200:
            if len(raw) > MAX_DOWNLOAD_BYTES:
                raise RelayError("the stored file is too large")
            return raw
        if status == 404 or (status == 400 and b"not_found" in raw.replace(b" ", b"_").lower()):
            return None
        if status in (401, 403):
            raise AuthError("signed out; sign in again")
        raise RelayError(f"the relay answered {status}")

    def upload(self, session: Session, name: str, data: bytes) -> None:
        """Store the file, replacing the previous one."""
        status, _ = self._request(
            "POST",
            f"/storage/v1/object/{self._object(session, name)}",
            data,
            {"Content-Type": "application/octet-stream", "x-upsert": "true"},
            token=session.access_token,
        )
        if status in (401, 403):
            raise AuthError("signed out; sign in again")
        if status not in (200, 201):
            raise RelayError(f"the relay answered {status}")

    # ---- the account: its vault record and its shared log (Postgres tables behind RLS)

    def _rest(
        self, method: str, path: str, session: Session, body: Any = None, prefer: str = ""
    ) -> Any:
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if prefer:
            headers["Prefer"] = prefer
        data = None if body is None else json.dumps(body).encode()
        status, raw = self._request(method, path, data, headers, token=session.access_token)
        if status in (401, 403):
            raise AuthError("signed out; sign in again")
        if status not in (200, 201, 204):
            raise RelayError(f"the relay answered {status}")
        return json.loads(raw) if raw else None

    def get_vault(self, session: Session) -> dict[str, Any] | None:
        rows = self._rest("GET", "/rest/v1/vaults?select=record", session)
        if not rows:
            return None
        record = rows[0]["record"]
        return json.loads(record) if isinstance(record, str) else record

    def put_vault(self, session: Session, record: dict[str, Any]) -> None:
        self._rest(
            "POST",
            "/rest/v1/vaults?on_conflict=user_id",
            session,
            {"user_id": session.user_id, "record": record},
            prefer="resolution=merge-duplicates,return=minimal",
        )

    def pull(self, session: Session, after: int, limit: int = 100) -> list[tuple[int, str, str]]:
        """Log rows after a position, oldest first: (seq, device, sealed blob)."""
        rows = self._rest(
            "GET",
            f"/rest/v1/changes?select=seq,device,blob&seq=gt.{int(after)}"
            f"&order=seq.asc&limit={int(limit)}",
            session,
        )
        return [(int(r["seq"]), str(r["device"]), str(r["blob"])) for r in rows or []]

    def push(self, session: Session, device: str, blob: str) -> int:
        """Append one sealed entry; returns its position in the log."""
        rows = self._rest(
            "POST",
            "/rest/v1/changes?select=seq",
            session,
            {"device": device, "blob": blob},
            prefer="return=representation",
        )
        return int(rows[0]["seq"])

    def update_password(self, session: Session, password: str) -> None:
        """Set the account's relay password (the derived auth secret, never the real one)."""
        self._rest("PUT", "/auth/v1/user", session, {"password": password})
