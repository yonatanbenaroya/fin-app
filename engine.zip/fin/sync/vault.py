"""One password, derived keys: the key hierarchy of the encrypted account.

    stretched = PBKDF2-SHA256(NFC(password), SHA-256("fin-vault-v1|" + email), N)
    auth      = HKDF-SHA256(stretched, info="fin auth v1")  -> the relay password (hex)
    wrap      = HKDF-SHA256(stretched, info="fin wrap v1")  -> never leaves the device
    vault     = AES-256-GCM(wrap, DEK, aad="fin vault v1")  -> stored in the relay
    recovery  = AES-256-GCM(HKDF(code, "fin recovery v1"), DEK, aad="fin vault recovery v1")

The data key (DEK) is random and made once; everything the account stores is
sealed with it. Changing the password rewraps the DEK and re-encrypts nothing.
A random recovery code, shown once, wraps a second copy of the DEK: with it, or
from a device that still holds the DEK, a forgotten password can be replaced.
The salt comes from the email, so a device can log in without asking anyone
first. `fin/web/vault.js` does the same with WebCrypto; `tests/vault_vectors.json`
proves the two agree. The `cryptography` package is imported only when called.
"""

import base64
import hashlib
import json
import os
import unicodedata
from dataclasses import dataclass, field
from typing import Any

from fin.sync.crypto import SealError

FORMAT = 1
ITERATIONS = 1_000_000
MIN_ITERATIONS = 100_000  # tests only; real vaults use ITERATIONS
MAX_ITERATIONS = 10_000_000
KEY_BYTES = 32
NONCE_BYTES = 12
SALT_PREFIX = "fin-vault-v1|"
AUTH_INFO = b"fin auth v1"
WRAP_INFO = b"fin wrap v1"
VAULT_AAD = b"fin vault v1"
RECOVERY_INFO = b"fin recovery v1"
RECOVERY_AAD = b"fin vault recovery v1"
RECOVERY_CHARS = 28
CROCKFORD = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_CROCKFORD_FIX = str.maketrans("OIL", "011")
KDF = "PBKDF2-SHA256"


@dataclass(frozen=True)
class LoginKeys:
    """What a password gives: the relay password and the key that opens the vault."""

    auth_secret: str = field(repr=False)
    wrap_key: bytes = field(repr=False)


def vault_salt(email: str) -> bytes:
    """The PBKDF2 salt: fixed per account, computable before any network call."""
    return hashlib.sha256((SALT_PREFIX + email.strip().lower()).encode("utf-8")).digest()


def _hkdf(stretched: bytes, info: bytes) -> bytes:
    from cryptography.hazmat.primitives import hashes  # noqa: PLC0415 - Mac only
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF  # noqa: PLC0415

    return HKDF(algorithm=hashes.SHA256(), length=KEY_BYTES, salt=None, info=info).derive(stretched)


def login_keys(email: str, password: str, iterations: int = ITERATIONS) -> LoginKeys:
    """Derive the auth secret and the wrapping key. Slow on purpose (about a second)."""
    if not email.strip():
        raise SealError("an email is required")
    if not password:
        raise SealError("a password is required")
    if not MIN_ITERATIONS <= iterations <= MAX_ITERATIONS:
        raise SealError("iteration count out of range")
    secret = unicodedata.normalize("NFC", password).encode("utf-8")
    stretched = hashlib.pbkdf2_hmac("sha256", secret, vault_salt(email), iterations, KEY_BYTES)
    return LoginKeys(_hkdf(stretched, AUTH_INFO).hex(), _hkdf(stretched, WRAP_INFO))


def _check_key(key: bytes) -> None:
    if len(key) != KEY_BYTES:
        raise SealError("a key must be 32 bytes")


def _seal_key(key: bytes, dek: bytes, aad: bytes, nonce: bytes | None = None) -> str:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: PLC0415

    _check_key(key)
    _check_key(dek)
    nonce = os.urandom(NONCE_BYTES) if nonce is None else nonce
    return base64.b64encode(nonce + AESGCM(key).encrypt(nonce, dek, aad)).decode("ascii")


def _open_key(key: bytes, wrapped: str, aad: bytes, what: str) -> bytes:
    from cryptography.exceptions import InvalidTag  # noqa: PLC0415
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: PLC0415

    _check_key(key)
    blob = base64.b64decode(wrapped)
    try:
        return AESGCM(key).decrypt(blob[:NONCE_BYTES], blob[NONCE_BYTES:], aad)
    except InvalidTag as exc:
        raise SealError(f"wrong {what}, or the vault is damaged") from exc


def new_recovery_code() -> str:
    """A random recovery code (140 bits), shown once: seven groups of four characters."""
    raw = "".join(CROCKFORD[b & 31] for b in os.urandom(RECOVERY_CHARS))
    return "-".join(raw[i : i + 4] for i in range(0, RECOVERY_CHARS, 4))


def normalize_recovery_code(code: str) -> str:
    """The canonical form of a typed code: case, spaces and dashes ignored, O→0, I/L→1."""
    text = "".join(code.split()).replace("-", "").upper().translate(_CROCKFORD_FIX)
    if len(text) != RECOVERY_CHARS or any(c not in CROCKFORD for c in text):
        raise SealError("this is not a recovery code")
    return text


def recovery_key(code: str) -> bytes:
    """The key a recovery code wraps the data key with. No stretching: the code is random."""
    return _hkdf(normalize_recovery_code(code).encode("ascii"), RECOVERY_INFO)


def _record(
    wrap_key: bytes, dek: bytes, iterations: int, recovery: str | None, nonce: bytes | None = None
) -> dict[str, Any]:
    record: dict[str, Any] = {
        "format": FORMAT,
        "kdf": KDF,
        "iterations": iterations,
        "wrapped": _seal_key(wrap_key, dek, VAULT_AAD, nonce),
    }
    if recovery is not None:
        record["recovery"] = recovery
    return record


def create_vault(
    wrap_key: bytes, iterations: int = ITERATIONS
) -> tuple[bytes, dict[str, Any], str]:
    """A new random data key, its vault record and the recovery code (show it once)."""
    dek = os.urandom(KEY_BYTES)
    code = new_recovery_code()
    recovery = _seal_key(recovery_key(code), dek, RECOVERY_AAD)
    return dek, _record(wrap_key, dek, iterations, recovery), code


def _wrapped_ok(value: Any) -> bool:
    blob = base64.b64decode(value, validate=True)
    return len(blob) == NONCE_BYTES + KEY_BYTES + 16


def _parse(record: Any) -> dict[str, Any]:
    """The checked vault record as a dict, or SealError."""
    if isinstance(record, (str, bytes)):
        try:
            record = json.loads(record)
        except ValueError as exc:
            raise SealError("this is not a vault record") from exc
    try:
        iterations = record["iterations"]
        valid = (
            record["format"] == FORMAT
            and record["kdf"] == KDF
            and type(iterations) is int
            and MIN_ITERATIONS <= iterations <= MAX_ITERATIONS
            and _wrapped_ok(record["wrapped"])
            and ("recovery" not in record or _wrapped_ok(record["recovery"]))
        )
    except (ValueError, KeyError, TypeError) as exc:
        raise SealError("this is not a vault record") from exc
    if not valid:
        raise SealError("this is not a vault record")
    return record


def vault_iterations(record: Any) -> int:
    """The iteration count a vault record was made with (to derive the login keys)."""
    return _parse(record)["iterations"]


def open_vault(record: Any, wrap_key: bytes) -> bytes:
    """The data key. Raises SealError on a wrong password or a damaged record."""
    return _open_key(wrap_key, _parse(record)["wrapped"], VAULT_AAD, "password")


def open_with_recovery(record: Any, code: str) -> bytes:
    """The data key from the recovery code (a forgotten password). SealError if wrong."""
    checked = _parse(record)
    if "recovery" not in checked:
        raise SealError("this vault has no recovery code")
    return _open_key(recovery_key(code), checked["recovery"], RECOVERY_AAD, "recovery code")


def wrap_vault(
    record: Any, dek: bytes, new_wrap_key: bytes, iterations: int | None = None
) -> dict[str, Any]:
    """The record with the data key under a new password; the recovery copy is kept.

    For a device that already holds the data key: a password reset without the old one.
    """
    checked = _parse(record)
    count = checked["iterations"] if iterations is None else iterations
    return _record(new_wrap_key, dek, count, checked.get("recovery"))


def rewrap(
    record: Any, old_wrap_key: bytes, new_wrap_key: bytes, iterations: int | None = None
) -> dict[str, Any]:
    """The same data key under a new password's wrapping key (a password change)."""
    return wrap_vault(record, open_vault(record, old_wrap_key), new_wrap_key, iterations)


def replace_recovery(record: Any, dek: bytes) -> tuple[dict[str, Any], str]:
    """A new recovery code for this vault; the old one stops working. Show the code once."""
    checked = dict(_parse(record))
    code = new_recovery_code()
    checked["recovery"] = _seal_key(recovery_key(code), dek, RECOVERY_AAD)
    return checked, code
