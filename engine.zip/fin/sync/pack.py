"""The content of a transfer file: a zip with the ledger rows (and the Mac's private configs).

Pure format code, used on both devices (the phone runs it in Pyodide).
Encryption is a separate step (fin.sync.crypto on the Mac, WebCrypto on the phone).
"""

import io
import json
import zipfile
from dataclasses import dataclass, field
from typing import Any

from fin.storage import PRIVATE_CONFIGS

FORMAT = 1
DEVICES = ("mac", "phone")
MAX_PLAIN_BYTES = 200 * 1024 * 1024


class PackError(ValueError):
    """The transfer file is not one this app can read."""


@dataclass(frozen=True)
class Pack:
    device: str
    exported_at: str
    snapshot: dict[str, Any]
    configs: dict[str, str] = field(default_factory=dict)


def make_plain(pack: Pack) -> bytes:
    """The zip that will be encrypted."""
    if pack.device not in DEVICES:
        raise PackError(f"unknown device {pack.device!r}")
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        manifest = {"format": FORMAT, "device": pack.device, "exported_at": pack.exported_at}
        archive.writestr("manifest.json", json.dumps(manifest))
        archive.writestr("rows.json", json.dumps(pack.snapshot, ensure_ascii=False))
        for name, text in sorted(pack.configs.items()):
            if name not in PRIVATE_CONFIGS:
                raise PackError(f"unknown config file {name!r}")
            archive.writestr(f"config/{name}", text)
    return buffer.getvalue()


def read_plain(data: bytes) -> Pack:
    """Read a decrypted transfer file. Raises PackError for anything unexpected."""
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            if sum(item.file_size for item in archive.infolist()) > MAX_PLAIN_BYTES:
                raise PackError("the file is too large")
            manifest = json.loads(archive.read("manifest.json"))
            snapshot = json.loads(archive.read("rows.json"))
            configs = {}
            for name in archive.namelist():
                if name.startswith("config/"):
                    bare = name.removeprefix("config/")
                    if bare not in PRIVATE_CONFIGS:
                        raise PackError(f"unknown config file {bare!r}")
                    configs[bare] = archive.read(name).decode("utf-8")
    except (zipfile.BadZipFile, KeyError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise PackError("this is not a transfer file from this app") from exc
    if manifest.get("format") != FORMAT:
        raise PackError("the file comes from a different version of the app")
    if manifest.get("device") not in DEVICES or not isinstance(snapshot, dict):
        raise PackError("this is not a transfer file from this app")
    return Pack(manifest["device"], str(manifest.get("exported_at", "")), snapshot, configs)
