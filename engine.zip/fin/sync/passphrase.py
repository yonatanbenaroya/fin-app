"""Where the Mac gets the transfer passphrase: the environment, the macOS Keychain, or a prompt.

The passphrase is never written to a file. `fin pack passphrase` stores it in
the Keychain through the `security` tool, which asks for it itself, so it never
appears on a command line.
"""

import getpass
import os
import subprocess

ENV_VAR = "FIN_PACK_PASSPHRASE"
SERVICE = "fin-pack"
ACCOUNT = "finance"


def from_keychain() -> str | None:
    """The stored passphrase, or None when there is none (or no Keychain)."""
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-s", SERVICE, "-a", ACCOUNT, "-w"],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return None
    value = result.stdout.rstrip("\n")
    return value if result.returncode == 0 and value else None


def store_in_keychain() -> bool:
    """Ask for a passphrase in the terminal and store it in the Keychain. True on success."""
    try:
        result = subprocess.run(
            ["security", "add-generic-password", "-U", "-s", SERVICE, "-a", ACCOUNT, "-w"],
            check=False,
        )
    except FileNotFoundError:
        return False
    return result.returncode == 0


def resolve(confirm: bool) -> str:
    """The passphrase to use now. Prompts (twice when `confirm`) if none is stored."""
    value = os.environ.get(ENV_VAR) or from_keychain()
    if value:
        return value
    first = getpass.getpass("Transfer passphrase: ")
    if confirm and getpass.getpass("Again: ") != first:
        raise ValueError("the two passphrases differ")
    if not first:
        raise ValueError("a passphrase is required")
    return first
