"""Small secrets kept in the macOS Keychain: the sync session and the passphrase.

Values are written through `security -i`, which reads its commands from
standard input, so a secret never appears in the process list. Tests use
`MemorySecrets` instead.
"""

import subprocess
from typing import Protocol

# (service, account) pairs. The passphrase item is the one `fin pack passphrase` writes.
REFRESH_TOKEN = ("fin-sync", "refresh-token")
PASSPHRASE = ("fin-pack", "finance")


class Secrets(Protocol):
    def get(self, item: tuple[str, str]) -> str | None: ...
    def put(self, item: tuple[str, str], value: str) -> None: ...
    def delete(self, item: tuple[str, str]) -> None: ...


def _quoted(value: str) -> str:
    if "\n" in value or "\r" in value or "\0" in value:
        raise ValueError("a secret cannot contain a line break")
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


class Keychain:
    """The login Keychain, through the `security` tool."""

    def get(self, item: tuple[str, str]) -> str | None:
        service, account = item
        try:
            result = subprocess.run(
                ["security", "find-generic-password", "-s", service, "-a", account, "-w"],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            return None
        value = result.stdout.rstrip("\n")
        return value if result.returncode == 0 and value else None

    def put(self, item: tuple[str, str], value: str) -> None:
        service, account = item
        command = (
            f"add-generic-password -U -s {_quoted(service)} -a {_quoted(account)}"
            f" -w {_quoted(value)}\n"
        )
        result = subprocess.run(
            ["security", "-i"], input=command, capture_output=True, text=True, check=False
        )
        if result.returncode != 0 or result.stderr.strip():
            raise OSError("could not write to the Keychain")

    def delete(self, item: tuple[str, str]) -> None:
        service, account = item
        subprocess.run(
            ["security", "delete-generic-password", "-s", service, "-a", account],
            capture_output=True,
            check=False,
        )


class MemorySecrets:
    """Secrets in memory, for tests."""

    def __init__(self) -> None:
        self.values: dict[tuple[str, str], str] = {}

    def get(self, item: tuple[str, str]) -> str | None:
        return self.values.get(item)

    def put(self, item: tuple[str, str], value: str) -> None:
        self.values[item] = value

    def delete(self, item: tuple[str, str]) -> None:
        self.values.pop(item, None)
