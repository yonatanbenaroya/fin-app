"""Sending the ledger between the Mac and the phone in an encrypted file.

Transactions merge by identity, so both devices can import. Configs travel
one way only: the Mac's configs replace the phone's; the Mac never takes the
phone's. Results are counts, never rows.
"""

import hashlib
import json
from dataclasses import dataclass
from datetime import UTC, datetime

from fin.storage import (
    MergeSummary,
    Settings,
    ledger_snapshot,
    merge_ledger,
    private_configs,
    write_private_configs,
)
from fin.sync.pack import Pack, PackError, make_plain, read_plain

MAC = "mac"
PHONE = "phone"


@dataclass(frozen=True)
class Received:
    sender: str
    exported_at: str
    merged: MergeSummary
    configs: tuple[str, ...]


@dataclass(frozen=True)
class Outgoing:
    plain: bytes
    digest: str  # of the content alone, without the export time: unchanged data, same digest


def outgoing(settings: Settings, device: str) -> Outgoing:
    """This device's unencrypted pack and a digest of what is in it."""
    configs = private_configs(settings) if device == MAC else {}
    snapshot = ledger_snapshot(settings)
    exported_at = datetime.now(UTC).isoformat(timespec="seconds")
    content = json.dumps([snapshot, configs], ensure_ascii=False, sort_keys=True)
    digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
    return Outgoing(make_plain(Pack(device, exported_at, snapshot, configs)), digest)


def build_plain(settings: Settings, device: str) -> bytes:
    """The unencrypted pack of this device: all rows, and the configs when it is the Mac."""
    return outgoing(settings, device).plain


def receive_plain(settings: Settings, plain: bytes, device: str) -> Received:
    """Merge a decrypted pack into this device. The phone also takes the Mac's configs."""
    pack = read_plain(plain)
    if pack.device == device:
        raise PackError(f"this file was made on a {device}; send it to the other device")
    applied: list[str] = []
    if device == PHONE and pack.device == MAC and pack.configs:
        applied = write_private_configs(settings, pack.configs)
    merged = merge_ledger(settings, pack.snapshot)
    return Received(pack.device, pack.exported_at, merged, tuple(applied))
