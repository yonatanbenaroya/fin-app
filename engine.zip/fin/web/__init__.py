"""Mobile-first web UI."""
