"""Is a password strong enough for the account? A pure rule, no network.

The one password guards every transaction on every device, and it is stretched
only once (PBKDF2), so it must be long: at least 16 characters, or a passphrase
of at least four words of three or more letters (Hebrew or English). Obvious
repeats ("aaaa...", "abcabc...", the same word four times) are refused.
"""

import re

MIN_LENGTH = 16
MIN_WORDS = 4
MIN_WORD_LETTERS = 3
MIN_DISTINCT_CHARS = 6

OK = None
EMPTY = "empty"
SHORT = "short"
REPEATED = "repeated"

_WORD = re.compile(r"[^\W\d_]+")
_REPEAT_UNIT = re.compile(r"(.+?)\1+", re.DOTALL)


def _words(password: str) -> list[str]:
    return [w.lower() for w in _WORD.findall(password) if len(w) >= MIN_WORD_LETTERS]


def _repeated(password: str) -> bool:
    text = password.strip().lower()
    if _REPEAT_UNIT.fullmatch(text) or len(set(text)) < MIN_DISTINCT_CHARS:
        return True
    words = _words(password)
    return len(words) >= MIN_WORDS and len(set(words)) < MIN_WORDS - 1


def password_problem(password: str) -> str | None:
    """None when the password is acceptable, otherwise EMPTY, SHORT or REPEATED."""
    if not password.strip():
        return EMPTY
    if len(password.strip()) < MIN_LENGTH and len(_words(password)) < MIN_WORDS:
        return SHORT
    if _repeated(password):
        return REPEATED
    return OK
