"""Errors shared by every box."""


class ConfigError(Exception):
    """Raised when a configuration file or value is missing or invalid."""
