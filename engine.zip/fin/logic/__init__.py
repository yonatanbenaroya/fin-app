"""The logic box: pure calculation.

No database, no files, no network: data in, data out. It imports nothing from
the other boxes. Other boxes take only what is listed here.
"""

from fin.logic.categorize.card_payments import BankPayment, CardCharge, match_card_payments
from fin.logic.categorize.legacy_match import LedgerRow, LegacyRow, learn_merchants, match_legacy
from fin.logic.categorize.overlay import apply_overlay
from fin.logic.categorize.rules import (
    LAYER_CARD_PAYMENT,
    LAYER_ESTIMATE,
    LAYER_NONE,
    SPECIFIC_LAYERS,
    classify,
    resolve,
)
from fin.logic.categorize.taxonomy import (
    EXPENSE,
    FAMILY_SUPPORT,
    INCOME,
    INTERNAL_TRANSFER,
    INVESTMENT,
    TRANSFER_IN,
    Rule,
    Taxonomy,
    parse_private_rules,
    parse_taxonomy,
)
from fin.logic.changes.hlc import ZERO as ZERO_STAMP
from fin.logic.changes.hlc import ClockError, Stamp
from fin.logic.changes.hlc import decode as decode_stamp
from fin.logic.changes.hlc import receive as clock_receive
from fin.logic.changes.hlc import tick as clock_tick
from fin.logic.changes.merge import ENTITIES, ITEM, Change, ChangeError, State
from fin.logic.changes.merge import fold as fold_changes
from fin.logic.changes.merge import history as change_history
from fin.logic.changes.order import between as order_between
from fin.logic.changes.order import ordered as in_order
from fin.logic.errors import ConfigError
from fin.logic.invite import INVITE_ALPHABET, normalize_invite
from fin.logic.manual import (
    CASH,
    MANUAL_SOURCE,
    FileRow,
    ManualTransaction,
    match_provisional,
    parse_manual,
)
from fin.logic.money import AGOROT_PER_SHEKEL, format_ils, mean_agorot, to_agorot
from fin.logic.net_worth import (
    ACCESSIBLE,
    FUTURE,
    HOLDING_KINDS,
    LONG_TERM,
    RATE_SCALE,
    BalancePoint,
    Holding,
    MonthWorth,
    group,
    net_worth_series,
    parse_holding,
    parse_point,
    point_for,
    value_agorot,
)
from fin.logic.password import password_problem
from fin.logic.planner.afford import check_purchase
from fin.logic.planner.baseline import (
    DECLARED,
    DEFAULT_WINDOW_MONTHS,
    RESERVE_LINE,
    Baseline,
    baseline_window,
    build_baseline,
)
from fin.logic.planner.baseline_config import BaselineConfig, parse_baseline_config
from fin.logic.planner.budget import (
    DEFAULT_TARGET_SURPLUS_AGOROT,
    Budget,
    TrackLine,
    budget_from_ceilings,
    effective_ceilings,
    propose_budget,
    track_month,
)
from fin.logic.planner.budget_config import BudgetConfig, parse_budget_config
from fin.logic.planner.due import (
    UNASSIGNED,
    Charge,
    Due,
    DueItem,
    same_payment,
    still_due,
    with_unassigned,
)
from fin.logic.planner.goals import (
    ALREADY,
    GoalStatus,
    cash_flow_check,
    evaluate_goals,
    first_limit_breach,
    required_horizon,
)
from fin.logic.planner.goals_config import Event, GoalsConfig, parse_goals_config
from fin.logic.planner.outlook import Outlook, build_outlook, goal_progress
from fin.logic.planner.pace import Pace, PaceDay, days_in, month_pace, pace_day
from fin.logic.planner.projection import ProjectedMonth, add_months, months_between, project
from fin.logic.planner.ranges import PRESETS as RANGE_PRESETS
from fin.logic.planner.ranges import date_range
from fin.logic.planner.scenario_config import Scenario, parse_scenarios
from fin.logic.planner.scenarios import ResolvedScenario, resolve_scenario
from fin.logic.source_map import (
    BANK,
    CARD,
    MAP_PREFIX,
    MappedRow,
    MappedRows,
    SourceMap,
    guess_columns,
    header_cells,
    map_rows,
    parse_source_map,
)
from fin.logic.summary import BucketLine, IncomeReference, MonthSummary, PeriodSummary
from fin.logic.titles import MAX_TITLE, RenameRule, display_title

__all__ = [
    "CASH",
    "FileRow",
    "match_provisional",
    "MAX_TITLE",
    "RenameRule",
    "display_title",
    "MANUAL_SOURCE",
    "ManualTransaction",
    "parse_manual",
    "ENTITIES",
    "ITEM",
    "apply_overlay",
    "ACCESSIBLE",
    "FUTURE",
    "HOLDING_KINDS",
    "LONG_TERM",
    "RATE_SCALE",
    "BalancePoint",
    "Holding",
    "MonthWorth",
    "group",
    "net_worth_series",
    "parse_holding",
    "parse_point",
    "point_for",
    "value_agorot",
    "INVITE_ALPHABET",
    "normalize_invite",
    "BANK",
    "CARD",
    "MAP_PREFIX",
    "MappedRow",
    "MappedRows",
    "SourceMap",
    "guess_columns",
    "header_cells",
    "map_rows",
    "parse_source_map",
    "ZERO_STAMP",
    "Change",
    "ChangeError",
    "ClockError",
    "Stamp",
    "State",
    "change_history",
    "clock_receive",
    "clock_tick",
    "decode_stamp",
    "fold_changes",
    "in_order",
    "order_between",
    "AGOROT_PER_SHEKEL",
    "ALREADY",
    "BankPayment",
    "Baseline",
    "BaselineConfig",
    "BucketLine",
    "Budget",
    "BudgetConfig",
    "CardCharge",
    "ConfigError",
    "DECLARED",
    "DEFAULT_TARGET_SURPLUS_AGOROT",
    "DEFAULT_WINDOW_MONTHS",
    "EXPENSE",
    "Event",
    "FAMILY_SUPPORT",
    "GoalStatus",
    "GoalsConfig",
    "INCOME",
    "INTERNAL_TRANSFER",
    "INVESTMENT",
    "IncomeReference",
    "LAYER_CARD_PAYMENT",
    "LAYER_ESTIMATE",
    "LAYER_NONE",
    "LedgerRow",
    "LegacyRow",
    "MonthSummary",
    "Outlook",
    "Pace",
    "Charge",
    "Due",
    "DueItem",
    "same_payment",
    "still_due",
    "UNASSIGNED",
    "with_unassigned",
    "PeriodSummary",
    "ProjectedMonth",
    "RESERVE_LINE",
    "ResolvedScenario",
    "Rule",
    "SPECIFIC_LAYERS",
    "Scenario",
    "TRANSFER_IN",
    "Taxonomy",
    "TrackLine",
    "add_months",
    "baseline_window",
    "budget_from_ceilings",
    "build_baseline",
    "build_outlook",
    "cash_flow_check",
    "check_purchase",
    "classify",
    "effective_ceilings",
    "evaluate_goals",
    "first_limit_breach",
    "format_ils",
    "goal_progress",
    "learn_merchants",
    "match_card_payments",
    "match_legacy",
    "mean_agorot",
    "month_pace",
    "PaceDay",
    "pace_day",
    "days_in",
    "RANGE_PRESETS",
    "date_range",
    "months_between",
    "parse_baseline_config",
    "parse_budget_config",
    "parse_goals_config",
    "parse_private_rules",
    "parse_scenarios",
    "parse_taxonomy",
    "password_problem",
    "project",
    "propose_budget",
    "required_horizon",
    "resolve",
    "resolve_scenario",
    "to_agorot",
    "track_month",
]
