"""Manual transactions: an expense or income typed in by hand, kept in the change log.

Amounts are signed integer agorot, like every stored transaction: an expense is
negative, income positive. The category is optional; without one the
categorization rules decide, as for any imported row.
"""

import re
from dataclasses import dataclass
from datetime import date
from typing import Any

from fin.logic.categorize.taxonomy import Taxonomy
from fin.logic.errors import ConfigError

MANUAL_SOURCE = "manual"
MAX_DESCRIPTION = 200
_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")


@dataclass(frozen=True)
class ManualTransaction:
    id: str
    tx_date: str
    amount_agorot: int
    description: str
    category: str | None = None

    @property
    def tx_hash(self) -> str:
        return f"{MANUAL_SOURCE}:{self.id}"

    @property
    def budget_month(self) -> str:
        return self.tx_date[:7]


def parse_manual(item_id: str, fields: dict[str, Any], taxonomy: Taxonomy) -> ManualTransaction:
    """Validate one manual transaction's fields; ConfigError says what is wrong."""
    when, amount = fields.get("date"), fields.get("amount_agorot")
    text, category = fields.get("description"), fields.get("category")
    if not isinstance(when, str) or not _DATE.fullmatch(when):
        raise ConfigError("manual transaction: date must be YYYY-MM-DD")
    try:
        date.fromisoformat(when)
    except ValueError as exc:
        raise ConfigError("manual transaction: no such date") from exc
    if isinstance(amount, bool) or not isinstance(amount, int) or amount == 0:
        raise ConfigError("manual transaction: amount_agorot must be a non-zero whole number")
    if not isinstance(text, str) or not text.strip() or len(text) > MAX_DESCRIPTION:
        raise ConfigError("manual transaction: a description of up to 200 characters is needed")
    if category is not None and category not in taxonomy.categories:
        raise ConfigError(f"manual transaction: unknown category {category!r}")
    return ManualTransaction(item_id, when, amount, text.strip(), category)
