"""Manual transactions: an expense or income typed in by hand, kept in the change log.

Amounts are signed integer agorot, like every stored transaction: an expense is
negative, income positive. The category is optional; without one the
categorization rules decide, as for any imported row.

`via` says how it was paid (design.md §11.2). Paid by card or from the bank it
is provisional: when that source's file is imported, the row for the same amount
within a few days takes its place, so it is never counted twice. Cash and other
are permanent manual transactions and are never matched.
"""

import re
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import date
from typing import Any

from fin.logic.categorize.taxonomy import Taxonomy
from fin.logic.errors import ConfigError

MANUAL_SOURCE = "manual"
MAX_DESCRIPTION = 200
_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")
CASH = "cash"
OTHER_VIA = "other"
PERMANENT = frozenset({CASH, OTHER_VIA})  # never matched to a file row
MATCH_DAYS = 3  # user decision, 2026-11-18: same source, exact amount, up to 3 days apart
_VIA = re.compile(r"[a-z][a-z0-9_]{0,30}")


@dataclass(frozen=True)
class ManualTransaction:
    id: str
    tx_date: str
    amount_agorot: int
    description: str
    category: str | None = None
    via: str | None = None  # max, cal, hapoalim, cash, other ...; None for older entries

    @property
    def provisional(self) -> bool:
        """Paid by a card or from the bank: waiting for that source's file row."""
        return self.via is not None and self.via not in PERMANENT

    @property
    def tx_hash(self) -> str:
        return f"{MANUAL_SOURCE}:{self.id}"

    @property
    def budget_month(self) -> str:
        return self.tx_date[:7]


def parse_manual(item_id: str, fields: dict[str, Any], taxonomy: Taxonomy) -> ManualTransaction:
    """Validate one manual transaction's fields; ConfigError says what is wrong."""
    when, amount = fields.get("date"), fields.get("amount_agorot")
    text, category, via = fields.get("description"), fields.get("category"), fields.get("via")
    if not isinstance(when, str) or not _DATE.fullmatch(when):
        raise ConfigError("manual transaction: date must be YYYY-MM-DD")
    try:
        date.fromisoformat(when)
    except ValueError as exc:
        raise ConfigError("manual transaction: no such date") from exc
    if isinstance(amount, bool) or not isinstance(amount, int) or amount == 0:
        raise ConfigError("manual transaction: amount_agorot must be a non-zero whole number")
    if not isinstance(text, str) or not text.strip() or len(text) > MAX_DESCRIPTION:
        raise ConfigError("manual transaction: a description of up to 200 characters is needed")
    if category is not None and category not in taxonomy.categories:
        raise ConfigError(f"manual transaction: unknown category {category!r}")
    if via is not None and (not isinstance(via, str) or not _VIA.fullmatch(via)):
        raise ConfigError("manual transaction: unknown source")
    return ManualTransaction(item_id, when, amount, text.strip(), category, via)


@dataclass(frozen=True)
class FileRow:
    tx_hash: str
    source: str
    tx_date: str
    amount_agorot: int


def match_provisional(
    items: Sequence[ManualTransaction], rows: Sequence[FileRow], days: int = MATCH_DAYS
) -> dict[str, str]:
    """Which file row replaces each provisional item: manual id -> tx_hash.

    A row matches when it comes from the item's source, has the same amount to the
    agora, and is dated at most `days` apart. Each row replaces one item at most.
    Items are taken oldest first; among several rows the nearest date wins, then the
    smallest tx_hash, so every device reaches the same answer.
    """
    taken: set[str] = set()
    found: dict[str, str] = {}
    for item in sorted((i for i in items if i.provisional), key=lambda i: (i.tx_date, i.id)):
        when = date.fromisoformat(item.tx_date)
        candidates = sorted(
            (abs((date.fromisoformat(row.tx_date) - when).days), row.tx_hash)
            for row in rows
            if row.source == item.via
            and row.amount_agorot == item.amount_agorot
            and row.tx_hash not in taken
            and abs((date.fromisoformat(row.tx_date) - when).days) <= days
        )
        if candidates:
            found[item.id] = candidates[0][1]
            taken.add(candidates[0][1])
    return found
