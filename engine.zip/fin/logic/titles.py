"""A transaction's title: the name shown for it, which the user may change.

The bank's own text is never replaced: it stays the transaction's description,
categorization rules keep matching it, and search finds it. A title comes from
the transaction's own name if it has one, otherwise from the first rename rule
that matches the bank's text (and, when the rule has one, the exact amount),
otherwise it is the bank's text itself.
"""

from collections.abc import Sequence
from dataclasses import dataclass

MAX_TITLE = 80


@dataclass(frozen=True)
class RenameRule:
    id: str
    match: str  # the bank's text, matched whole, ignoring case
    title: str
    amount_agorot: int | None = None  # only this signed amount, when given

    def matches(self, description: str, amount_agorot: int) -> bool:
        if self.amount_agorot is not None and self.amount_agorot != amount_agorot:
            return False
        return description.casefold() == self.match.casefold()


def display_title(
    description: str,
    amount_agorot: int,
    own: str | None,
    rules: Sequence[RenameRule],
) -> str:
    """The title to show: the transaction's own name, a matching rule's, or the bank's text."""
    if own:
        return own
    for rule in rules:
        if rule.matches(description, amount_agorot):
            return rule.title
    return description
