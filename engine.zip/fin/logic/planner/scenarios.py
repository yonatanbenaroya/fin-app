"""Turn a what-if scenario into concrete changes to the projection. Pure.

Every change becomes a monthly cash flow adjustment (positive is better) or a
one-time event. Levels are read off the baseline's own window months, so a
"cut" is always a level of spending that already happened.
"""

from collections.abc import Sequence
from dataclasses import dataclass

from fin.logic.errors import ConfigError
from fin.logic.money import mean_agorot
from fin.logic.planner.baseline import MEAN, Baseline, BaselineLine
from fin.logic.planner.goals_config import Event
from fin.logic.planner.projection import Adjustment
from fin.logic.planner.scenario_config import (
    BUCKET_CHANGE,
    BUCKET_SET,
    EVENT,
    INCOME,
    LEVEL,
    MEDIAN,
    RECEIVED,
    Change,
    Scenario,
)


@dataclass(frozen=True)
class ResolvedScenario:
    name: str
    adjustments: tuple[Adjustment, ...] = ()
    events: tuple[Event, ...] = ()


def median_agorot(values: Sequence[int]) -> int:
    """Median in whole agorot; an even count takes the mean of the two middle values."""
    if not values:
        raise ValueError("no values")
    ordered = sorted(values)
    middle = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[middle]
    return mean_agorot(ordered[middle - 1] + ordered[middle], 2)


def second_lowest_agorot(values: Sequence[int]) -> int:
    """The second-lowest value: a lean month that happened more than once."""
    if not values:
        raise ValueError("no values")
    ordered = sorted(values)
    return ordered[min(1, len(ordered) - 1)]


def resolve_scenario(scenario: Scenario, baseline: Baseline) -> ResolvedScenario:
    """Resolve a scenario's changes against the baseline."""
    adjustments: list[Adjustment] = []
    events: list[Event] = []
    for change in scenario.changes:
        if change.kind == EVENT:
            assert change.first_month is not None and change.amount_agorot is not None
            events.append(Event(change.first_month, change.label, change.amount_agorot))
            continue
        for label, delta in _deltas(change, baseline, scenario.name):
            if delta:
                adjustments.append(
                    Adjustment(change.label or label, delta, change.first_month, change.last_month)
                )
    return ResolvedScenario(scenario.name, tuple(adjustments), tuple(events))


def _deltas(change: Change, baseline: Baseline, scenario: str) -> list[tuple[str, int]]:
    """(label, monthly cash flow change) pairs for one change."""
    if change.kind == RECEIVED:
        return [("no money received from people", -baseline.received_agorot)]
    if change.kind == INCOME:
        return [("net income", change.amount_agorot or 0)]
    if change.kind == LEVEL:
        if change.bucket is None:
            lines = [line for line in baseline.lines if line.basis == MEAN]
        else:
            lines = [_line(baseline, change.bucket, scenario)]
            if lines[0].basis != MEAN:
                raise ConfigError(
                    f"scenario {scenario!r}: bucket {change.bucket!r} is declared, not measured;"
                    " use 'set' to change it"
                )
        level = median_agorot if change.level == MEDIAN else second_lowest_agorot
        return [
            (
                f"{line.bucket} at its {change.level} month",
                line.amount_agorot - level(line.monthly_agorot),
            )
            for line in lines
        ]
    line = _line(baseline, change.bucket or "", scenario)
    amount = change.amount_agorot or 0
    if change.kind == BUCKET_SET:
        return [(f"{line.bucket} set", line.amount_agorot - amount)]
    assert change.kind == BUCKET_CHANGE
    return [(f"{line.bucket} changed", -amount)]


def _line(baseline: Baseline, bucket: str, scenario: str) -> BaselineLine:
    for line in baseline.lines:
        if line.bucket == bucket:
            return line
    raise ConfigError(f"scenario {scenario!r}: bucket {bucket!r} is not in the baseline")
