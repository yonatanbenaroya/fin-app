"""Date ranges for the Activity filter: the presets turned into first and last days.

Pure: the caller passes today (the device's date). Every range is inclusive.
"""

import re
from datetime import date, timedelta

_MONTH = re.compile(r"\d{4}-(0[1-9]|1[0-2])")
PRESETS = ("this_month", "last_month", "last_3_months", "this_year", "month", "custom")


def _first_of(year: int, month: int) -> date:
    return date(year + (month - 1) // 12, (month - 1) % 12 + 1, 1)


def _last_of(year: int, month: int) -> date:
    return _first_of(year, month + 1) - timedelta(days=1)


def date_range(
    preset: str,
    today: date,
    month: str | None = None,
    start: date | None = None,
    end: date | None = None,
) -> tuple[date, date]:
    """(first day, last day) of a preset. ValueError for an unknown or malformed one.

    this_month and this_year run to today; last_month is the whole previous month;
    last_3_months is this month and the two before it; month is a "YYYY-MM"; custom
    is `start` to `end` (swapped when given the wrong way round).
    """
    if preset == "this_month":
        return _first_of(today.year, today.month), today
    if preset == "last_month":
        return _first_of(today.year, today.month - 1), _last_of(today.year, today.month - 1)
    if preset == "last_3_months":
        return _first_of(today.year, today.month - 2), today
    if preset == "this_year":
        return date(today.year, 1, 1), today
    if preset == "month":
        if not _MONTH.fullmatch(month or ""):
            raise ValueError("month must be YYYY-MM")
        first = date(int(month[:4]), int(month[5:]), 1)  # type: ignore[index]
        return first, _last_of(first.year, first.month)
    if preset == "custom":
        if start is None or end is None:
            raise ValueError("a custom range needs from and to")
        return (start, end) if start <= end else (end, start)
    raise ValueError(f"unknown range {preset!r}")
