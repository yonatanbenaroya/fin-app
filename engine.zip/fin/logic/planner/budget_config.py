"""Monthly spending ceilings per bucket, kept in a private YAML file."""

import re
from dataclasses import dataclass
from typing import Any

from fin.logic.errors import ConfigError
from fin.logic.money import to_agorot

_MONTH = re.compile(r"\d{4}-(0[1-9]|1[0-2])")
_PREFIX = "budget config"


@dataclass(frozen=True)
class BudgetConfig:
    # First month the ceilings apply to (YYYY-MM).
    start_month: str
    # The monthly surplus the budget is meant to leave.
    target_surplus_agorot: int
    # Bucket -> monthly ceiling.
    ceilings: dict[str, int]


def parse_budget_config(raw: Any, path: str = "") -> BudgetConfig:
    """Validate a saved budget."""
    if not isinstance(raw, dict):
        raise ConfigError(f"{_PREFIX}: root must be a mapping: {path}")
    month = str(raw.get("start_month", ""))
    if not _MONTH.fullmatch(month):
        raise ConfigError(f"{_PREFIX}: start_month must be YYYY-MM")
    ceilings = raw.get("ceilings")
    if not isinstance(ceilings, dict) or not ceilings:
        raise ConfigError(f"{_PREFIX}: ceilings must be a non-empty mapping")
    return BudgetConfig(
        start_month=month,
        target_surplus_agorot=_amount(raw.get("target_surplus", 0), "target_surplus"),
        ceilings={str(b): _amount(value, f"ceilings.{b}") for b, value in ceilings.items()},
    )


def _amount(value: Any, name: str) -> int:
    try:
        agorot = to_agorot(value)
    except (TypeError, ValueError) as exc:
        raise ConfigError(f"{_PREFIX}: {name} is not a money amount") from exc
    if agorot < 0:
        raise ConfigError(f"{_PREFIX}: {name} must not be negative")
    return agorot
