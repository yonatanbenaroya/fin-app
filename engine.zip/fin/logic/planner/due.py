"""The fixed payments still due this month (design.md §6 "What left means", spec v0.38).

Pure. Fixed payments are the commitments charged to a bucket in the pace and the card
installments. A commitment has a month but no day, so it is still due until a charge in
the month's files matches it (the same rule as "Coming up": the same amount, or the
commitment's name in the charge's text). A card installment counts in its purchase
month plus k-1 (spec v0.39), like a regular card purchase charged the next month: it is
spending already, never still due. One real payment counts once: a commitment and its
card installment are one payment.
"""

from collections.abc import Collection, Sequence
from dataclasses import dataclass, field, replace

from fin.logic.planner.goals_config import Commitment

COMMITMENT = "commitment"
CARD = "card"
# The hidden group of the commitments that have no group (one added from "Coming up"):
# counted in Home's total like any commitment, never shown as a group (spec v0.38).
UNASSIGNED = "(commitments)"


def with_unassigned(commitments: Sequence[Commitment]) -> tuple[Commitment, ...]:
    """The commitments, those without a group placed in the hidden UNASSIGNED group."""
    return tuple(c if c.bucket is not None else replace(c, bucket=UNASSIGNED) for c in commitments)


def same_payment(name: str, amount_agorot: int, text: str, charge_agorot: int) -> bool:
    """A declared payment and a charge in the files are one payment ("Coming up" rule)."""
    named = bool(name.strip()) and name.casefold() in text.casefold()
    return amount_agorot == charge_agorot or named


@dataclass(frozen=True)
class Charge:
    """One expense row of the month from the files; the amount is positive."""

    text: str
    bucket: str
    amount_agorot: int
    installment: bool = False  # a payment of a card installment deal
    category: str = ""


@dataclass(frozen=True)
class DueItem:
    kind: str  # COMMITMENT or CARD
    name: str
    bucket: str
    amount_agorot: int


@dataclass(frozen=True)
class Due:
    """Per bucket: still due, already charged, and charged outside the pace (a
    commitment's payment the files put in a group outside the pace, to be added to the
    commitment's own group, so it still counts against what was allowed for it). Only
    buckets in the pace."""

    items: tuple[DueItem, ...] = ()
    due: dict[str, int] = field(default_factory=dict)
    fixed_spent: dict[str, int] = field(default_factory=dict)
    outside: dict[str, int] = field(default_factory=dict)

    @property
    def total_agorot(self) -> int:
        return sum(self.due.values())


def _add(into: dict[str, int], bucket: str, amount: int) -> None:
    into[bucket] = into.get(bucket, 0) + amount


def still_due(
    commitments: Sequence[Commitment],
    month: str,
    charges: Sequence[Charge],
    pace_buckets: Collection[str],
) -> Due:
    """Split the month's fixed payments into still due and already charged."""
    free = [c for c in charges if c.amount_agorot > 0]
    items: list[DueItem] = []
    due: dict[str, int] = {}
    fixed: dict[str, int] = {}
    outside: dict[str, int] = {}

    for item in commitments:
        if item.bucket is None or item.bucket not in pace_buckets:
            continue
        if not item.first_month <= month <= item.last_month:
            continue
        # A card installment first, then a charge with the name, then the same amount.
        order = sorted(
            (c for c in free if same_payment(item.name, item.amount_agorot, c.text,
                                             c.amount_agorot)),
            key=lambda c: (not c.installment, item.name.casefold() not in c.text.casefold()),
        )  # fmt: skip
        if order:
            twin = order[0]
            free.remove(twin)
            if twin.bucket in pace_buckets:
                _add(fixed, twin.bucket, twin.amount_agorot)
            else:  # charged outside the pace: counted against the commitment's group
                _add(fixed, item.bucket, twin.amount_agorot)
                _add(outside, item.bucket, twin.amount_agorot)
            continue
        _add(due, item.bucket, item.amount_agorot)
        items.append(DueItem(COMMITMENT, item.name, item.bucket, item.amount_agorot))
    for charge in free:  # the other card installments: spending, and fixed for the colour
        if charge.installment and charge.bucket in pace_buckets:
            _add(fixed, charge.bucket, charge.amount_agorot)
    items.sort(key=lambda i: -i.amount_agorot)
    return Due(tuple(items), due, fixed, outside)
