"""What-if scenarios: named lists of changes to the baseline, loaded from YAML."""

import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

from fin.logic.errors import ConfigError
from fin.logic.money import to_agorot

LEVEL = "level"
BUCKET_SET = "set"
BUCKET_CHANGE = "change"
INCOME = "income"
RECEIVED = "received"
EVENT = "event"
_KINDS = (LEVEL, BUCKET_SET, BUCKET_CHANGE, INCOME, RECEIVED, EVENT)

MEDIAN = "median"
SECOND_LOWEST = "second_lowest"
LEVELS = frozenset({MEDIAN, SECOND_LOWEST})

_MONTH = re.compile(r"\d{4}-(0[1-9]|1[0-2])")
_PREFIX = "scenarios config"


@dataclass(frozen=True)
class Change:
    """One change to the baseline.

    kind LEVEL: bring a measured bucket (or all of them) to a level it already
    reached in the window. BUCKET_SET / BUCKET_CHANGE: a bucket at a fixed amount,
    or moved by an amount. INCOME: monthly net income moved by an amount.
    RECEIVED: drop the money received from people. EVENT: a one-time amount.
    """

    kind: str
    bucket: str | None = None
    level: str | None = None
    # Shekel amounts in agorot; signed for BUCKET_CHANGE, INCOME and EVENT.
    amount_agorot: int | None = None
    first_month: str | None = None
    last_month: str | None = None
    label: str = ""


@dataclass(frozen=True)
class Scenario:
    name: str
    changes: tuple[Change, ...]


def parse_scenarios(documents: Sequence[tuple[Any, str]]) -> tuple[Scenario, ...]:
    """Validate scenario documents, given as (content, where it came from); names must be unique."""
    scenarios: list[Scenario] = []
    for raw, path in documents:
        scenarios.extend(_parse_document(raw, path))
    names = [scenario.name for scenario in scenarios]
    duplicates = sorted({name for name in names if names.count(name) > 1})
    if duplicates:
        raise ConfigError(f"{_PREFIX}: duplicate scenario name: {', '.join(duplicates)}")
    return tuple(scenarios)


def _parse_document(raw: Any, path: str) -> list[Scenario]:
    if raw is None:
        return []
    items = raw.get("scenarios") if isinstance(raw, dict) else None
    if not isinstance(items, list):
        raise ConfigError(f"{_PREFIX}: 'scenarios' must be a list: {path}")
    return [_scenario(item, f"scenarios[{index}]") for index, item in enumerate(items)]


def _scenario(item: Any, name: str) -> Scenario:
    if not isinstance(item, dict):
        raise ConfigError(f"{_PREFIX}: {name} must be a mapping")
    title, changes = item.get("name"), item.get("changes")
    if not isinstance(title, str) or not title:
        raise ConfigError(f"{_PREFIX}: {name}.name is missing")
    if not isinstance(changes, list) or not changes:
        raise ConfigError(f"{_PREFIX}: {name}.changes must be a non-empty list")
    return Scenario(
        title, tuple(_change(c, f"{name}.changes[{index}]") for index, c in enumerate(changes))
    )


def _change(item: Any, name: str) -> Change:
    if not isinstance(item, dict):
        raise ConfigError(f"{_PREFIX}: {name} must be a mapping")
    kinds = [kind for kind in _KINDS if kind in item]
    if len(kinds) != 1:
        raise ConfigError(f"{_PREFIX}: {name} needs exactly one of: {', '.join(_KINDS)}")
    kind = kinds[0]
    value = item[kind]
    bucket = item.get("bucket")
    if bucket is not None and (not isinstance(bucket, str) or not bucket):
        raise ConfigError(f"{_PREFIX}: {name}.bucket must be a bucket name")
    first, last = (
        _month(item.get("from"), f"{name}.from"),
        _month(item.get("until"), f"{name}.until"),
    )
    if first and last and first > last:
        raise ConfigError(f"{_PREFIX}: {name}.from must not be after until")
    label = str(item.get("label") or "")
    if kind == LEVEL:
        if value not in LEVELS:
            raise ConfigError(
                f"{_PREFIX}: {name}.level must be one of: {', '.join(sorted(LEVELS))}"
            )
        return Change(LEVEL, bucket, value, None, first, last, label)
    if kind == RECEIVED:
        if value is not False:
            raise ConfigError(f"{_PREFIX}: {name}.received must be false")
        return Change(RECEIVED, None, None, None, first, last, label)
    amount = _amount(value, f"{name}.{kind}")
    if kind in (BUCKET_SET, BUCKET_CHANGE):
        if bucket is None:
            raise ConfigError(f"{_PREFIX}: {name} needs a bucket")
        if kind == BUCKET_SET and amount < 0:
            raise ConfigError(f"{_PREFIX}: {name}.set must not be negative")
        return Change(kind, bucket, None, amount, first, last, label)
    if amount == 0:
        raise ConfigError(f"{_PREFIX}: {name}.{kind} must not be zero")
    if kind == EVENT:
        month = _month(item.get("month"), f"{name}.month")
        if month is None or not label:
            raise ConfigError(f"{_PREFIX}: {name} needs a month and a label")
        return Change(EVENT, None, None, amount, month, month, label)
    return Change(INCOME, None, None, amount, first, last, label)


def _amount(value: Any, name: str) -> int:
    try:
        return to_agorot(value)
    except (TypeError, ValueError) as exc:
        raise ConfigError(f"{_PREFIX}: {name} is not a money amount") from exc


def _month(value: Any, name: str) -> str | None:
    if value is None:
        return None
    text = str(value)
    if not _MONTH.fullmatch(text):
        raise ConfigError(f"{_PREFIX}: {name} must be YYYY-MM")
    return text
