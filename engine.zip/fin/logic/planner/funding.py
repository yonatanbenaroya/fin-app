"""Goals, second version: each goal has its own pot, funded month by month (design.md §6
"Goals, second version", spec v0.40). Pure and deterministic, integer agorot only.

The order of the list is the priority. Every month with a positive surplus, the list is
walked in order: a goal flagged "goes first" that is not reached takes all that is left
of the surplus, and the goals below it wait for the next month; any other goal takes its
fixed monthly amount (or what is left, or what it still misses, whichever is smaller).
What is left of the surplus stays in the account. A month with no surplus moves nothing.

A back-to-zero goal (the overdraft) has a target of zero and its pot starts at the
balance when that is negative. A positive starting balance is shared out to the goals in
list order, up to each target, as the first version counted it.
"""

from collections.abc import Sequence
from dataclasses import dataclass

from fin.logic.planner.goals_config import Goal, GoalsConfig
from fin.logic.planner.projection import months_between, project

AMOUNT = "amount"
MONTHS = "months"
ZERO = "zero"
HORIZON_MONTHS = 72  # a goal not reached within six years gets no expected month
NEEDS_STEP_AGOROT = 5000  # "needs ₪X a month" rounds up to 50 shekels


def goal_kind(goal: Goal) -> str:
    if goal.amount_agorot:
        return AMOUNT
    return MONTHS if goal.months_of_spend else ZERO


def goes_first(goal: Goal) -> bool:
    """The goal's flag, or the default: a back-to-zero goal goes first."""
    return goal.first if goal.first is not None else goal_kind(goal) == ZERO


def target_agorot(goal: Goal, typical_month_agorot: int) -> int:
    kind = goal_kind(goal)
    if kind == AMOUNT:
        return goal.amount_agorot
    return goal.months_of_spend * typical_month_agorot if kind == MONTHS else 0


@dataclass(frozen=True)
class GoalPlan:
    name: str
    kind: str
    target_agorot: int
    first: bool
    monthly_agorot: int
    # What the goal holds now (for back to zero: the balance, negative while overdrawn).
    saved_agorot: int
    reached: bool  # reached already, now
    expected: str | None  # the month it is reached; None when reached already or not in 6 years
    waits_for: str | None  # the goal above it that goes first and is not reached yet
    by: str | None
    late_months: int | None  # months after `by`; None when on time, or late with no month
    late: bool
    needs_monthly_agorot: int | None  # only when late: the gap spread up to `by`

    @property
    def left_agorot(self) -> int:
        return max(0, self.target_agorot - self.saved_agorot)


def _ceil(value: int, step: int) -> int:
    return -(-value // step) * step


def fund_goals(
    goals: Sequence[Goal],
    surpluses: Sequence[tuple[str, int]],
    start_balance_agorot: int,
    typical_month_agorot: int,
) -> tuple[GoalPlan, ...]:
    """Simulate the goals over the months of `surpluses` ((month, surplus), in order)."""
    targets = [target_agorot(g, typical_month_agorot) for g in goals]
    firsts = [goes_first(g) for g in goals]
    pots: list[int] = []
    spare = max(0, start_balance_agorot)
    for goal, target in zip(goals, targets, strict=True):
        if goal_kind(goal) == ZERO:
            pots.append(min(0, start_balance_agorot))
        else:
            take = min(spare, target)
            pots.append(take)
            spare -= take
    now = list(pots)
    done = [pot >= target for pot, target in zip(pots, targets, strict=True)]
    reached_now = list(done)
    expected: list[str | None] = [None] * len(goals)
    waits: list[str | None] = []
    blocker: str | None = None
    for index, goal in enumerate(goals):
        waits.append(blocker)
        if firsts[index] and not done[index] and blocker is None:
            blocker = goal.name
    for month, surplus in surpluses[:HORIZON_MONTHS]:
        if surplus <= 0:
            continue
        left = surplus
        for index, goal in enumerate(goals):
            if done[index]:
                continue
            need = targets[index] - pots[index]
            cap = left if firsts[index] else min(goal.monthly_agorot, left)
            give = min(cap, need)
            pots[index] += give
            left -= give
            if pots[index] >= targets[index]:
                done[index] = True
                expected[index] = month
            if firsts[index]:
                break  # the goals below wait, also in the month it is reached
    first_month = surpluses[0][0] if surpluses else None
    plans = []
    for index, goal in enumerate(goals):
        late, late_months, needs = False, None, None
        if goal.by and not reached_now[index] and goal_kind(goal) != ZERO:
            when = expected[index]
            if when is None or when > goal.by:
                late = True
                late_months = None if when is None else months_between(goal.by, when)
                months = (
                    1 if first_month is None else max(1, months_between(first_month, goal.by) + 1)
                )
                gap = targets[index] - now[index]
                needs = _ceil(-(-gap // months), NEEDS_STEP_AGOROT)
        plans.append(
            GoalPlan(
                name=goal.name, kind=goal_kind(goal), target_agorot=targets[index],
                first=firsts[index], monthly_agorot=goal.monthly_agorot, saved_agorot=now[index],
                reached=reached_now[index], expected=expected[index],
                waits_for=None if reached_now[index] else waits[index], by=goal.by,
                late_months=late_months, late=late, needs_monthly_agorot=needs,
            )
        )  # fmt: skip
    return tuple(plans)


def over_committed(goals: Sequence[GoalPlan], surplus_agorot: int) -> int:
    """How much the monthly amounts of the goals still funded go over the surplus (0 if not)."""
    asked = sum(g.monthly_agorot for g in goals if not g.first and not g.reached)
    return max(0, asked - max(0, surplus_agorot))


@dataclass(frozen=True)
class GoalsAhead:
    """The goals funded from the projected end of the current month (spec v0.40)."""

    plans: tuple[GoalPlan, ...]
    # The balance the overdraft axis shows and the simulation starts from: the projected
    # end of the current month (the last full month's closing balance plus this month's
    # projected flow), so it does not jump on payday.
    balance_agorot: int
    balance_month: str
    first_month: str
    over_committed_agorot: int


def plan_goals(
    config: GoalsConfig,
    base_flow_agorot: int,
    typical_month_agorot: int,
    data_month: str,
    window_months: Sequence[str],
    latest_balance_agorot: int,
    last_month_end_agorot: int | None,
) -> GoalsAhead:
    """Project the current month and six years after it, then fund the goals."""
    months = project(
        0, data_month, base_flow_agorot, HORIZON_MONTHS + 1, config.commitments,
        config.events, window_months,
    )  # fmt: skip
    if last_month_end_agorot is None:  # no closing balance in the files: the latest one
        balance = latest_balance_agorot
    else:
        balance = last_month_end_agorot + months[0].flow_agorot
    surpluses = [(m.month, m.flow_agorot) for m in months[1:]]
    plans = fund_goals(config.goals, surpluses, balance, typical_month_agorot)
    return GoalsAhead(
        plans, balance, data_month, surpluses[0][0], over_committed(plans, base_flow_agorot)
    )
