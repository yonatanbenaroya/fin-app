"""Monthly budget: a spending ceiling per bucket that keeps the cash flow positive.

Pure and deterministic. Declared lines (rent, the reserve) and dated
commitments are taken as given; the ceilings cover the measured buckets.
"""

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from fin.logic.errors import ConfigError
from fin.logic.money import AGOROT_PER_SHEKEL
from fin.logic.planner.baseline import MEAN, RESERVE_LINE, Baseline
from fin.logic.planner.goals_config import Commitment
from fin.logic.planner.scenarios import second_lowest_agorot
from fin.logic.summary import MonthSummary

DEFAULT_TARGET_SURPLUS_AGOROT = 500 * AGOROT_PER_SHEKEL


@dataclass(frozen=True)
class BudgetLine:
    bucket: str
    baseline_agorot: int
    # The bucket's second-lowest month in the baseline window.
    lean_agorot: int
    ceiling_agorot: int

    @property
    def cut_agorot(self) -> int:
        """How far the ceiling is below the baseline mean (negative: above it)."""
        return self.baseline_agorot - self.ceiling_agorot


@dataclass(frozen=True)
class Budget:
    month: str
    income_agorot: int
    received_agorot: int
    # Declared lines that the budget does not touch: (label, monthly amount).
    fixed: tuple[tuple[str, int], ...]
    # Dated commitments active in the month: (name, monthly amount).
    commitments: tuple[tuple[str, int], ...]
    target_surplus_agorot: int
    lines: tuple[BudgetLine, ...]

    @property
    def ceilings_agorot(self) -> int:
        return sum(line.ceiling_agorot for line in self.lines)

    @property
    def cash_flow_agorot(self) -> int:
        """What is left each month when every bucket is spent up to its ceiling."""
        taken = sum(amount for _, amount in (*self.fixed, *self.commitments))
        return self.income_agorot + self.received_agorot - taken - self.ceilings_agorot

    @property
    def positive(self) -> bool:
        return self.cash_flow_agorot > 0

    @property
    def meets_target(self) -> bool:
        return self.cash_flow_agorot >= self.target_surplus_agorot


@dataclass(frozen=True)
class TrackLine:
    bucket: str
    spent_agorot: int
    ceiling_agorot: int

    @property
    def remaining_agorot(self) -> int:
        """Left until the ceiling; negative when the bucket is over it."""
        return self.ceiling_agorot - self.spent_agorot


def _active(commitments: Sequence[Commitment], month: str) -> tuple[Commitment, ...]:
    return tuple(c for c in commitments if c.first_month <= month <= c.last_month)


def _build(
    baseline: Baseline,
    commitments: Sequence[Commitment],
    month: str,
    target_surplus_agorot: int,
    ceilings: Mapping[str, int],
) -> Budget:
    measured = {line.bucket: line for line in baseline.lines if line.basis == MEAN}
    lines = [
        BudgetLine(
            bucket,
            line.amount_agorot,
            second_lowest_agorot(line.monthly_agorot),
            ceilings.get(bucket, line.amount_agorot),
        )
        for bucket, line in measured.items()
    ]
    # A ceiling for a bucket with no history is still part of the plan.
    lines.extend(
        BudgetLine(bucket, 0, 0, amount)
        for bucket, amount in ceilings.items()
        if bucket not in measured
    )
    return Budget(
        month=month,
        income_agorot=baseline.income_agorot,
        received_agorot=baseline.received_agorot,
        fixed=tuple(
            (line.bucket, line.amount_agorot) for line in baseline.lines if line.basis != MEAN
        ),
        commitments=tuple((c.name, c.amount_agorot) for c in _active(commitments, month)),
        target_surplus_agorot=target_surplus_agorot,
        lines=tuple(lines),
    )


def budget_from_ceilings(
    baseline: Baseline,
    commitments: Sequence[Commitment],
    month: str,
    target_surplus_agorot: int,
    ceilings: Mapping[str, int],
) -> Budget:
    """The budget that a saved set of ceilings gives against today's baseline.

    A measured bucket without a ceiling counts at its baseline mean.
    """
    return _build(baseline, commitments, month, target_surplus_agorot, ceilings)


def propose_budget(
    baseline: Baseline,
    commitments: Sequence[Commitment],
    month: str,
    target_surplus_agorot: int = DEFAULT_TARGET_SURPLUS_AGOROT,
) -> Budget:
    """Propose ceilings that leave at least the target surplus.

    Every measured bucket keeps the same share of its baseline mean: the
    money available divided by what the buckets cost today. A bucket's lean
    month is not used for the split, because for a bucket that jumps around it
    is an almost empty month, not a level one can live at. Ceilings are rounded
    down to whole shekels, so the target always holds.
    """
    empty = _build(baseline, commitments, month, target_surplus_agorot, {})
    available = empty.cash_flow_agorot + empty.ceilings_agorot - target_surplus_agorot
    if available <= 0:
        raise ConfigError(
            "budget: income does not cover rent, commitments and the target surplus;"
            " there is nothing left to divide between the buckets"
        )
    start = {line.bucket: line.baseline_agorot for line in empty.lines if line.baseline_agorot > 0}
    total = sum(start.values())
    ceilings = {}
    for bucket, level in start.items():
        share = level if total <= available else level * available // total
        ceilings[bucket] = share // AGOROT_PER_SHEKEL * AGOROT_PER_SHEKEL
    return _build(baseline, commitments, month, target_surplus_agorot, ceilings)


def effective_ceilings(
    ceilings: Mapping[str, int],
    fixed: Mapping[str, int],
    commitments: Sequence[Commitment],
    month: str,
) -> dict[str, int]:
    """What each bucket may show in a given month.

    The saved ceilings, the declared buckets at their declared amount, and
    on top of a bucket's ceiling every commitment that is charged to it.
    """
    result = {**fixed, **ceilings}
    for item in _active(commitments, month):
        if item.bucket is not None:
            result[item.bucket] = result.get(item.bucket, 0) + item.amount_agorot
    result.pop(RESERVE_LINE, None)
    return result


def track_month(ceilings: Mapping[str, int], month: MonthSummary) -> tuple[TrackLine, ...]:
    """Spending so far in a month against the ceilings, largest ceiling first."""
    spent = {line.bucket: line.spent_agorot for line in month.buckets}
    lines = [
        TrackLine(bucket, spent.get(bucket, 0), ceilings.get(bucket, 0))
        for bucket in set(spent) | set(ceilings)
    ]
    return tuple(sorted(lines, key=lambda line: (-line.ceiling_agorot, line.bucket)))
