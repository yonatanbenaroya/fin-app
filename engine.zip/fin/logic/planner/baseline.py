"""Current-state baseline: the typical month from now on.

Declared values (today's rent, today's net income) win over history; every
other bucket is the mean of the recent full months, with one-time expenses
left out. Pure and deterministic: integer agorot in, integer agorot out.
"""

from collections.abc import Sequence
from dataclasses import dataclass

from fin.logic.errors import ConfigError
from fin.logic.money import mean_agorot
from fin.logic.planner.baseline_config import BaselineConfig, OneOff
from fin.logic.summary import MonthSummary

DECLARED = "declared"
MEAN = "mean"
# The line that holds the declared allowance for irregular expenses.
RESERVE_LINE = "reserve for irregular expenses"
DEFAULT_WINDOW_MONTHS = 6


@dataclass(frozen=True)
class BaselineLine:
    bucket: str
    amount_agorot: int
    # DECLARED or MEAN: where the amount comes from.
    basis: str
    # Measured in the window, after leaving out one-time expenses.
    window_mean_agorot: int
    last_month_agorot: int
    # The bucket's spend in each window month, one-time expenses left out.
    monthly_agorot: tuple[int, ...] = ()


@dataclass(frozen=True)
class Baseline:
    first_month: str
    last_month: str
    months: int
    lines: tuple[BaselineLine, ...]
    income_agorot: int
    income_basis: str
    income_window_mean_agorot: int
    income_last_month_agorot: int
    # Mean money received from people in the window; not guaranteed income.
    received_agorot: int
    # One-time expenses that were left out of the window means.
    one_offs: tuple[OneOff, ...]

    @property
    def spend_agorot(self) -> int:
        return sum(line.amount_agorot for line in self.lines)

    @property
    def cash_flow_agorot(self) -> int:
        """Income plus money received from people, minus spending."""
        return self.income_agorot + self.received_agorot - self.spend_agorot

    @property
    def cash_flow_without_received_agorot(self) -> int:
        """The cash flow when nobody pays anything back."""
        return self.income_agorot - self.spend_agorot


def baseline_window(
    months: Sequence[MonthSummary], last_data_month: str, count: int = DEFAULT_WINDOW_MONTHS
) -> tuple[MonthSummary, ...]:
    """Pick the latest `count` full months.

    The month of the newest transaction is treated as partial and left out.
    """
    if count <= 0:
        raise ValueError("count must be positive")
    full = sorted((m for m in months if m.month < last_data_month), key=lambda m: m.month)
    return tuple(full[-count:])


def build_baseline(window: Sequence[MonthSummary], config: BaselineConfig) -> Baseline | None:
    """Build the baseline from the window months; None when the window is empty."""
    if not window:
        return None
    count = len(window)
    position = {month.month: index for index, month in enumerate(window)}
    series: dict[str, list[int]] = {}
    for index, month in enumerate(window):
        for line in month.buckets:
            series.setdefault(line.bucket, [0] * count)[index] += line.spent_agorot
    applied = []
    for item in config.one_off:
        index = position.get(item.month)
        if index is None:
            continue  # outside the window: it does not affect the means anyway
        if item.amount_agorot > series.get(item.bucket, [0] * count)[index]:
            raise ConfigError(
                f"baseline config: one-off in {item.month} is larger than what was spent"
                f" in bucket {item.bucket!r} that month"
            )
        series[item.bucket][index] -= item.amount_agorot
        applied.append(item)
    last = window[-1]
    last_spent = {line.bucket: line.spent_agorot for line in last.buckets}
    lines = []
    for bucket in set(series) | set(config.fixed):
        monthly = tuple(series.get(bucket, [0] * count))
        measured = mean_agorot(sum(monthly), count)
        declared = config.fixed.get(bucket)
        lines.append(
            BaselineLine(
                bucket=bucket,
                amount_agorot=measured if declared is None else declared,
                basis=MEAN if declared is None else DECLARED,
                window_mean_agorot=measured,
                last_month_agorot=last_spent.get(bucket, 0),
                monthly_agorot=monthly,
            )
        )
    lines.sort(key=lambda line: (-line.amount_agorot, line.bucket))
    if config.irregular_reserve_agorot:
        reserve = config.irregular_reserve_agorot
        lines.append(BaselineLine(RESERVE_LINE, reserve, DECLARED, 0, 0, (0,) * count))
    income_mean = mean_agorot(sum(m.net_income_agorot or 0 for m in window), count)
    declared_income = config.net_income_agorot
    return Baseline(
        first_month=window[0].month,
        last_month=last.month,
        months=count,
        lines=tuple(lines),
        income_agorot=income_mean if declared_income is None else declared_income,
        income_basis=MEAN if declared_income is None else DECLARED,
        income_window_mean_agorot=income_mean,
        income_last_month_agorot=last.net_income_agorot or 0,
        received_agorot=mean_agorot(sum(m.transfers_in_agorot for m in window), count),
        one_offs=tuple(applied),
    )
