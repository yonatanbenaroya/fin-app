"""The balance projection with its goals, shared by `fin goals`, `fin what-if` and the screens.

Pure: the caller hands in the baseline, the goals configuration and the
starting balance; nothing is read here.
"""

from collections.abc import Sequence
from dataclasses import dataclass

from fin.logic.planner.baseline import Baseline
from fin.logic.planner.goals import (
    ALREADY,
    GoalStatus,
    evaluate_goals,
    first_limit_breach,
    required_horizon,
)
from fin.logic.planner.goals_config import Event, GoalsConfig
from fin.logic.planner.projection import Adjustment, ProjectedMonth, add_months, project


@dataclass(frozen=True)
class Outlook:
    first_month: str
    base_flow_agorot: int
    projection: tuple[ProjectedMonth, ...]
    statuses: tuple[GoalStatus, ...]
    limit_breach_month: str | None


def build_outlook(
    baseline: Baseline,
    goals: GoalsConfig,
    start_balance_agorot: int,
    data_month: str,
    window_months: Sequence[str],
    adjustments: Sequence[Adjustment] = (),
    events: Sequence[Event] = (),
) -> Outlook:
    """Project from the month after the newest data month and evaluate the goals.

    `events` come on top of the configured timeline events (for a scenario or a
    purchase being considered).
    """
    first_month = add_months(data_month, 1)
    base_flow = baseline.cash_flow_agorot
    projection = project(
        start_balance_agorot,
        first_month,
        base_flow,
        required_horizon(first_month, goals.goals, goals.horizon_months),
        goals.commitments,
        (*goals.events, *events),
        window_months,
        adjustments,
    )
    limit = goals.overdraft_limit_agorot
    return Outlook(
        first_month=first_month,
        base_flow_agorot=base_flow,
        projection=projection,
        statuses=evaluate_goals(
            projection, goals.goals, start_balance_agorot, baseline.spend_agorot
        ),
        limit_breach_month=None if limit is None else first_limit_breach(projection, limit),
    )


def goal_progress(statuses: Sequence[GoalStatus], balance_agorot: int) -> tuple[int, ...]:
    """How far today's balance is through each goal's own step, in whole percent.

    Goals are cumulative: a goal's step runs from the previous goal's threshold
    to its own. A step of zero (getting back to a zero balance) is 0 or 100.
    """
    progress = []
    floor = None
    for status in statuses:
        start = status.threshold_agorot if floor is None else floor
        if status.reached == ALREADY or balance_agorot >= status.threshold_agorot:
            progress.append(100)
        elif status.threshold_agorot <= start or balance_agorot <= start:
            progress.append(0)
        else:
            progress.append((balance_agorot - start) * 100 // (status.threshold_agorot - start))
        floor = status.threshold_agorot
    return tuple(progress)
