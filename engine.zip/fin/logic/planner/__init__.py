"""Goal planning and what-if simulations."""
