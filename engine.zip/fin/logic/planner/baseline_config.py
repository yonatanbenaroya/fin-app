"""Declared values for the current-state baseline, loaded from a private YAML file."""

import re
from dataclasses import dataclass, field
from typing import Any

from fin.logic.errors import ConfigError
from fin.logic.money import to_agorot

_MONTH = re.compile(r"\d{4}-(0[1-9]|1[0-2])")


@dataclass(frozen=True)
class OneOff:
    """A one-time expense that must not shape the monthly baseline."""

    month: str
    bucket: str
    amount_agorot: int
    note: str = ""


@dataclass(frozen=True)
class BaselineConfig:
    # Declared monthly net income; None means "use the measured mean".
    net_income_agorot: int | None = None
    # Bucket -> declared monthly amount (positive agorot).
    fixed: dict[str, int] = field(default_factory=dict)
    one_off: tuple[OneOff, ...] = ()
    # Monthly allowance for irregular expenses: one-time costs are left out of the
    # means, but something like them will happen again.
    irregular_reserve_agorot: int = 0


def parse_baseline_config(raw: Any, path: str = "") -> BaselineConfig:
    """Validate the declared baseline values; an empty document declares nothing."""
    if raw is None:
        return BaselineConfig()
    if not isinstance(raw, dict):
        raise ConfigError(f"baseline config root must be a mapping: {path}")
    income = raw.get("net_income")
    fixed = raw.get("fixed") or {}
    one_off = raw.get("one_off") or []
    reserve = raw.get("irregular_reserve")
    if not isinstance(fixed, dict) or not isinstance(one_off, list):
        raise ConfigError(f"baseline config: 'fixed' is a mapping and 'one_off' a list: {path}")
    return BaselineConfig(
        net_income_agorot=None if income is None else _positive(income, "net_income"),
        fixed={
            str(bucket): _positive(amount, f"fixed.{bucket}") for bucket, amount in fixed.items()
        },
        one_off=tuple(_one_off(item, index) for index, item in enumerate(one_off)),
        irregular_reserve_agorot=0 if reserve is None else _positive(reserve, "irregular_reserve"),
    )


def _positive(value: Any, name: str) -> int:
    try:
        agorot = to_agorot(value)
    except (TypeError, ValueError) as exc:
        raise ConfigError(f"baseline config: {name} is not a money amount") from exc
    if agorot <= 0:
        raise ConfigError(f"baseline config: {name} must be positive")
    return agorot


def _one_off(item: Any, index: int) -> OneOff:
    name = f"one_off[{index}]"
    if not isinstance(item, dict):
        raise ConfigError(f"baseline config: {name} must be a mapping")
    month, bucket = str(item.get("month", "")), item.get("bucket")
    if not _MONTH.fullmatch(month):
        raise ConfigError(f"baseline config: {name}.month must be YYYY-MM")
    if not isinstance(bucket, str) or not bucket:
        raise ConfigError(f"baseline config: {name}.bucket is missing")
    return OneOff(
        month, bucket, _positive(item.get("amount"), f"{name}.amount"), str(item.get("note") or "")
    )
