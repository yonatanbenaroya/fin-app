"""Pace within a month: how much is left, per day, and whether spending runs ahead.

Pure and deterministic, integer agorot only. "Even pace" is the share of the
ceiling that a perfectly steady month would have spent by this day.
"""

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date, timedelta

ON_TRACK = "on_track"
TIGHT = "tight"
OVER = "over"

# The pace level shown on Home (design.md §2 "Status colour"): the ratio of the share of
# the budget spent to the share of the month gone by, in thousandths. Decided 2026-11-17.
ON_TRACK_MAX_PERMILLE = 1000
FAST_MAX_PERMILLE = 1150
LEVEL_ON_TRACK = "on_track"
LEVEL_FAST = "fast"
LEVEL_OVER = "over_pace"


@dataclass(frozen=True)
class Pace:
    spent_agorot: int
    ceiling_agorot: int
    # The day the pace is measured on (today, see pace_day), and the length of that month.
    day: int
    days_in_month: int

    def __post_init__(self) -> None:
        if not 1 <= self.day <= self.days_in_month:
            raise ValueError("day must fall inside the month")

    @property
    def remaining_agorot(self) -> int:
        """Left until the ceiling; negative when over it."""
        return self.ceiling_agorot - self.spent_agorot

    @property
    def days_left(self) -> int:
        """Days after `day` until the end of the month."""
        return self.days_in_month - self.day

    @property
    def daily_allowance_agorot(self) -> int:
        """What can be spent per remaining day, rounded down; 0 when nothing is left."""
        if self.remaining_agorot <= 0:
            return 0
        return self.remaining_agorot // max(self.days_left, 1)

    @property
    def spent_percent(self) -> int:
        """Share of the ceiling spent, in whole percent, rounded down (can exceed 100)."""
        if self.ceiling_agorot <= 0:
            return 0 if self.spent_agorot <= 0 else 100
        return max(0, self.spent_agorot) * 100 // self.ceiling_agorot

    @property
    def even_percent(self) -> int:
        """Share of the month gone by, in whole percent, rounded down."""
        return self.day * 100 // self.days_in_month

    @property
    def ratio_permille(self) -> int | None:
        """Share of the budget spent over share of the month gone by, in thousandths.

        1000 is exactly even pace. Rounded down. None without a positive ceiling.
        """
        if self.ceiling_agorot <= 0:
            return None
        spent = max(0, self.spent_agorot)
        return spent * self.days_in_month * 1000 // (self.ceiling_agorot * self.day)

    @property
    def level(self) -> str | None:
        """LEVEL_ON_TRACK up to 1.000, LEVEL_FAST up to 1.150, else LEVEL_OVER.

        None without a ceiling.
        """
        ratio = self.ratio_permille
        if ratio is None:
            return None
        if ratio <= ON_TRACK_MAX_PERMILLE:
            return LEVEL_ON_TRACK
        return LEVEL_FAST if ratio <= FAST_MAX_PERMILLE else LEVEL_OVER

    @property
    def status(self) -> str:
        """OVER past the ceiling, TIGHT ahead of even pace, else ON_TRACK."""
        if self.spent_agorot > self.ceiling_agorot:
            return OVER
        if self.spent_agorot * self.days_in_month > self.ceiling_agorot * self.day:
            return TIGHT
        return ON_TRACK


def month_pace(
    ceilings: Mapping[str, int],
    spent: Mapping[str, int],
    day: int,
    days_in_month: int,
) -> tuple[Pace, dict[str, Pace]]:
    """The pace of the whole budget and of each budgeted bucket.

    Only buckets with a ceiling count; spending in a bucket without one is not
    part of the pace (it shows up in the categories screen instead).
    """
    buckets = {
        bucket: Pace(spent.get(bucket, 0), ceiling, day, days_in_month)
        for bucket, ceiling in ceilings.items()
    }
    total = Pace(
        sum(p.spent_agorot for p in buckets.values()),
        sum(p.ceiling_agorot for p in buckets.values()),
        day,
        days_in_month,
    )
    return total, buckets


@dataclass(frozen=True)
class PaceDay:
    """Where in which month the pace is measured (design.md §6, "Dates").

    Days left, the daily allowance and the dot on the month line count from
    today on the device. Spending is as of the latest data, so in a month the
    data does not reach yet (`has_data` False) nothing is spent so far.
    """

    month: str  # "YYYY-MM"
    day: int
    days_in_month: int
    has_data: bool  # the latest data falls in this month
    stale: bool  # the latest data is older than today


def days_in(year: int, month: int) -> int:
    first_next = date(year + month // 12, month % 12 + 1, 1)
    return (first_next - timedelta(days=1)).day


def pace_day(data_date: date, today: date) -> PaceDay:
    """The month and day to measure the pace on, given today and the latest data.

    A device clock behind the data (today earlier than the data) falls back to
    the data's date, so a wrong clock never makes days run backwards.
    """
    when = max(today, data_date)
    same_month = (when.year, when.month) == (data_date.year, data_date.month)
    return PaceDay(
        f"{when.year:04d}-{when.month:02d}",
        when.day,
        days_in(when.year, when.month),
        same_month,
        data_date < today,
    )
