"""Progress toward goals, read off a balance projection. Pure and deterministic.

Goals are cumulative steps on the bank balance, in priority order: each goal
is reached when the balance covers it and every goal before it.
"""

from collections.abc import Sequence
from dataclasses import dataclass

from fin.logic.planner.goals_config import Goal
from fin.logic.planner.projection import ProjectedMonth, months_between

ALREADY = "already"


@dataclass(frozen=True)
class GoalStatus:
    name: str
    # The balance at which the goal (and all earlier ones) is covered.
    threshold_agorot: int
    # First projected month that ends at or above the threshold; ALREADY when
    # the starting balance covers it; None when the projection never gets there.
    reached: str | None
    # The month the requirement below is measured at: the goal's own target
    # month, or the last projected month when the goal has none.
    target_month: str
    dated: bool
    projected_agorot: int
    # Extra cash flow needed every month to be at the threshold by target_month.
    required_monthly_agorot: int
    # The same two figures for the goal's smaller acceptable amount, if it has one.
    minimum_threshold_agorot: int | None = None
    minimum_required_monthly_agorot: int | None = None


def required_horizon(first_month: str, goals: Sequence[Goal], default: int) -> int:
    """The number of months to project so that every dated goal is covered."""
    furthest = max((months_between(first_month, g.by) + 1 for g in goals if g.by), default=0)
    return max(default, furthest)


def evaluate_goals(
    projection: Sequence[ProjectedMonth],
    goals: Sequence[Goal],
    start_balance_agorot: int,
    monthly_spend_agorot: int,
) -> tuple[GoalStatus, ...]:
    """Evaluate each goal against the projection, in priority order."""
    if not projection:
        raise ValueError("projection is empty")
    by_month = {month.month: index for index, month in enumerate(projection)}
    statuses = []
    covered = 0
    for goal in goals:
        base = covered
        covered += goal.amount_agorot + goal.months_of_spend * monthly_spend_agorot
        if start_balance_agorot >= covered:
            reached: str | None = ALREADY
        else:
            reached = next((m.month for m in projection if m.balance_agorot >= covered), None)
        # A target month that is already behind us is measured at the first month.
        index = by_month.get(goal.by, 0) if goal.by else len(projection) - 1
        at_target = projection[index].balance_agorot
        minimum = None if goal.minimum_agorot is None else base + goal.minimum_agorot
        statuses.append(
            GoalStatus(
                name=goal.name,
                threshold_agorot=covered,
                reached=reached,
                target_month=projection[index].month,
                dated=goal.by is not None,
                projected_agorot=at_target,
                required_monthly_agorot=_per_month(covered - at_target, index + 1),
                minimum_threshold_agorot=minimum,
                minimum_required_monthly_agorot=(
                    None if minimum is None else _per_month(minimum - at_target, index + 1)
                ),
            )
        )
    return tuple(statuses)


def first_limit_breach(projection: Sequence[ProjectedMonth], limit_agorot: int) -> str | None:
    """The first month that ends deeper in overdraft than the credit limit allows."""
    return next((m.month for m in projection if m.balance_agorot < -limit_agorot), None)


@dataclass(frozen=True)
class CashFlowCheck:
    """Does the projection keep every month's cash flow above zero?"""

    months: int
    # Months whose cash flow is zero or negative.
    failing_months: int
    worst_month: str
    worst_flow_agorot: int

    @property
    def positive(self) -> bool:
        return self.failing_months == 0

    @property
    def missing_agorot(self) -> int:
        """Extra monthly cash flow needed for the worst month to end above zero."""
        return 0 if self.positive else 1 - self.worst_flow_agorot


def cash_flow_check(projection: Sequence[ProjectedMonth]) -> CashFlowCheck:
    """Check the rule that the plan must stay cash flow positive every month."""
    if not projection:
        raise ValueError("projection is empty")
    worst = min(projection, key=lambda month: month.flow_agorot)
    failing = sum(1 for month in projection if month.flow_agorot <= 0)
    return CashFlowCheck(len(projection), failing, worst.month, worst.flow_agorot)


def _per_month(gap_agorot: int, months: int) -> int:
    """Spread a gap over the months, rounding up so that the amount is enough."""
    return 0 if gap_agorot <= 0 else -(-gap_agorot // months)
