"""Goals, dated commitments and timeline events, loaded from a private YAML file."""

import re
from dataclasses import dataclass
from typing import Any

from fin.logic.errors import ConfigError
from fin.logic.money import to_agorot

DEFAULT_HORIZON_MONTHS = 12
_MONTH = re.compile(r"\d{4}-(0[1-9]|1[0-2])")
_PREFIX = "goals config"


@dataclass(frozen=True)
class Goal:
    """One step on the way up: what the balance has to grow by, on top of earlier goals.

    The step is a fixed amount, a number of months of baseline spending, or
    nothing at all (for "get the balance back to zero").
    """

    name: str
    amount_agorot: int = 0
    months_of_spend: int = 0
    # A smaller acceptable amount, reported as an alternative.
    minimum_agorot: int | None = None
    # Target month (YYYY-MM): the goal should hold at the end of it.
    by: str | None = None


@dataclass(frozen=True)
class Commitment:
    """A fixed monthly payment that runs between two months, inclusive."""

    name: str
    amount_agorot: int
    first_month: str
    last_month: str
    # The bucket the payments show up under, so that a budget can allow for them.
    bucket: str | None = None


@dataclass(frozen=True)
class Event:
    """A point on the timeline; with an amount it also changes the balance."""

    month: str
    label: str
    # Signed: positive is money in. None marks a milestone with no known amount.
    amount_agorot: int | None = None


@dataclass(frozen=True)
class GoalsConfig:
    horizon_months: int = DEFAULT_HORIZON_MONTHS
    overdraft_limit_agorot: int | None = None
    goals: tuple[Goal, ...] = ()
    commitments: tuple[Commitment, ...] = ()
    events: tuple[Event, ...] = ()


def parse_goals_config(raw: Any, path: str = "") -> GoalsConfig:
    """Validate goals and timeline; an empty document has none."""
    if raw is None:
        return GoalsConfig()
    if not isinstance(raw, dict):
        raise ConfigError(f"{_PREFIX}: root must be a mapping: {path}")
    horizon = raw.get("horizon_months", DEFAULT_HORIZON_MONTHS)
    if isinstance(horizon, bool) or not isinstance(horizon, int) or horizon < 1:
        raise ConfigError(f"{_PREFIX}: horizon_months must be a positive whole number")
    limit = raw.get("overdraft_limit")
    return GoalsConfig(
        horizon_months=horizon,
        overdraft_limit_agorot=None if limit is None else _positive(limit, "overdraft_limit"),
        goals=tuple(_goal(item, name) for item, name in _items(raw, "goals")),
        commitments=tuple(_commitment(item, name) for item, name in _items(raw, "commitments")),
        events=tuple(_event(item, name) for item, name in _items(raw, "events")),
    )


def _items(raw: dict[str, Any], key: str) -> list[tuple[dict[str, Any], str]]:
    values = raw.get(key) or []
    if not isinstance(values, list):
        raise ConfigError(f"{_PREFIX}: {key} must be a list")
    for index, item in enumerate(values):
        if not isinstance(item, dict):
            raise ConfigError(f"{_PREFIX}: {key}[{index}] must be a mapping")
    return [(item, f"{key}[{index}]") for index, item in enumerate(values)]


def _amount(value: Any, name: str) -> int:
    try:
        return to_agorot(value)
    except (TypeError, ValueError) as exc:
        raise ConfigError(f"{_PREFIX}: {name} is not a money amount") from exc


def _positive(value: Any, name: str) -> int:
    agorot = _amount(value, name)
    if agorot <= 0:
        raise ConfigError(f"{_PREFIX}: {name} must be positive")
    return agorot


def _month(value: Any, name: str) -> str:
    text = str(value)
    if not _MONTH.fullmatch(text):
        raise ConfigError(f"{_PREFIX}: {name} must be YYYY-MM")
    return text


def _text(item: dict[str, Any], key: str, name: str) -> str:
    value = item.get(key)
    if not isinstance(value, str) or not value:
        raise ConfigError(f"{_PREFIX}: {name}.{key} is missing")
    return value


def _goal(item: dict[str, Any], name: str) -> Goal:
    months = item.get("months_of_spend", 0)
    if isinstance(months, bool) or not isinstance(months, int) or months < 0:
        raise ConfigError(f"{_PREFIX}: {name}.months_of_spend must be a whole number")
    amount = 0 if item.get("amount") is None else _positive(item["amount"], f"{name}.amount")
    if amount and months:
        raise ConfigError(f"{_PREFIX}: {name} takes amount or months_of_spend, not both")
    minimum = item.get("minimum")
    if minimum is not None:
        minimum = _positive(minimum, f"{name}.minimum")
        if minimum >= amount:
            raise ConfigError(f"{_PREFIX}: {name}.minimum must be smaller than amount")
    by = item.get("by")
    return Goal(
        name=_text(item, "name", name),
        amount_agorot=amount,
        months_of_spend=months,
        minimum_agorot=minimum,
        by=None if by is None else _month(by, f"{name}.by"),
    )


def _commitment(item: dict[str, Any], name: str) -> Commitment:
    first = _month(item.get("from"), f"{name}.from")
    last = _month(item.get("until"), f"{name}.until")
    if first > last:
        raise ConfigError(f"{_PREFIX}: {name}.from must not be after until")
    bucket = item.get("bucket")
    if bucket is not None and (not isinstance(bucket, str) or not bucket):
        raise ConfigError(f"{_PREFIX}: {name}.bucket must be a bucket name")
    return Commitment(
        _text(item, "name", name),
        _positive(item.get("amount"), f"{name}.amount"),
        first,
        last,
        bucket,
    )


def _event(item: dict[str, Any], name: str) -> Event:
    amount = item.get("amount")
    if amount is not None:
        amount = _amount(amount, f"{name}.amount")
        if amount == 0:
            raise ConfigError(f"{_PREFIX}: {name}.amount must not be zero")
    return Event(_month(item.get("month"), f"{name}.month"), _text(item, "label", name), amount)
