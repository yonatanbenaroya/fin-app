"""Can I afford it: what a one-time purchase does to this month and to the goals.

Pure. The caller runs the projection twice (with and without the purchase) and
hands in both goal evaluations. Decision support, not advice.
"""

from collections.abc import Sequence
from dataclasses import dataclass

from fin.logic.planner.goals import ALREADY, GoalStatus
from fin.logic.planner.pace import Pace
from fin.logic.planner.projection import months_between


@dataclass(frozen=True)
class GoalShift:
    name: str
    before: str | None
    after: str | None

    @property
    def delay_months(self) -> int | None:
        """How many months later the goal is reached; None when it no longer is."""
        if self.after is None:
            return None if self.before is not None else 0
        if self.before is None:
            return 0
        if ALREADY in (self.before, self.after):
            return 0 if self.before == self.after else None
        return months_between(self.before, self.after)


@dataclass(frozen=True)
class PurchaseCheck:
    amount_agorot: int
    before: Pace
    after: Pace
    shifts: tuple[GoalShift, ...]

    @property
    def fits_this_month(self) -> bool:
        """The month's budget still has room once the purchase is made."""
        return self.after.remaining_agorot >= 0


def check_purchase(
    amount_agorot: int,
    pace: Pace,
    goals_before: Sequence[GoalStatus],
    goals_after: Sequence[GoalStatus],
) -> PurchaseCheck:
    """Compare the month and the goal dates with and without the purchase."""
    if amount_agorot <= 0:
        raise ValueError("amount must be positive")
    after = Pace(
        pace.spent_agorot + amount_agorot, pace.ceiling_agorot, pace.day, pace.days_in_month
    )
    shifts = tuple(
        GoalShift(b.name, b.reached, a.reached)
        for b, a in zip(goals_before, goals_after, strict=True)
    )
    return PurchaseCheck(amount_agorot, pace, after, shifts)
