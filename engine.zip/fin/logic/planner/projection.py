"""Month-by-month projection of the bank balance. Pure, integer agorot only."""

from collections.abc import Sequence
from dataclasses import dataclass

from fin.logic.money import mean_agorot
from fin.logic.planner.goals_config import Commitment, Event


@dataclass(frozen=True)
class ProjectedMonth:
    month: str
    flow_agorot: int
    # Balance at the end of the month.
    balance_agorot: int
    notes: tuple[str, ...] = ()


@dataclass(frozen=True)
class Adjustment:
    """A change to the monthly cash flow (positive is better), optionally bounded."""

    label: str
    monthly_agorot: int
    first_month: str | None = None
    last_month: str | None = None

    def active(self, month: str) -> bool:
        """True when the adjustment applies in the given month."""
        return (self.first_month is None or self.first_month <= month) and (
            self.last_month is None or month <= self.last_month
        )


def add_months(month: str, count: int) -> str:
    """Shift a 'YYYY-MM' month by a number of months (negative goes back)."""
    index = int(month[:4]) * 12 + int(month[5:7]) - 1 + count
    return f"{index // 12:04d}-{index % 12 + 1:02d}"


def months_between(first: str, last: str) -> int:
    """How many months `last` is after `first` (negative when it is before)."""
    return (int(last[:4]) - int(first[:4])) * 12 + int(last[5:7]) - int(first[5:7])


def project(
    start_balance_agorot: int,
    first_month: str,
    base_flow_agorot: int,
    horizon: int,
    commitments: Sequence[Commitment] = (),
    events: Sequence[Event] = (),
    window_months: Sequence[str] = (),
    adjustments: Sequence[Adjustment] = (),
) -> tuple[ProjectedMonth, ...]:
    """Project `horizon` months, starting with `first_month`.

    Every month gets the baseline cash flow, minus the commitments active in it,
    plus the events that carry an amount and the adjustments active in it.
    `window_months` are the months the baseline was averaged over: the part of a
    commitment that already fell inside them is in the baseline, so it is not
    charged twice.
    """
    if horizon < 1:
        raise ValueError("horizon must be positive")
    in_baseline = {
        item: _already_counted(item, window_months) for item in dict.fromkeys(commitments)
    }
    months = []
    balance = start_balance_agorot
    for offset in range(horizon):
        month = add_months(first_month, offset)
        flow = base_flow_agorot
        flow += sum(item.monthly_agorot for item in adjustments if item.active(month))
        notes = []
        for item in commitments:
            flow += in_baseline[item]
            if item.first_month <= month <= item.last_month:
                flow -= item.amount_agorot
            if month == item.last_month:
                notes.append(f"last payment: {item.name}")
        for event in events:
            if event.month == month:
                flow += event.amount_agorot or 0
                notes.append(event.label if event.amount_agorot else f"{event.label} (no amount)")
        balance += flow
        months.append(ProjectedMonth(month, flow, balance, tuple(notes)))
    return tuple(months)


def _already_counted(item: Commitment, window_months: Sequence[str]) -> int:
    """The monthly share of a commitment that the baseline mean already contains."""
    if not window_months:
        return 0
    active = sum(1 for month in window_months if item.first_month <= month <= item.last_month)
    return mean_agorot(item.amount_agorot * active, len(window_months))
