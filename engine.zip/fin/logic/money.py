"""Money helpers. Amounts are stored as integer agorot (1 ILS = 100 agorot)."""

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

AGOROT_PER_SHEKEL = 100


def to_agorot(value: int | float | str | Decimal) -> int:
    """Convert a shekel amount to integer agorot, rounding half up.

    Floats are converted through their shortest repr, so 12.34 becomes 1234
    and never 1233. Strings may contain thousands separators.
    """
    if isinstance(value, bool):
        raise TypeError("bool is not a money amount")
    if isinstance(value, Decimal):
        amount = value
    elif isinstance(value, int):
        amount = Decimal(value)
    elif isinstance(value, float):
        amount = Decimal(repr(value))
    elif isinstance(value, str):
        try:
            amount = Decimal(value.strip().replace(",", ""))
        except InvalidOperation as exc:
            raise ValueError("not a money amount") from exc
    else:
        raise TypeError(f"unsupported money type: {type(value).__name__}")
    if not amount.is_finite():
        raise ValueError("money amount must be finite")
    return int((amount * AGOROT_PER_SHEKEL).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def mean_agorot(total: int, count: int) -> int:
    """Return total / count in whole agorot, rounding half away from zero."""
    if count <= 0:
        raise ValueError("count must be positive")
    return int((Decimal(total) / Decimal(count)).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def format_ils(agorot: int) -> str:
    """Format integer agorot as a shekel string, for example '-₪1,234.50'."""
    sign = "-" if agorot < 0 else ""
    shekels, rest = divmod(abs(agorot), AGOROT_PER_SHEKEL)
    return f"{sign}₪{shekels:,}.{rest:02d}"
