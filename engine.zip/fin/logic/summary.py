"""Monthly summary records: what the queries return and the planner reads. Pure."""

from dataclasses import dataclass

from fin.logic.money import mean_agorot


@dataclass(frozen=True)
class BucketLine:
    bucket: str
    spent_agorot: int
    budget_agorot: int | None

    @property
    def remaining_agorot(self) -> int | None:
        """Budget left for the bucket (negative when overspent), if a budget exists."""
        return None if self.budget_agorot is None else self.budget_agorot - self.spent_agorot


@dataclass(frozen=True)
class MonthSummary:
    month: str
    buckets: tuple[BucketLine, ...]
    transactions: int
    quarantined: int
    net_income_agorot: int | None
    # Filled for the actual ledger only (see fin.storage.analytics.actual).
    transfers_in_agorot: int = 0
    investments_agorot: int = 0
    family_support_agorot: int = 0
    uncategorized: int = 0
    unmatched_card_payments: int = 0
    estimated: int = 0

    @property
    def spent_agorot(self) -> int:
        return sum(line.spent_agorot for line in self.buckets)

    @property
    def budget_agorot(self) -> int | None:
        budgets = [line.budget_agorot for line in self.buckets if line.budget_agorot is not None]
        return sum(budgets) if budgets else None

    @property
    def cash_flow_agorot(self) -> int | None:
        """Income plus money received from people, minus spending.

        None when the month has no income figure.
        """
        if self.net_income_agorot is None:
            return None
        return self.net_income_agorot + self.transfers_in_agorot - self.spent_agorot


@dataclass(frozen=True)
class PeriodSummary:
    months: tuple[MonthSummary, ...]
    source: str | None = None

    @property
    def mean_spent_agorot(self) -> int | None:
        if not self.months:
            return None
        return mean_agorot(sum(m.spent_agorot for m in self.months), len(self.months))

    @property
    def months_with_income(self) -> tuple[MonthSummary, ...]:
        return tuple(m for m in self.months if m.net_income_agorot is not None)

    @property
    def mean_net_income_agorot(self) -> int | None:
        known = self.months_with_income
        if not known:
            return None
        return mean_agorot(sum(m.net_income_agorot or 0 for m in known), len(known))

    @property
    def mean_cash_flow_agorot(self) -> int | None:
        """Mean cash flow over the months that have a net income figure."""
        known = self.months_with_income
        if not known:
            return None
        return mean_agorot(sum(m.cash_flow_agorot or 0 for m in known), len(known))

    @property
    def bucket_means(self) -> tuple[tuple[str, int], ...]:
        """Mean monthly spend per bucket over all months of the period, largest first."""
        totals: dict[str, int] = {}
        for month in self.months:
            for line in month.buckets:
                totals[line.bucket] = totals.get(line.bucket, 0) + line.spent_agorot
        means = [(bucket, mean_agorot(total, len(self.months))) for bucket, total in totals.items()]
        return tuple(sorted(means, key=lambda item: (-item[1], item[0])))


@dataclass(frozen=True)
class IncomeReference:
    """Mean net income over the latest recorded months, whatever period they cover."""

    first_month: str
    last_month: str
    months: int
    mean_net_agorot: int
