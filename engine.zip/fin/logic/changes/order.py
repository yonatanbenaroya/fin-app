"""Order keys that always fit between two others, so moving one rule edits one field.

Keys are strings over 0-9A-Za-z, compared as plain strings, never ending in '0'.
`between(low, high)` returns a key with low < key < high; None means no bound on
that side. Two devices that insert at the same place may pick the same key;
items with equal keys are then ordered by their id, the same way everywhere.
"""

DIGITS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
BASE = len(DIGITS)


def _check(key: str) -> None:
    if not key or any(c not in DIGITS for c in key) or key.endswith(DIGITS[0]):
        raise ValueError(f"not an order key: {key!r}")


def between(low: str | None, high: str | None) -> str:
    """A key strictly between `low` and `high` (either may be None)."""
    for key in (low, high):
        if key is not None:
            _check(key)
    if low is not None and high is not None and not low < high:
        raise ValueError("low must sort before high")
    low = low or ""
    prefix = ""
    i = 0
    while True:
        lo = DIGITS.index(low[i]) if i < len(low) else 0
        hi = DIGITS.index(high[i]) if high is not None and i < len(high) else BASE
        if lo == hi:
            prefix += DIGITS[lo]
            i += 1
            continue
        middle = (lo + hi) // 2
        if middle > lo:
            return prefix + DIGITS[middle]
        # No room at this position: keep low's digit, which is already below high,
        # and look for room above low further on.
        prefix += DIGITS[lo]
        i += 1
        high = None


def ordered(items: dict[str, str]) -> list[str]:
    """Item ids sorted by their order key, then by id."""
    return sorted(items, key=lambda item_id: (items[item_id], item_id))
