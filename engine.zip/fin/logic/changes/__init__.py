"""The shared change log: a hybrid clock, change records, and the merge that folds them."""
