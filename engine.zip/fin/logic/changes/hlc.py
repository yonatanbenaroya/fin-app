"""A hybrid logical clock: one order of events across devices whose clocks may be wrong.

A stamp is (wall time in ms, counter, device). A device's next stamp is never
below the newest stamp it has seen, its own or another device's, so an edit
made after receiving a change always orders after that change, even when this
device's clock runs behind. Equal times go to the counter and then to the
device id, so every device sorts the same stamps the same way.
"""

from dataclasses import dataclass

MAX_COUNTER = 99_999
MAX_DRIFT_MS = 24 * 60 * 60 * 1000  # a remote stamp more than a day ahead is refused


class ClockError(ValueError):
    """A stamp that cannot be right: malformed, or far in the future."""


@dataclass(frozen=True, order=True)
class Stamp:
    wall_ms: int
    counter: int
    device: str

    def encode(self) -> str:
        """Text that sorts like the stamp: '0001795000000000-00000-mac'."""
        return f"{self.wall_ms:016d}-{self.counter:05d}-{self.device}"


ZERO = Stamp(0, 0, "")


def decode(text: str) -> Stamp:
    parts = text.split("-", 2)
    if len(parts) != 3 or not parts[0].isdigit() or not parts[1].isdigit() or not parts[2]:
        raise ClockError(f"not a clock stamp: {text!r}")
    return Stamp(int(parts[0]), int(parts[1]), parts[2])


def _check_device(device: str) -> None:
    if not device or "-" in device:
        raise ClockError("a device id must be non-empty and contain no '-'")


def tick(last: Stamp, now_ms: int, device: str) -> Stamp:
    """The stamp for a new edit on this device; `last` is the newest stamp it has seen."""
    _check_device(device)
    if now_ms > last.wall_ms:
        return Stamp(now_ms, 0, device)
    if last.counter >= MAX_COUNTER:
        return Stamp(last.wall_ms + 1, 0, device)
    return Stamp(last.wall_ms, last.counter + 1, device)


def receive(last: Stamp, remote: Stamp, now_ms: int, device: str) -> Stamp:
    """The newest stamp this device has seen, after taking in a change from another device."""
    _check_device(device)
    if remote.wall_ms > now_ms + MAX_DRIFT_MS:
        raise ClockError("a change is stamped more than a day in the future")
    wall = max(last.wall_ms, remote.wall_ms, now_ms)
    if wall == last.wall_ms == remote.wall_ms:
        counter = max(last.counter, remote.counter) + 1
    elif wall == last.wall_ms:
        counter = last.counter + 1
    elif wall == remote.wall_ms:
        counter = remote.counter + 1
    else:
        counter = 0
    if counter > MAX_COUNTER:
        return Stamp(wall + 1, 0, device)
    return Stamp(wall, counter, device)
