"""Change records and the deterministic merge of any set of them.

Every edit is a change to one field of one item: (entity, key, field, value).
Deleting an item is a change with `deleted=True` and no field. The state holds
the newest value of every field, newest by clock stamp. A deletion hides the
item and every field written before it; a field written after it brings the
item back. The fold keeps a maximum per field, so the same changes give the
same state in any order, and taking a change twice changes nothing.

Imported bank and card rows are facts with their own identity (tx_hash) and are
not merged here.
"""

from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any

from fin.logic.changes.hlc import Stamp

ENTITIES = frozenset({
    "document",           # that a settings document exists, by name (rules, budget, ...)
    "setting",            # a single value of a document, by "document.name"
    "rule",               # a categorization rule, by id: match, category, order, ...
    "budget_ceiling",     # a monthly ceiling, by bucket
    "goal",               # a goal, by id
    "commitment",         # a fixed monthly payment of the goals timeline, by id
    "event",              # a point on the goals timeline, by id
    "declared",           # a declared monthly amount of the baseline, by bucket
    "one_off",            # a one-time expense left out of the baseline, by id
    "scenario",           # a what-if scenario, by id
    "category_override",  # a category set by hand, by tx_hash
    "manual_tx",          # a manual expense or income, by id
    "note",               # a free-text note on a transaction, by tx_hash
    "profile",            # the user's own details (key "main"): the name for the greeting
    "title",              # a transaction's own title, by tx_hash (the bank's text stays)
    "rename",             # a merchant rename rule, by id: match, title, amount_agorot, order
    "hidden_charge",      # a card charge hidden from "Coming up", by "month|bank text|amount"
    "category_label",     # a category's own name per language and its order, by category key
    "source_map",         # a bank or card export mapped by hand, by id
    "holding",            # a saving typed in by the user (pension, study fund, RSU ...), by id
    "holding_balance",    # one balance of a holding as of a date, by "<holding id>|YYYY-MM-DD"
})  # fmt: skip
ITEM = ""  # the field of an item-level change (a deletion)

State = dict[str, dict[str, dict[str, Any]]]


class ChangeError(ValueError):
    """A change that cannot be applied."""


def _plain(value: Any) -> bool:
    """Text, whole numbers, booleans, None, and lists or mappings of those. No floats:
    money is integer agorot."""
    if value is None or isinstance(value, bool | int | str):
        return True
    if isinstance(value, list):
        return all(_plain(item) for item in value)
    if isinstance(value, dict):
        return all(isinstance(k, str) and _plain(v) for k, v in value.items())
    return False


@dataclass(frozen=True)
class Change:
    id: str
    stamp: Stamp
    entity: str
    key: str
    field: str = ITEM
    value: Any = None
    deleted: bool = False

    def __post_init__(self) -> None:
        if self.entity not in ENTITIES:
            raise ChangeError(f"unknown entity {self.entity!r}")
        if not self.id or not self.key:
            raise ChangeError("a change needs an id and a key")
        if self.deleted != (self.field == ITEM):
            raise ChangeError("a deletion has no field, and every other change has one")
        if self.deleted and self.value is not None:
            raise ChangeError("a deletion has no value")
        if not _plain(self.value):
            raise ChangeError("a value must be plain data (text, whole numbers, lists, mappings)")


@dataclass
class _Item:
    deleted_at: Stamp | None = None
    fields: dict[str, Change] = field(default_factory=dict)


def fold(changes: Iterable[Change]) -> State:
    """The state: entity -> key -> field -> value, for every item that exists."""
    items: dict[tuple[str, str], _Item] = {}
    seen: set[str] = set()
    for change in changes:
        if change.id in seen:
            continue
        seen.add(change.id)
        item = items.setdefault((change.entity, change.key), _Item())
        if change.deleted:
            if item.deleted_at is None or change.stamp > item.deleted_at:
                item.deleted_at = change.stamp
            continue
        current = item.fields.get(change.field)
        if current is None or change.stamp > current.stamp:
            item.fields[change.field] = change
    state: State = {}
    for (entity, key), item in sorted(items.items()):
        alive = {
            name: change.value
            for name, change in sorted(item.fields.items())
            if item.deleted_at is None or change.stamp > item.deleted_at
        }
        if alive:
            state.setdefault(entity, {})[key] = alive
    return state


def history(changes: Iterable[Change], entity: str, key: str, name: str) -> list[Change]:
    """Every write to one field, oldest first: what a newer edit replaced stays visible."""
    found = {c.id: c for c in changes if (c.entity, c.key, c.field) == (entity, key, name)}
    return sorted(found.values(), key=lambda c: c.stamp)
