"""A source of the user's own: how to read a bank or card export no adapter knows.

The user maps the file's columns once (design.md §12, item 9): which column is
the date, the description, the amount (one signed column, or debit and credit),
and optionally the running balance and the billing date. The file's header row
is its signature: the next export with the same headers is recognized again.

Pure: cells in, signed agorot and dates out. Spending is negative, as in every
stored transaction. Reading the file and storing rows is the storage box's job.
"""

import re
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

from fin.logic.errors import ConfigError
from fin.logic.money import to_agorot

BANK = "bank"
CARD = "card"
MAP_KINDS = (BANK, CARD)
DATE_ORDERS = ("dmy", "mdy", "ymd")
SPENDING_NEGATIVE = "negative"  # as a bank statement: money out has a minus
SPENDING_POSITIVE = "positive"  # as a card statement: a charge is a plus
SPENDING = (SPENDING_NEGATIVE, SPENDING_POSITIVE)
MAX_NAME = 40
MAX_LABEL = 60
MAP_PREFIX = "map_"
ROLES = ("date", "description", "amount", "debit", "credit", "balance", "billing")


@dataclass(frozen=True)
class SourceMap:
    id: str
    name: str
    kind: str
    sheet: str | None  # None for a CSV file, or "any sheet with these headers"
    headers: tuple[str, ...]
    date: str
    description: str
    amount: str | None = None
    debit: str | None = None
    credit: str | None = None
    balance: str | None = None
    billing: str | None = None
    date_order: str = "dmy"
    spending: str = SPENDING_NEGATIVE
    # A card: how the bank statement names this card's monthly payment, so it is not
    # counted twice (the card's own rows are the detail).
    bank_label: str | None = None

    @property
    def source(self) -> str:
        """The source key stored on every row, e.g. "map_3f2a9c1b7d0e"."""
        return f"{MAP_PREFIX}{self.id}"


@dataclass(frozen=True)
class MappedRow:
    tx_date: date
    description: str
    amount_agorot: int  # spending negative
    balance_agorot: int | None = None
    billing_date: date | None = None


@dataclass(frozen=True)
class MappedRows:
    rows: tuple[MappedRow, ...]
    # (row number in the file, 1-based after the header; reason)
    problems: tuple[tuple[int, str], ...]


def _text(value: Any) -> str:
    return " ".join(str(value).split()) if value is not None else ""


def header_cells(row: Sequence[Any]) -> tuple[str, ...]:
    """A header row as the signature compares it: text with spaces collapsed, trailing
    empty cells dropped."""
    cells = [_text(cell) for cell in row]
    while cells and not cells[-1]:
        cells.pop()
    return tuple(cells)


def parse_source_map(item_id: str, fields: dict[str, Any]) -> SourceMap:
    """Validate a mapping; ConfigError says what is wrong."""
    name = _text(fields.get("name"))
    if not name or len(name) > MAX_NAME:
        raise ConfigError(f"source: a name of up to {MAX_NAME} characters is needed")
    kind = fields.get("kind")
    if kind not in MAP_KINDS:
        raise ConfigError("source: kind is bank or card")
    headers = fields.get("headers")
    if not isinstance(headers, list) or not all(isinstance(h, str) for h in headers):
        raise ConfigError("source: the file's header row is needed")
    named = {h for h in headers if h}
    if len(named) < 2:
        raise ConfigError("source: the header row needs at least two named columns")
    sheet = fields.get("sheet")
    if sheet is not None and not isinstance(sheet, str):
        raise ConfigError("source: the sheet is a name")
    columns: dict[str, str | None] = {}
    for role in ROLES:
        value = fields.get(role) or None
        if value is not None and value not in named:
            raise ConfigError(f"source: the {role} column is not in the header row")
        columns[role] = value
    if not columns["date"] or not columns["description"]:
        raise ConfigError("source: the date and description columns are needed")
    if columns["amount"] and (columns["debit"] or columns["credit"]):
        raise ConfigError("source: one amount column, or debit and credit, not both")
    if not columns["amount"] and not (columns["debit"] or columns["credit"]):
        raise ConfigError("source: an amount column (or debit and credit) is needed")
    used = [c for c in columns.values() if c]
    if len(used) != len(set(used)):
        raise ConfigError("source: a column has one role")
    order = fields.get("date_order") or "dmy"
    if order not in DATE_ORDERS:
        raise ConfigError("source: unknown date order")
    spending = fields.get("spending") or SPENDING_NEGATIVE
    if spending not in SPENDING:
        raise ConfigError("source: spending is negative or positive")
    label = _text(fields.get("bank_label")) or None
    if label is not None and (kind != CARD or len(label) > MAX_LABEL):
        raise ConfigError("source: a bank label belongs to a card, up to 60 characters")
    if columns["billing"] and kind != CARD:
        raise ConfigError("source: a billing date belongs to a card")
    return SourceMap(
        id=item_id, name=name, kind=kind, sheet=sheet or None, headers=tuple(headers),
        date=columns["date"], description=columns["description"], amount=columns["amount"],
        debit=columns["debit"], credit=columns["credit"], balance=columns["balance"],
        billing=columns["billing"], date_order=order, spending=spending, bank_label=label,
    )  # fmt: skip


_DATE_PARTS = re.compile(r"(\d{1,4})\s*[./\-]\s*(\d{1,2})\s*[./\-]\s*(\d{1,4})")


def read_date(value: Any, order: str = "dmy") -> date:
    """A date cell: a date or datetime object, or text such as 05/11/2026, 5.11.26 or
    2026-11-05 (four digits first is always year-month-day). Raises ValueError."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    match = _DATE_PARTS.search(_text(value))
    if not match:
        raise ValueError("not a date")
    a, b, c = match.groups()
    if len(a) == 4:
        year, month, day = int(a), int(b), int(c)
    elif order == "mdy":
        month, day, year = int(a), int(b), int(c)
    elif order == "ymd":
        year, month, day = int(a), int(b), int(c)
    else:
        day, month, year = int(a), int(b), int(c)
    if year < 100:
        year += 2000
    return date(year, month, day)


_NOT_AMOUNT = re.compile(r"[^\d.,\-+()]")


def read_amount(value: Any) -> int | None:
    """An amount cell in agorot, keeping its sign; None for an empty cell. Text may carry a
    currency sign, thousands separators, a trailing minus (100-) or parentheses. Raises
    ValueError for anything else."""
    if value is None or isinstance(value, bool):
        if isinstance(value, bool):
            raise ValueError("not an amount")
        return None
    if isinstance(value, int | float):
        return to_agorot(value)
    text = _text(value)
    if not text:
        return None
    negative = text.startswith("(") and text.endswith(")")
    text = _NOT_AMOUNT.sub("", text).strip("()")
    if text.endswith("-"):
        negative, text = True, text[:-1]
    if text.startswith("-"):
        negative, text = not negative, text[1:]
    text = text.lstrip("+").replace(",", "")
    try:
        amount = Decimal(text)
    except InvalidOperation as exc:
        raise ValueError("not an amount") from exc
    agorot = to_agorot(amount)
    return -agorot if negative else agorot


def map_rows(
    mapping: SourceMap, headers: Sequence[str], rows: Sequence[Sequence[Any]]
) -> MappedRows:
    """Read the rows under the header with the mapping. Empty rows, and rows with neither
    a date nor an amount (totals, footers), are skipped; any other unreadable row is a
    problem, and the caller refuses the file when there are problems."""
    index = {name: i for i, name in reversed(list(enumerate(headers))) if name}

    def cell(row: Sequence[Any], role: str | None) -> Any:
        if role is None:
            return None
        i = index[role]
        return row[i] if i < len(row) else None

    found: list[MappedRow] = []
    problems: list[tuple[int, str]] = []
    for number, row in enumerate(rows, start=1):
        if not any(_text(v) for v in row):
            continue
        raw_date = cell(row, mapping.date)
        try:
            if mapping.amount:
                single = read_amount(cell(row, mapping.amount))
                amount = None if single is None else (
                    -single if mapping.spending == SPENDING_POSITIVE else single)  # fmt: skip
            else:
                debit = read_amount(cell(row, mapping.debit))
                credit = read_amount(cell(row, mapping.credit))
                # Some banks write debits with a minus and some without: the column decides.
                none = debit is None and credit is None
                amount = None if none else abs(credit or 0) - abs(debit or 0)
        except ValueError:
            problems.append((number, "amount"))
            continue
        if not _text(raw_date) and amount is None:
            continue  # a total or a footer line
        if amount is None:
            problems.append((number, "amount"))
            continue
        if amount == 0:
            continue  # nothing moved (an information line)
        try:
            when = read_date(raw_date, mapping.date_order)
        except ValueError:
            problems.append((number, "date"))
            continue
        text = _text(cell(row, mapping.description))
        if not text:
            problems.append((number, "description"))
            continue
        try:
            balance = read_amount(cell(row, mapping.balance))
            billing_raw = cell(row, mapping.billing)
            billing = read_date(billing_raw, mapping.date_order) if _text(billing_raw) else None
        except ValueError:
            problems.append((number, "balance" if mapping.balance else "billing"))
            continue
        found.append(MappedRow(when, text, amount, balance, billing))
    return MappedRows(tuple(found), tuple(problems))


_GUESS = {
    "billing": ("תאריך חיוב", "מועד חיוב", "billing", "charge date", "posted"),
    "date": ("תאריך", "date", "יום"),
    "description": (
        "תיאור",
        "פרטים",
        "בית עסק",
        "שם בית העסק",
        "פעולה",
        "description",
        "merchant",
        "payee",
        "details",
        "memo",
    ),  # fmt: skip
    "debit": ("חובה", "debit", "withdrawal", "משיכה", "money out"),
    "credit": ("זכות", "credit", "deposit", "הפקדה", "money in"),
    "balance": ("יתרה", "balance"),
    "amount": ("סכום", "amount", "חיוב", "charge", "sum", "total"),
}


def guess_columns(headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> dict[str, Any]:
    """A first suggestion for the mapping step, by header names and the sample rows.
    Only a suggestion: the user confirms every role."""
    taken: set[str] = set()
    guess: dict[str, Any] = {}
    for role, words in _GUESS.items():
        for name in headers:
            if name and name not in taken and any(w in name.casefold() for w in words):
                guess[role] = name
                taken.add(name)
                break
    if "billing" in guess and "date" not in guess:  # the only date column is the date
        guess["date"] = guess.pop("billing")
    if "amount" in guess and ("debit" in guess or "credit" in guess):
        if "debit" in guess and "credit" in guess:
            del guess["amount"]
        else:
            guess.pop("debit", None)
            guess.pop("credit", None)
    guess["date_order"] = "dmy"
    date_column = guess.get("date")
    if date_column in headers:
        i = headers.index(date_column)
        for row in rows:
            match = _DATE_PARTS.search(_text(row[i] if i < len(row) else ""))
            if match and len(match.group(1)) <= 2 and int(match.group(2)) > 12:
                guess["date_order"] = "mdy"
                break
    if "amount" in guess:
        i = headers.index(guess["amount"])
        signs = []
        for row in rows:
            try:
                value = read_amount(row[i] if i < len(row) else None)
            except ValueError:
                continue
            if value:
                signs.append(value > 0)
        mostly_positive = signs and sum(signs) > len(signs) * 0.8
        guess["spending"] = SPENDING_POSITIVE if mostly_positive else SPENDING_NEGATIVE
    guess["kind"] = CARD if guess.get("spending") == SPENDING_POSITIVE else BANK
    return guess
