"""Cross-match actual transactions with the hand-categorized legacy workbook.

The workbook records the same expenses that later show up in the bank and card
ledgers, with a category the user chose. Two records are taken to be the same
expense when the amounts are equal and the dates are close, but only if the
pairing is unambiguous in both directions: a guess is worse than no match.
"""

from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import date

MIN_MATCHES_TO_LEARN = 2


@dataclass(frozen=True)
class LedgerRow:
    tx_id: int
    tx_date: str
    amount_agorot: int
    source: str
    description: str


@dataclass(frozen=True)
class LegacyRow:
    tx_id: int
    tx_date: str
    amount_agorot: int
    bucket: str | None
    category: str | None


def match_legacy(
    actual: Iterable[LedgerRow], legacy: Iterable[LegacyRow], window_days: int
) -> dict[int, LegacyRow]:
    """Return, per actual transaction id, its one-to-one legacy counterpart."""
    by_amount: dict[int, list[LegacyRow]] = defaultdict(list)
    for row in legacy:
        by_amount[row.amount_agorot].append(row)
    candidates: dict[int, list[LegacyRow]] = {}
    for row in actual:
        day = date.fromisoformat(row.tx_date)
        close = [
            other
            for other in by_amount.get(row.amount_agorot, [])
            if abs((date.fromisoformat(other.tx_date) - day).days) <= window_days
        ]
        if close:
            candidates[row.tx_id] = close
    claims = Counter(other.tx_id for close in candidates.values() for other in close)
    return {
        tx_id: close[0]
        for tx_id, close in candidates.items()
        if len(close) == 1 and claims[close[0].tx_id] == 1
    }


def learn_merchants(
    actual: Iterable[LedgerRow], matches: Mapping[int, LegacyRow]
) -> dict[tuple[str, str], tuple[str | None, str | None]]:
    """Learn (source, merchant) -> (category, bucket) from consistent matches.

    A merchant is learned only when it was matched at least twice and every
    match agrees, so catch-all descriptions such as a payment app are left out.
    """
    seen: dict[tuple[str, str], list[tuple[str | None, str | None]]] = defaultdict(list)
    for row in actual:
        legacy = matches.get(row.tx_id)
        if legacy is not None:
            seen[(row.source, row.description)].append((legacy.category, legacy.bucket))
    return {
        merchant: outcomes[0]
        for merchant, outcomes in seen.items()
        if len(outcomes) >= MIN_MATCHES_TO_LEARN and len(set(outcomes)) == 1
    }
