"""Deterministic transaction classification. Pure: no database, no network."""

from collections.abc import Sequence
from dataclasses import dataclass

from fin.logic.categorize.taxonomy import EXPENSE, Rule, Taxonomy

LAYER_PRIVATE = "private"
LAYER_LEGACY = "legacy"
LAYER_LEARNED = "learned"
LAYER_ESTIMATE = "estimate"
LAYER_GENERIC = "generic"
LAYER_ISSUER = "issuer"
LAYER_NONE = "none"
LAYER_CARD_PAYMENT = "card_payment"
# Layers that rest on something known about this very transaction or merchant.
SPECIFIC_LAYERS = frozenset({LAYER_PRIVATE, LAYER_LEGACY, LAYER_LEARNED, LAYER_ESTIMATE})


@dataclass(frozen=True)
class Classification:
    category: str
    bucket: str | None
    kind: str
    # Which rule decided, for example "private:2", "legacy", "issuer" or "none".
    rule: str

    @property
    def layer(self) -> str:
        return self.rule.split(":", 1)[0]


def resolve(
    taxonomy: Taxonomy, category: str, rule: str, bucket: str | None = None
) -> Classification:
    """Build a classification for a known category, with an optional bucket override. A
    deleted category leads to its replacement; a category the user moved keeps its group."""
    category = taxonomy.canonical(category)
    spec = taxonomy.categories[category]
    if category in taxonomy.moved:
        bucket = None
    return Classification(category, bucket or spec.bucket, spec.kind, rule)


def _from_workbook(
    taxonomy: Taxonomy, labels: tuple[str | None, str | None], rule: str
) -> Classification | None:
    """Adopt a (category, bucket) pair that the user wrote in the legacy workbook."""
    category, bucket = labels
    if category is None:
        return None
    category = taxonomy.canonical(category)
    known = taxonomy.categories.get(category)
    if known is not None and category in taxonomy.moved:
        bucket = None
    kind = known.kind if known else EXPENSE
    return Classification(category, bucket or (known.bucket if known else None), kind, rule)


def classify(
    description: str,
    source: str,
    source_category: str | None,
    amount_agorot: int,
    taxonomy: Taxonomy,
    private_rules: Sequence[Rule] = (),
    legacy: tuple[str | None, str | None] | None = None,
    learned: tuple[str | None, str | None] | None = None,
) -> Classification:
    """Classify one transaction; the first layer that applies decides.

    Order: personal rules, the matching legacy workbook row, what was learned
    about the merchant, personal estimate rules, generic rules, the issuer's
    category, and finally "uncategorized". `legacy` and `learned` are
    (category, bucket) pairs.
    """
    indexed = list(enumerate(private_rules))
    for index, rule in indexed:
        if not rule.estimate and rule.matches(description, source, amount_agorot):
            return resolve(taxonomy, rule.category, f"{LAYER_PRIVATE}:{index}", rule.bucket)
    for labels, layer in ((legacy, LAYER_LEGACY), (learned, LAYER_LEARNED)):
        adopted = _from_workbook(taxonomy, labels, layer) if labels else None
        if adopted is not None:
            return adopted
    for index, rule in indexed:
        if rule.estimate and rule.matches(description, source, amount_agorot):
            return resolve(taxonomy, rule.category, f"{LAYER_ESTIMATE}:{index}", rule.bucket)
    for index, rule in enumerate(taxonomy.rules):
        if rule.matches(description, source, amount_agorot):
            return resolve(taxonomy, rule.category, f"{LAYER_GENERIC}:{index}", rule.bucket)
    mapped = taxonomy.issuer_categories.get(source, {}).get(source_category or "")
    if mapped is not None:
        return resolve(taxonomy, mapped, LAYER_ISSUER)
    fallback = taxonomy.uncategorized_credit if amount_agorot > 0 else taxonomy.uncategorized_debit
    return resolve(taxonomy, fallback, LAYER_NONE)
