"""Transaction categorization: rules first, LLM fallback."""
