"""Match card bill payments in the bank ledger to the card ledgers.

A bank debit to a card issuer duplicates the detailed card transactions it
pays for, so counting both would double count. For every payment this module
works out how much of it is already detailed in the issuer's card ledger for
the same billing date:

1. A payment equal, to the agora, to one card's total is fully covered.
2. What is left of the issuer's ledger for that date is then spread over the
   remaining payments, largest first. A payment can be covered in part: the
   export may start mid-cycle, or the bill may include charges that never
   appear in the ledger.

Only the uncovered remainder of a payment is spending without detail.
"""

from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass


@dataclass(frozen=True)
class BankPayment:
    tx_id: int
    tx_date: str
    amount_agorot: int
    # Card ledger source this payment belongs to; None when there is no ledger for it.
    issuer: str | None


@dataclass(frozen=True)
class CardCharge:
    source: str
    billing_date: str
    card_last4: str | None
    amount_agorot: int


def match_card_payments(
    payments: Iterable[BankPayment], charges: Iterable[CardCharge]
) -> dict[int, int]:
    """Return, per bank payment id, the signed amount detailed in the card ledger.

    Payments with no coverage at all are absent from the result. A value equal
    to the payment's amount means the payment is fully covered.
    """
    per_card: dict[tuple[str, str], dict[str | None, int]] = defaultdict(lambda: defaultdict(int))
    for charge in charges:
        per_card[(charge.source, charge.billing_date)][charge.card_last4] += charge.amount_agorot
    by_cycle: dict[tuple[str, str], list[BankPayment]] = defaultdict(list)
    for payment in payments:
        if payment.issuer is not None:
            by_cycle[(payment.issuer, payment.tx_date)].append(payment)

    covered: dict[int, int] = {}
    for cycle, cycle_payments in by_cycle.items():
        cards = dict(per_card.get(cycle, {}))
        remaining = []
        for payment in sorted(cycle_payments, key=lambda p: p.tx_id):
            card = next(
                (name for name in sorted(cards, key=str) if cards[name] == payment.amount_agorot),
                None,
            )
            if card is None:
                remaining.append(payment)
            else:
                covered[payment.tx_id] = cards.pop(card)
        left = sum(cards.values())
        for payment in sorted(remaining, key=lambda p: (-abs(p.amount_agorot), p.tx_id)):
            part = _same_sign_part(payment.amount_agorot, left)
            if part:
                covered[payment.tx_id] = part
                left -= part
    return covered


def _same_sign_part(amount: int, available: int) -> int:
    """Largest part of `amount` that `available` can cover; zero if signs differ."""
    if amount < 0 and available < 0:
        return max(amount, available)
    if amount > 0 and available > 0:
        return min(amount, available)
    return 0
