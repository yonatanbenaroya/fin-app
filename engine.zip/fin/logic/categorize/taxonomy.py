"""Category taxonomy and rule definitions, loaded from YAML and validated."""

from dataclasses import dataclass
from typing import Any

from fin.logic.errors import ConfigError
from fin.logic.money import to_agorot

EXPENSE = "expense"
INCOME = "income"
TRANSFER_IN = "transfer_in"
INVESTMENT = "investment"
INTERNAL_TRANSFER = "internal_transfer"
FAMILY_SUPPORT = "family_support"
KINDS = frozenset({EXPENSE, INCOME, TRANSFER_IN, INVESTMENT, INTERNAL_TRANSFER, FAMILY_SUPPORT})
DEFAULT_LEGACY_MATCH_WINDOW_DAYS = 3
_DIRECTIONS = frozenset({"credit", "debit"})


@dataclass(frozen=True)
class Category:
    name: str
    bucket: str | None
    kind: str


@dataclass(frozen=True)
class Rule:
    match: str
    category: str
    source: str | None = None
    exact: bool = False
    direction: str | None = None
    bucket: str | None = None
    # Exact signed amount (debits are negative), for charges with no other handle.
    amount_agorot: int | None = None
    # An educated guess rather than a fact; applied late and counted in reports.
    estimate: bool = False

    def matches(self, description: str, source: str, amount_agorot: int) -> bool:
        """True when the rule applies to a transaction (case-insensitive)."""
        if self.source is not None and self.source != source:
            return False
        if self.direction == "credit" and amount_agorot <= 0:
            return False
        if self.direction == "debit" and amount_agorot >= 0:
            return False
        if self.amount_agorot is not None and self.amount_agorot != amount_agorot:
            return False
        text, wanted = description.casefold(), self.match.casefold()
        return text == wanted if self.exact else wanted in text


@dataclass(frozen=True)
class Taxonomy:
    categories: dict[str, Category]
    rules: tuple[Rule, ...]
    issuer_categories: dict[str, dict[str, str]]
    # Bank description prefix -> card ledger source (None: no ledger for that card).
    card_payment_labels: dict[str, str | None]
    uncategorized_debit: str
    uncategorized_credit: str
    matched_card_payment: str
    unmatched_card_payment: str
    legacy_match_window_days: int = DEFAULT_LEGACY_MATCH_WINDOW_DAYS


def parse_taxonomy(raw: dict[str, Any], config_path: str = "") -> Taxonomy:
    """Validate the taxonomy; every rule and mapping must point at a known category."""
    try:
        categories = {
            str(name): Category(str(name), spec.get("bucket"), str(spec["kind"]))
            for name, spec in raw["categories"].items()
        }
        special = raw["special"]
        taxonomy = Taxonomy(
            categories=categories,
            rules=_rules(raw.get("rules") or [], categories, config_path),
            issuer_categories={
                str(source): {str(k): str(v) for k, v in mapping.items()}
                for source, mapping in (raw.get("issuer_categories") or {}).items()
            },
            card_payment_labels={
                str(label): (None if source is None else str(source))
                for label, source in (raw.get("card_payment_labels") or {}).items()
            },
            uncategorized_debit=str(special["uncategorized_debit"]),
            uncategorized_credit=str(special["uncategorized_credit"]),
            matched_card_payment=str(special["matched_card_payment"]),
            unmatched_card_payment=str(special["unmatched_card_payment"]),
            legacy_match_window_days=int(
                raw.get("legacy_match_window_days", DEFAULT_LEGACY_MATCH_WINDOW_DAYS)
            ),
        )
    except (KeyError, TypeError, AttributeError, ValueError) as exc:
        raise ConfigError(f"invalid taxonomy: {config_path}") from exc
    for category in categories.values():
        if category.kind not in KINDS:
            raise ConfigError(f"unknown flow kind {category.kind!r} in {config_path}")
        if category.kind == EXPENSE and not category.bucket:
            raise ConfigError(f"expense category without a bucket in {config_path}")
    referenced = [
        taxonomy.uncategorized_debit,
        taxonomy.uncategorized_credit,
        taxonomy.matched_card_payment,
        taxonomy.unmatched_card_payment,
        *(name for mapping in taxonomy.issuer_categories.values() for name in mapping.values()),
    ]
    for name in referenced:
        if name not in categories:
            raise ConfigError(f"unknown category {name!r} referenced in {config_path}")
    return taxonomy


def parse_private_rules(
    raw: dict[str, Any], taxonomy: Taxonomy, path: str = ""
) -> tuple[Rule, ...]:
    """Validate personal rules against the taxonomy."""
    try:
        return _rules(raw.get("rules") or [], taxonomy.categories, path)
    except (TypeError, AttributeError) as exc:
        raise ConfigError(f"invalid rules file: {path}") from exc


def _rules(items: list[Any], categories: dict[str, Category], path: str) -> tuple[Rule, ...]:
    rules = []
    for item in items:
        try:
            rule = Rule(
                match=str(item["match"]),
                category=str(item["category"]),
                source=item.get("source"),
                exact=bool(item.get("exact", False)),
                direction=item.get("direction"),
                bucket=item.get("bucket"),
                amount_agorot=None if item.get("amount") is None else to_agorot(item["amount"]),
                estimate=bool(item.get("estimate", False)),
            )
        except (KeyError, TypeError, AttributeError, ValueError) as exc:
            raise ConfigError(f"invalid rule in {path}") from exc
        if not rule.match or rule.category not in categories:
            raise ConfigError(f"rule points at unknown category {rule.category!r} in {path}")
        if rule.direction is not None and rule.direction not in _DIRECTIONS:
            raise ConfigError(f"unknown direction {rule.direction!r} in {path}")
        rules.append(rule)
    return tuple(rules)
