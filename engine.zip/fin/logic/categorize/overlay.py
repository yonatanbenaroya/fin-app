"""The user's own changes on top of the built-in taxonomy (design.md §6, categories editor).

The built-in categories come from config/categories.yaml and never change. The user can
add a category, move one to another group, hide a built-in one, or delete one into
another (its transactions, rules and own choices then follow the replacement). Those
changes live in the encrypted account's change log, one item per category key; this
module turns them into the taxonomy every part of the engine uses. Pure.
"""

from collections.abc import Mapping
from dataclasses import replace
from typing import Any

from fin.logic.categorize.taxonomy import EXPENSE, Category, Taxonomy


def _final(name: str, merges: Mapping[str, str]) -> str | None:
    """Follow a chain of deletions (A into B, B into C) to a live category; None on a cycle."""
    seen = {name}
    while name in merges:
        name = merges[name]
        if name in seen:
            return None
        seen.add(name)
    return name


def apply_overlay(taxonomy: Taxonomy, changes: Mapping[str, Mapping[str, Any]]) -> Taxonomy:
    """The effective taxonomy. `changes` is category key -> fields: `added` (a category of
    the user's, with `bucket`), `bucket` (moved), `hidden` (a built-in one put away) and
    `merged_into` (deleted into another category)."""
    categories = dict(taxonomy.categories)
    moved: set[str] = set()
    for name, fields in changes.items():
        bucket = fields.get("bucket")
        if name not in categories and fields.get("added") and isinstance(bucket, str) and bucket:
            categories[name] = Category(name, bucket, EXPENSE)
    for name, fields in changes.items():
        bucket = fields.get("bucket")
        spec = categories.get(name)
        if spec is not None and spec.kind == EXPENSE and isinstance(bucket, str) and bucket:
            categories[name] = Category(name, bucket, EXPENSE)
            moved.add(name)
    merges = {
        name: str(fields["merged_into"])
        for name, fields in changes.items()
        if fields.get("merged_into") and name in categories and name not in taxonomy.special
    }
    aliases: dict[str, str] = {}
    for name in merges:
        target = _final(name, merges)
        if target is not None and target in categories:
            aliases[name] = target
    for name in aliases:
        categories.pop(name)
    hidden = frozenset(
        name for name, fields in changes.items()
        if fields.get("hidden") and name in categories and name not in taxonomy.special
    )  # fmt: skip
    return replace(taxonomy, categories=categories, aliases={**taxonomy.aliases, **aliases},
                   hidden=taxonomy.hidden | hidden, moved=frozenset(moved))  # fmt: skip
