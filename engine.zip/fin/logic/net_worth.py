"""Net worth: the bank balances from the files plus the savings the user types in.

A holding (pension, study fund, investments, company stock ...) has its own details
and a list of balance points, each "the balance as of a date": a quarterly update
adds a point and keeps the earlier ones. Company stock (RSU) is kept in dollars
with the rate the user typed, and is not counted until it vests (spec v0.35).

Every holding sits in one group by when the money is available:
accessible (anytime, or a "from" date that has passed, or vested stock),
long-term (at retirement, or a "from" date still ahead), future (unvested
stock, shown apart and not counted).

Pure: integer agorot and dollar cents, a rate in 1/10000 of a shekel; no floats.
"""

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

from fin.logic.errors import ConfigError

PENSION, STUDY_FUND, PROVIDENT = "pension", "study_fund", "provident"
INVESTMENTS, RSU, OTHER = "investments", "rsu", "other"
HOLDING_KINDS = (PENSION, STUDY_FUND, PROVIDENT, INVESTMENTS, RSU, OTHER)
ANYTIME, FROM_DATE, RETIREMENT = "anytime", "date", "retirement"
AVAILABILITY = (ANYTIME, FROM_DATE, RETIREMENT)
# What "available" a new holding of each kind starts with (the user can change it).
DEFAULT_AVAILABILITY = {
    PENSION: RETIREMENT, STUDY_FUND: FROM_DATE, PROVIDENT: RETIREMENT,
    INVESTMENTS: ANYTIME, OTHER: ANYTIME,
}  # fmt: skip
ACCESSIBLE, LONG_TERM, FUTURE = "accessible", "long_term", "future"
RATE_SCALE = 10_000  # a rate of 3.7215 shekels per dollar is stored as 37215
MAX_HOLDING_NAME = 40
MAX_AMOUNT = 10**13  # a hundred billion: anything above is a typing slip
_MONTH = re.compile(r"\d{4}-(0[1-9]|1[0-2])")
_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")


@dataclass(frozen=True)
class Holding:
    id: str
    kind: str
    name: str
    deposit_agorot: int | None = None
    available: str = ANYTIME  # RSU: ignored, the vest month decides
    available_from: str | None = None  # YYYY-MM, with available == "date"
    vest: str | None = None  # YYYY-MM, RSU only

    @property
    def in_dollars(self) -> bool:
        return self.kind == RSU


@dataclass(frozen=True)
class BalancePoint:
    as_of: str  # YYYY-MM-DD
    amount: int  # agorot, or dollar cents for RSU
    rate: int | None = None  # RSU only: shekels per dollar times RATE_SCALE

    @property
    def month(self) -> str:
        return self.as_of[:7]


@dataclass(frozen=True)
class MonthWorth:
    month: str
    total: int  # accessible + long-term; future is not counted
    accessible: int
    long_term: int
    future: int


def _month(value: Any, what: str) -> str:
    if not isinstance(value, str) or not _MONTH.fullmatch(value):
        raise ConfigError(f"saving: {what} must be YYYY-MM")
    return value


def parse_holding(item_id: str, fields: Mapping[str, Any]) -> Holding:
    """Validate a holding's details; ConfigError says what is wrong."""
    kind = fields.get("kind")
    if kind not in HOLDING_KINDS:
        raise ConfigError("saving: unknown type")
    name = " ".join(str(fields.get("name") or "").split())
    if not name or len(name) > MAX_HOLDING_NAME:
        raise ConfigError(f"saving: a name of up to {MAX_HOLDING_NAME} characters is needed")
    deposit = fields.get("deposit")
    if deposit is not None and (
        isinstance(deposit, bool) or not isinstance(deposit, int) or not 0 <= deposit < MAX_AMOUNT
    ):
        raise ConfigError("saving: the monthly deposit is a whole number of agorot, zero or more")
    if kind == RSU:
        return Holding(item_id, kind, name, deposit, ANYTIME, None,
                       _month(fields.get("vest"), "the vest month"))  # fmt: skip
    available = fields.get("available") or DEFAULT_AVAILABILITY[kind]
    if available not in AVAILABILITY:
        raise ConfigError("saving: available is anytime, date or retirement")
    since = _month(fields.get("available_from"), "the date") if available == FROM_DATE else None
    return Holding(item_id, kind, name, deposit, available, since)


def parse_point(fields: Mapping[str, Any], holding: Holding) -> BalancePoint:
    """Validate one balance point of a holding."""
    as_of, amount, rate = fields.get("as_of"), fields.get("amount"), fields.get("rate")
    if not isinstance(as_of, str) or not _DATE.fullmatch(as_of):
        raise ConfigError("saving: the date must be YYYY-MM-DD")
    try:
        date.fromisoformat(as_of)
    except ValueError as exc:
        raise ConfigError("saving: no such date") from exc
    if isinstance(amount, bool) or not isinstance(amount, int) or not 0 <= amount < MAX_AMOUNT:
        raise ConfigError("saving: the balance is a whole amount, zero or more")
    if holding.in_dollars:
        if isinstance(rate, bool) or not isinstance(rate, int) or not 0 < rate < 1000 * RATE_SCALE:
            raise ConfigError("saving: a dollar rate above zero is needed")
    elif rate is not None:
        raise ConfigError("saving: only company stock has a dollar rate")
    return BalancePoint(as_of, amount, rate)


def value_agorot(point: BalancePoint) -> int:
    """The point's value in agorot: as is, or dollar cents times the rate, half up."""
    if point.rate is None:
        return point.amount
    exact = Decimal(point.amount) * point.rate / RATE_SCALE
    return int(exact.quantize(Decimal(1), rounding=ROUND_HALF_UP))


def group(holding: Holding, month: str) -> str:
    """Accessible, long-term or future, in a given month."""
    if holding.kind == RSU:
        return ACCESSIBLE if holding.vest is not None and month >= holding.vest else FUTURE
    if holding.available == RETIREMENT:
        return LONG_TERM
    if holding.available == FROM_DATE and holding.available_from and month < holding.available_from:
        return LONG_TERM
    return ACCESSIBLE


def point_for(points: Sequence[BalancePoint], month: str) -> BalancePoint | None:
    """The newest point dated in or before the month; before the first point, the first
    point itself (its value carried back, so typing a holding in adds no jump)."""
    if not points:
        return None
    ordered = sorted(points, key=lambda p: p.as_of)
    found = [p for p in ordered if p.month <= month]
    return found[-1] if found else ordered[0]


def bank_for(bank_by_month: Mapping[str, int], month: str) -> int:
    """The bank at the end of the month: that month's balance, else the latest before it,
    else zero (no file reaches back that far)."""
    known = [m for m in bank_by_month if m <= month]
    return bank_by_month[max(known)] if known else 0


def month_worth(
    month: str,
    bank_by_month: Mapping[str, int],
    holdings: Sequence[tuple[Holding, Sequence[BalancePoint]]],
) -> MonthWorth:
    sums = {ACCESSIBLE: bank_for(bank_by_month, month), LONG_TERM: 0, FUTURE: 0}
    for holding, points in holdings:
        point = point_for(points, month)
        if point is not None:
            sums[group(holding, month)] += value_agorot(point)
    return MonthWorth(month, sums[ACCESSIBLE] + sums[LONG_TERM], sums[ACCESSIBLE],
                      sums[LONG_TERM], sums[FUTURE])  # fmt: skip


def net_worth_series(
    months: Sequence[str],
    bank_by_month: Mapping[str, int],
    holdings: Sequence[tuple[Holding, Sequence[BalancePoint]]],
) -> list[MonthWorth]:
    """Net worth at the end of each month, oldest first."""
    return [month_worth(m, bank_by_month, holdings) for m in sorted(months)]
