"""Which day an installment counts on (design.md §6 "Installments count in their purchase
month", spec v0.39).

Pure. Payment k of an installment deal counts in the month of the purchase plus k-1, on
the purchase's day of the month (the last day when that month is shorter). A regular
purchase counts on its own date. When the money leaves is a separate thing: the billing
date, which Coming up and every cash view keep.
"""

from datetime import date

from fin.logic.planner.pace import days_in


def is_installment(number: int | None, total: int | None) -> bool:
    """A payment of a deal split into more than one installment."""
    return number is not None and total is not None and total > 1 and number >= 1


def count_date(tx_date: date, number: int | None, total: int | None) -> date:
    """The day a card row counts on: the purchase date moved k-1 months for payment k."""
    if not is_installment(number, total):
        return tx_date
    assert number is not None
    months = tx_date.year * 12 + tx_date.month - 1 + number - 1
    year, month = divmod(months, 12)
    last = days_in(year, month + 1)
    return date(year, month + 1, min(tx_date.day, last))
