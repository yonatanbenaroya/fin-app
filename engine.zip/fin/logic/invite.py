"""Invite codes for creating an account (spec v0.35): 12 characters in three groups,
from an alphabet without look-alikes (no 0/O, no 1/I). Pure."""

import re

INVITE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
_CLEAN = re.compile(r"[\s\-_.]")
_CODE = re.compile(r"[A-Z2-9]{12}")


def normalize_invite(text: str) -> str:
    """ "abcd efgh jkmn" -> "ABCD-EFGH-JKMN". Raises ValueError for anything that is not a code."""
    bare = _CLEAN.sub("", text or "").upper()
    if not _CODE.fullmatch(bare) or any(ch not in INVITE_ALPHABET for ch in bare):
        raise ValueError("an invite code is 12 letters and digits, like ABCD-EFGH-JKMN")
    return f"{bare[:4]}-{bare[4:8]}-{bare[8:]}"
