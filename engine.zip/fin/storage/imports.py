"""Importing bank and card exports one file at a time, as the app's import sheet does.

A file is saved in the inbox (so the CLI sees the same files), recognized by
the adapters, checked and stored exactly like `fin ingest`, then everything is
categorized again. Results are counts only: no row's contents leave here.
"""

import hashlib
import sqlite3
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path, PurePath

from fin.storage.categorize_apply import LEGACY_SOURCE, CategorizeSummary
from fin.storage.db import connect, migrate
from fin.storage.ingest.adapter import ControlTotalError
from fin.storage.ingest.pipeline import import_file as store_file
from fin.storage.ingest.registry import build_adapters, find_adapter
from fin.storage.settings import Settings

# The categorization step, handed in by the session (which owns it).
CategorizeFn = Callable[[sqlite3.Connection, Settings], CategorizeSummary]

IMPORT_SUFFIXES = frozenset({".xlsx", ".xls", ".pdf"})
MAX_IMPORT_BYTES = 20 * 1024 * 1024
IMPORTED = "imported"
UNRECOGNIZED = "unrecognized"
REJECTED = "rejected"


@dataclass(frozen=True)
class FileImport:
    # The name the file has in the inbox (it may differ from the name it was sent with).
    name: str
    status: str
    source: str | None = None
    # False when an identical file was already in the inbox and nothing was written.
    saved: bool = False
    rows_seen: int = 0
    rows_inserted: int = 0
    rows_duplicate: int = 0
    rows_quarantined: int = 0
    skipped_no_charge: int = 0


@dataclass(frozen=True)
class SourceStatus:
    source: str
    files: int
    last_import: str | None
    newest_transaction: str | None


def check_upload(name: str, size: int) -> str:
    """Validate an upload's name and size; return the bare file name. Raises ValueError."""
    bare = PurePath(name.replace("\\", "/")).name
    if not bare or bare != name or bare.startswith("."):
        raise ValueError("the file name must be a plain name, without a folder")
    if PurePath(bare).suffix.lower() not in IMPORT_SUFFIXES:
        raise ValueError("only .xlsx, .xls and .pdf files can be imported")
    if not 0 < size <= MAX_IMPORT_BYTES:
        raise ValueError("the file is empty or larger than 20 MB")
    return bare


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _save(inbox: Path, name: str, data: bytes) -> tuple[Path, bool]:
    """Save to the inbox unless an identical file is there; never overwrite another file."""
    inbox.mkdir(parents=True, exist_ok=True)
    digest = _sha256(data)
    for existing in sorted(inbox.iterdir()):
        if existing.is_file() and existing.stat().st_size == len(data):
            if _sha256(existing.read_bytes()) == digest:
                return existing, False
    target = inbox / name
    stem, suffix = target.stem, target.suffix
    number = 2
    while target.exists():
        target = inbox / f"{stem}-{number}{suffix}"
        number += 1
    target.write_bytes(data)
    return target, True


def import_upload(
    settings: Settings, name: str, data: bytes, categorize: CategorizeFn
) -> FileImport:
    """Save one uploaded export, import it and categorize. Raises ValueError for a bad upload.

    A file that is not recognized, or that fails its control check, is not kept
    in the inbox if this upload wrote it there.
    """
    bare = check_upload(name, len(data))
    path, saved = _save(settings.inbox_dir, bare, data)
    adapter = find_adapter(path, build_adapters())
    if adapter is None:
        if saved:
            path.unlink()
        return FileImport(path.name, UNRECOGNIZED)
    conn = connect(settings.db_path)
    try:
        migrate(conn)
        try:
            summary = store_file(conn, adapter, path)
        except ControlTotalError:
            if saved:
                path.unlink()
            return FileImport(path.name, REJECTED, adapter.source)
        categorize(conn, settings)
    finally:
        conn.close()
    return FileImport(
        name=path.name,
        status=IMPORTED,
        source=adapter.source,
        saved=saved,
        rows_seen=summary.rows_seen,
        rows_inserted=summary.rows_inserted,
        rows_duplicate=summary.rows_duplicate,
        rows_quarantined=summary.rows_quarantined,
        skipped_no_charge=summary.skipped_no_charge,
    )


def import_status(conn: sqlite3.Connection, sources: tuple[str, ...]) -> tuple[SourceStatus, ...]:
    """Per source: distinct files imported, the last import time, the newest transaction date."""
    runs = {
        source: (files, last)
        for source, files, last in conn.execute(
            "SELECT source, COUNT(DISTINCT file_sha256), MAX(started_at) FROM import_runs"
            " WHERE source != ? GROUP BY source",
            (LEGACY_SOURCE,),
        )
    }
    newest = dict(
        conn.execute(
            "SELECT source, MAX(tx_date) FROM transactions WHERE source != ? GROUP BY source",
            (LEGACY_SOURCE,),
        ).fetchall()
    )
    return tuple(
        SourceStatus(source, runs.get(source, (0, None))[0], runs.get(source, (0, None))[1],
                     newest.get(source))
        for source in sources
    )  # fmt: skip
