"""Edits made in the app, as changes in the log, and their effect on the ledger.

An edit request names one thing to change: a budget ceiling, a rule, a goal, a
transaction's category, a manual transaction. It becomes field-level changes,
so an edit on another device to a different field never conflicts with it.
The caller checks the resulting settings with the fin.logic validators before
the changes are saved.

Manual transactions and category overrides live only in the change log; on
every categorization they are written into the ledger again (rows of source
"manual" under one fixed import run, never sent as facts) and the overrides
are put on top of what the rules decided.
"""

import sqlite3
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any

from fin.logic import (
    CASH,
    EXPENSE,
    MANUAL_SOURCE,
    MAX_TITLE,
    RATE_SCALE,
    BalancePoint,
    ConfigError,
    FileRow,
    Holding,
    ManualTransaction,
    RenameRule,
    SourceMap,
    State,
    Taxonomy,
    add_months,
    in_order,
    match_provisional,
    order_between,
    parse_holding,
    parse_manual,
    parse_point,
    parse_source_map,
    resolve,
    to_agorot,
)
from fin.storage.categorize_apply import LEGACY_SOURCE
from fin.storage.settings_store import ORDER, VALUE, Editor, decode, encode

MANUAL_RUN = (MANUAL_SOURCE, MANUAL_SOURCE, "1970-01-01T00:00:00+00:00")
OVERRIDE_RULE = "manual"
# entity -> document, for save/delete/move
LISTS = {"rule": "rules", "goal": "goals", "commitment": "goals", "event": "goals"}
RULE_FIELDS = {"match", "category", "source", "exact", "direction", "bucket", "amount", "estimate"}
GOAL_FIELDS = {"name", "amount", "minimum", "months_of_spend", "by"}
COMMITMENT_FIELDS = {"name", "amount", "from", "until", "bucket"}
EVENT_FIELDS = {"month", "label", "amount"}
FIELDS = {
    "rule": RULE_FIELDS,
    "goal": GOAL_FIELDS,
    "commitment": COMMITMENT_FIELDS,
    "event": EVENT_FIELDS,
}


class EditError(ValueError):
    """An edit request that cannot be applied as asked."""


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


def _order_after(items: dict[str, dict[str, Any]], after: str | None, moving: str) -> str:
    """An order key that places an item right after `after` (None: first)."""
    orders = {key: str(f.get(ORDER, "")) for key, f in items.items() if key != moving}
    sequence = in_order(orders)
    if after is not None and after not in orders:
        raise EditError("no such item to place it after")
    index = 0 if after is None else sequence.index(after) + 1
    low = orders[sequence[index - 1]] if index > 0 else None
    high = orders[sequence[index]] if index < len(sequence) else None
    if low is not None and high is not None and not low < high:
        high = None  # equal keys (made on two devices at once): go after both
    return order_between(low or None, high or None)


def _ensure_document(editor: Editor, current: State, document: str) -> None:
    if document not in current.get("document", {}):
        editor.set("document", document, "present", True)


def _shekels(agorot: int) -> int | float:
    whole, rest = divmod(agorot, 100)
    return whole if rest == 0 else agorot / 100


def plan_edit(
    editor: Editor,
    current: State,
    request: dict[str, Any],
    taxonomy: Taxonomy,
    used: Callable[[str], bool] | None = None,
) -> dict[str, Any]:
    """Turn one request into changes on `editor` (not saved). Returns what the app shows next.

    `used(category)` says whether a category has transactions, rules or the user's own
    choices (the session reads the ledger for it); deleting such a category needs a
    replacement."""
    kind = request.get("kind")
    if kind == "budget_ceiling":
        return _budget_ceiling(editor, current, request)
    if kind == "group_label":
        return _group_label(editor, current, request, taxonomy)
    if kind == "group_delete":
        return _group_delete(editor, current, request, taxonomy)
    if kind == "category_add":
        return _category_add(editor, current, request, taxonomy)
    if kind == "category_group":
        return _category_group(editor, current, request, taxonomy)
    if kind == "category_delete":
        return _category_delete(editor, current, request, taxonomy, used)
    if kind == "category_restore":
        return _category_restore(editor, current, request, taxonomy)
    # The undo of the editor's own changes:
    if kind == "budget_remove":
        return _budget_remove(editor, current)
    if kind == "group_restore":
        bucket = request.get("bucket")
        if bucket in current.get("group", {}):
            editor.set("group", bucket, "deleted", None)
        return {"bucket": bucket}
    if kind == "category_flags":
        return _category_flags(editor, current, request)
    if kind == "category_forget":  # the undo of adding one
        name = request.get("category")
        if name in current.get("category_label", {}):
            editor.delete("category_label", name)
        return {"category": name}
    if kind == "category_bring_back":  # the undo of deleting one of the user's own
        name, fields = request.get("category"), request.get("fields") or {}
        for field_name, value in fields.items():
            editor.set("category_label", name, field_name, value)
        return {"category": name}
    if kind == "category_group_back":
        name = request.get("category")
        editor.set("category_label", name, "bucket", request.get("bucket"))
        return {"category": name}
    if kind.endswith("_save") and kind.removesuffix("_save") in LISTS:
        entity = kind.removesuffix("_save")
        items = current.get(entity, {})
        item_id = request.get("id") or _new_id()
        fields = request.get("fields")
        if not isinstance(fields, dict) or not fields:
            raise EditError("the fields to save are needed")
        fields = _typed_fields(entity, fields)
        unknown = set(fields) - FIELDS[entity]
        if unknown:
            raise EditError(f"unknown fields: {', '.join(sorted(unknown))}")
        _ensure_document(editor, current, LISTS[entity])
        old = items.get(item_id, {})
        # Only the fields sent change; a field sent as None is removed. So editing a
        # commitment from the app keeps its bucket, which the app does not show.
        for name, value in fields.items():
            if value is not None and old.get(name) != encode(value):
                editor.set(entity, item_id, name, encode(value))
            elif value is None and old.get(name) is not None:
                editor.set(entity, item_id, name, None)
        if item_id not in items:
            last = in_order({k: str(f.get(ORDER, "")) for k, f in items.items()})
            after = None if request.get("position") == "first" else (last[-1] if last else None)
            order = request.get("order") or _order_after(items, after, item_id)
            editor.set(entity, item_id, ORDER, order)
            return {"id": item_id, "undo": {"kind": f"{entity}_delete", "id": item_id}}
        before = {k: decode(v) for k, v in old.items() if k != ORDER and v is not None}
        added = {k: None for k, v in fields.items() if v is not None and old.get(k) is None}
        return {"id": item_id, "undo": {"kind": kind, "id": item_id, "fields": {**added, **before}}}
    if kind.endswith("_delete") and (
        kind.removesuffix("_delete") in LISTS or kind == "manual_delete"
    ):
        entity = "manual_tx" if kind == "manual_delete" else kind.removesuffix("_delete")
        item_id = request.get("id")
        if item_id not in current.get(entity, {}):
            raise EditError("no such item")
        editor.delete(entity, item_id)
        old = current[entity][item_id]
        if entity == "manual_tx":  # bring it back with the same id and fields
            return {"id": item_id, "undo": {"kind": "manual_save", "id": item_id, **old}}
        back = {k: decode(v) for k, v in old.items() if k != ORDER and v is not None}
        undo = {"kind": f"{entity}_save", "id": item_id, "fields": back, "order": old.get(ORDER)}
        return {"id": item_id, "undo": undo}
    if kind == "hide_charge":
        return _hide_charge(editor, current, request)
    if kind.endswith("_move") and kind.removesuffix("_move") in LISTS:
        entity = kind.removesuffix("_move")
        items = current.get(entity, {})
        item_id = request.get("id")
        if item_id not in items:
            raise EditError("no such item")
        before = items[item_id].get(ORDER)
        # `order` puts it back exactly where it was (the undo of a move).
        order = request.get("order") or _order_after(items, request.get("after"), item_id)
        editor.set(entity, item_id, ORDER, order)
        return {"id": item_id, "undo": {"kind": kind, "id": item_id, "order": before}}
    if kind == "category":
        tx_hash, category = request.get("tx_hash"), request.get("category")
        if not isinstance(tx_hash, str) or not tx_hash:
            raise EditError("a transaction is needed")
        before = current.get("category_override", {}).get(tx_hash, {}).get("category")
        undo = {"kind": "category", "tx_hash": tx_hash, "category": before}
        if category is None:
            if tx_hash in current.get("category_override", {}):
                editor.delete("category_override", tx_hash)
            return {"tx_hash": tx_hash, "undo": undo}
        if category not in taxonomy.categories:
            raise EditError(f"unknown category {category!r}")
        editor.set("category_override", tx_hash, "category", category)
        return {"tx_hash": tx_hash, "undo": undo}
    if kind == "recategorize":
        return _recategorize(editor, current, request, taxonomy)
    if kind == "note":
        return _note(editor, current, request)
    if kind == "profile":
        return _profile(editor, current, request)
    if kind == "retitle":
        return _retitle(editor, current, request, taxonomy)
    if kind == "title":
        return _title(editor, current, request)
    if kind == "rename_save":
        return _rename_save(editor, current, request)
    if kind == "rename_delete":
        return _rename_delete(editor, current, request)
    if kind == "restore_title":
        return _restore_title(editor, current, request, taxonomy)
    if kind == "holding_save":
        return _holding_save(editor, current, request)
    if kind == "holding_delete":
        return _holding_delete(editor, current, request)
    if kind == "holding_point":
        return _holding_point(editor, current, request)
    if kind == "holding_order":  # the undo of a delete puts it back in its place
        item_id, order = request.get("id"), request.get("order")
        if item_id not in current.get("holding", {}) and not editor_has(editor, item_id):
            raise EditError("no such saving")
        editor.set("holding", item_id, ORDER, order)
        return {"id": item_id}
    if kind == "source_map_save":
        return _source_map_save(editor, current, request)
    if kind == "source_map_delete":
        item_id = request.get("id")
        before = current.get("source_map", {}).get(item_id)
        if before is None:
            raise EditError("no such source")
        editor.delete("source_map", item_id)
        return {"id": item_id, "undo": {"kind": "source_map_save", "id": item_id,
                                        "fields": dict(before)}}  # fmt: skip
    if kind == "category_label":
        return _category_label(editor, current, request, taxonomy)
    if kind == "category_move":
        return _category_move(editor, current, request, taxonomy)
    if kind == "batch":
        edits = request.get("edits")
        if not isinstance(edits, list) or not edits:
            raise EditError("a batch needs a list of edits")
        undos = []
        for part in edits:
            if not isinstance(part, dict) or part.get("kind") == "batch":
                raise EditError("a batch holds single edits")
            done = plan_edit(editor, current, part, taxonomy, used)
            undo_part = done.get("undo")
            if undo_part and undo_part.get("kind") == "batch":  # keep batches flat
                undos.extend(reversed(undo_part["edits"]))
            elif undo_part:
                undos.append(undo_part)
        undo = {"kind": "batch", "edits": list(reversed(undos))} if undos else None
        return {"undo": undo}
    if kind == "manual_save":
        item_id = request.get("id") or _new_id()
        keys = ("date", "amount_agorot", "description", "category", "via")
        wanted = {k: request.get(k) for k in keys}
        if "amount_text" in request:  # typed in the app, in shekels: the engine converts it
            try:
                typed = to_agorot(str(request["amount_text"]).strip())
            except (TypeError, ValueError) as exc:
                raise EditError("the amount is not a number") from exc
            if typed <= 0:
                raise EditError("the amount must be more than zero")
            wanted["amount_agorot"] = -typed if request.get("expense", True) else typed
        try:
            parse_manual(item_id, wanted, taxonomy)
        except ConfigError as exc:
            raise EditError(str(exc)) from exc
        old = current.get("manual_tx", {}).get(item_id, {})
        for name, value in wanted.items():
            if old.get(name) != value and (value is not None or name in old):
                editor.set("manual_tx", item_id, name, value)
        if not old:
            return {"id": item_id, "undo": {"kind": "manual_delete", "id": item_id}}
        return {"id": item_id, "undo": {"kind": "manual_save", "id": item_id, **old}}
    raise EditError("unknown kind of edit")


SCOPES = ("one", "merchant", "merchant_amount")


def find_transaction(conn: sqlite3.Connection, tx_hash: str) -> sqlite3.Row | None:
    """One ledger row by its identity (never a row of the legacy workbook)."""
    return conn.execute(
        "SELECT tx_hash, source, source_ref, description, my_share_agorot, tx_date, category,"
        " bucket, flow_kind, billing_date, installment_number, installment_total"
        " FROM transactions WHERE tx_hash = ? AND source != ?",
        (tx_hash, LEGACY_SOURCE),
    ).fetchone()


def merchant_counts(conn: sqlite3.Connection, row: sqlite3.Row) -> tuple[int, int]:
    """How many transactions a merchant rule would cover: by name, and at this exact amount.

    Matches the way the rule matches: the same description, ignoring case, on any card
    or account (the legacy workbook aside).
    """
    wanted = str(row["description"]).casefold()
    same = [
        amount
        for description, amount in conn.execute(
            "SELECT description, my_share_agorot FROM transactions WHERE source != ?",
            (LEGACY_SOURCE,),
        )
        if str(description).casefold() == wanted
    ]
    return len(same), sum(1 for amount in same if amount == row["my_share_agorot"])


def _recategorize(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """A new category for one transaction, every transaction from its merchant (on any
    card or account), or the merchant at this exact amount. A merchant rule goes first,
    so it wins over older rules, and this transaction's own override is cleared so the
    rule shows at once."""
    tx_hash, category, scope = (request.get(k) for k in ("tx_hash", "category", "scope"))
    if scope not in SCOPES:
        raise EditError("the scope is one, merchant or merchant_amount")
    if category not in taxonomy.categories:
        raise EditError(f"unknown category {category!r}")
    row = find_transaction(editor.conn, tx_hash) if isinstance(tx_hash, str) else None
    if row is None:
        raise EditError("no such transaction")
    if scope == "one":
        return plan_edit(
            editor,
            current,
            {"kind": "category", "tx_hash": tx_hash, "category": category},
            taxonomy,
        )
    if row["source"] == MANUAL_SOURCE:
        raise EditError("a manual transaction takes its category directly, not by a rule")
    fields: dict[str, Any] = {"match": row["description"], "exact": True, "category": category}
    if scope == "merchant_amount":
        fields["amount"] = _shekels(row["my_share_agorot"])
    parts: list[dict[str, Any]] = [{"kind": "rule_save", "fields": fields, "position": "first"}]
    if tx_hash in current.get("category_override", {}):
        parts.append({"kind": "category", "tx_hash": tx_hash, "category": None})
    return plan_edit(editor, current, {"kind": "batch", "edits": parts}, taxonomy)


def _title(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """A transaction's own title; None or empty removes it (the rules or the bank's text show)."""
    tx_hash, text = request.get("tx_hash"), request.get("text")
    if not isinstance(tx_hash, str) or find_transaction(editor.conn, tx_hash) is None:
        raise EditError("no such transaction")
    text = _clean_title(text)
    before = current.get("title", {}).get(tx_hash, {}).get("text")
    if not text:
        if tx_hash in current.get("title", {}):
            editor.delete("title", tx_hash)
    elif text != before:
        editor.set("title", tx_hash, "text", text)
    return {"tx_hash": tx_hash, "undo": {"kind": "title", "tx_hash": tx_hash, "text": before}}


def _clean_title(text: Any) -> str:
    if text is not None and not isinstance(text, str):
        raise EditError("a title is text")
    text = " ".join((text or "").split())
    if len(text) > MAX_TITLE:
        raise EditError(f"a title is at most {MAX_TITLE} characters")
    return text


RENAME_FIELDS = ("match", "title", "amount_agorot")


def _rename_save(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """A merchant rename rule: the bank's text (and maybe an exact amount) gets a title.
    A new rule goes first, so it wins over older ones."""
    rules = current.get("rename", {})
    rule_id = request.get("id") or _new_id()
    match, title = request.get("match"), _clean_title(request.get("title"))
    amount = request.get("amount_agorot")
    if not isinstance(match, str) or not match or not title:
        raise EditError("a rename needs the bank's text and a title")
    if amount is not None and (isinstance(amount, bool) or not isinstance(amount, int)):
        raise EditError("the amount is whole agorot")
    old = rules.get(rule_id, {})
    for name, value in (("match", match), ("title", title), ("amount_agorot", amount)):
        if old.get(name) != value and (value is not None or name in old):
            editor.set("rename", rule_id, name, value)
    if rule_id not in rules:
        order = request.get("order") or _order_after(rules, None, rule_id)
        editor.set("rename", rule_id, ORDER, order)
        return {"id": rule_id, "undo": {"kind": "rename_delete", "id": rule_id}}
    return {"id": rule_id}


def _rename_delete(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    rule_id = request.get("id")
    old = current.get("rename", {}).get(rule_id) if isinstance(rule_id, str) else None
    if old is None:
        raise EditError("no such rename")
    editor.delete("rename", rule_id)
    back = {name: old.get(name) for name in RENAME_FIELDS}
    return {"id": rule_id, "undo": {"kind": "rename_save", "id": rule_id, **back,
                                     "order": old.get(ORDER)}}  # fmt: skip


def rename_rules(current: State) -> list[RenameRule]:
    """The rename rules in their order (a newer rule first)."""
    found = current.get("rename", {})
    orders = {rule_id: str(fields.get(ORDER, "")) for rule_id, fields in found.items()}
    return [
        RenameRule(rule_id, str(found[rule_id]["match"]), str(found[rule_id]["title"]),
                   found[rule_id].get("amount_agorot"))
        for rule_id in in_order(orders)
        if found[rule_id].get("match") and found[rule_id].get("title")
    ]  # fmt: skip


def own_titles(current: State) -> dict[str, str]:
    return {
        tx_hash: str(fields["text"])
        for tx_hash, fields in current.get("title", {}).items()
        if fields.get("text")
    }


def _retitle(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """A new title for one transaction, every transaction with the same bank text, or that
    text at this exact amount (design.md §5). Categorization keeps matching the bank's text."""
    tx_hash, scope = request.get("tx_hash"), request.get("scope", "one")
    if scope not in SCOPES:
        raise EditError("the scope is one, merchant or merchant_amount")
    title = _clean_title(request.get("title"))
    if not title:
        raise EditError("a title cannot be empty; restore the original instead")
    row = find_transaction(editor.conn, tx_hash) if isinstance(tx_hash, str) else None
    if row is None:
        raise EditError("no such transaction")
    if scope == "one":
        return _title(editor, current, {"tx_hash": tx_hash, "text": title})
    exact = row["my_share_agorot"] if scope == "merchant_amount" else None
    rule = {
        "kind": "rename_save",
        "match": row["description"],
        "title": title,
        "amount_agorot": exact,
    }
    parts: list[dict[str, Any]] = [rule]
    if tx_hash in current.get("title", {}):  # this row's own title would hide the rule
        parts.append({"kind": "title", "tx_hash": tx_hash, "text": None})
    return plan_edit(editor, current, {"kind": "batch", "edits": parts}, taxonomy)


def _restore_title(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """Back to the bank's text: drop this row's own title and every rename rule for it."""
    tx_hash = request.get("tx_hash")
    row = find_transaction(editor.conn, tx_hash) if isinstance(tx_hash, str) else None
    if row is None:
        raise EditError("no such transaction")
    parts: list[dict[str, Any]] = []
    if tx_hash in current.get("title", {}):
        parts.append({"kind": "title", "tx_hash": tx_hash, "text": None})
    parts.extend(
        {"kind": "rename_delete", "id": rule.id}
        for rule in rename_rules(current)
        if rule.matches(row["description"], row["my_share_agorot"])
    )
    if not parts:
        return {"tx_hash": tx_hash, "undo": None}
    return plan_edit(editor, current, {"kind": "batch", "edits": parts}, taxonomy)


def _typed_fields(entity: str, fields: dict[str, Any]) -> dict[str, Any]:
    """Fields as the app types them, turned into the YAML document's own form.

    `amount_text` is shekels as typed (the engine converts, never the browser); an
    event's `expense` makes its amount money out. A commitment's `payments` count
    sets `until` from `from`.
    """
    fields = dict(fields)
    if "minimum_text" in fields:  # a goal's smaller acceptable amount; empty removes it
        text = str(fields.pop("minimum_text") or "").strip()
        if not text:
            fields["minimum"] = None
        else:
            try:
                fields["minimum"] = _shekels(to_agorot(text))
            except (TypeError, ValueError) as exc:
                raise EditError("the minimum is not a number") from exc
    if "amount_text" in fields:
        try:
            agorot = to_agorot(str(fields.pop("amount_text")).strip())
        except (TypeError, ValueError) as exc:
            raise EditError("the amount is not a number") from exc
        if agorot <= 0:
            raise EditError("the amount must be more than zero")
        if entity == "event" and fields.pop("expense", True):
            agorot = -agorot
        fields["amount"] = _shekels(agorot)
    fields.pop("expense", None)
    if entity == "commitment" and "payments" in fields:
        count, first = fields.pop("payments"), fields.get("from")
        if isinstance(count, bool) or not isinstance(count, int) or not 1 <= count <= 600:
            raise EditError("the number of payments is a whole number from 1")
        if not isinstance(first, str):
            raise EditError("a first month is needed")
        fields["until"] = add_months(first, count - 1)
    return fields


def charge_key(month: str, name: str, amount: int) -> str:
    """The identity of a card charge in "Coming up": its month, bank text and amount."""
    return f"{month}|{name}|{amount}"


def _hide_charge(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """Hide a card charge that duplicates a payment the user already lists (design.md §6)."""
    key, hidden = request.get("key"), request.get("hidden", True)
    if not isinstance(key, str) or key.count("|") != 2:
        raise EditError("a card charge is needed")
    was = key in current.get("hidden_charge", {})
    if hidden and not was:
        editor.set("hidden_charge", key, "hidden", True)
    elif not hidden and was:
        editor.delete("hidden_charge", key)
    return {"key": key, "undo": {"kind": "hide_charge", "key": key, "hidden": was}}


def hidden_charges(current: State) -> set[str]:
    return set(current.get("hidden_charge", {}))


def item_ids(current: State, entity: str) -> list[str]:
    """A list entity's ids in their order: the same order the document lists them in."""
    found = current.get(entity, {})
    return in_order({key: str(fields.get(ORDER, "")) for key, fields in found.items()})


MAX_NAME = 40
PROFILE = "main"


def _profile(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """The name the greeting uses, kept in the account so every device shows it."""
    name = request.get("name")
    if name is not None and not isinstance(name, str):
        raise EditError("a name is text")
    name = " ".join((name or "").split())
    if len(name) > MAX_NAME:
        raise EditError(f"a name is at most {MAX_NAME} characters")
    before = current.get("profile", {}).get(PROFILE, {}).get("name")
    if not name:
        if PROFILE in current.get("profile", {}):
            editor.delete("profile", PROFILE)
    elif name != before:
        editor.set("profile", PROFILE, "name", name)
    return {"name": name or None, "undo": {"kind": "profile", "name": before}}


def profile_name(current: State) -> str | None:
    return current.get("profile", {}).get(PROFILE, {}).get("name") or None


HOLDING_FIELDS = ("kind", "name", "deposit", "available", "available_from", "vest")


def _money_text(text: Any, what: str) -> int:
    """Shekels (or dollars) as typed, in agorot (or cents); the engine converts, never the
    browser."""
    try:
        value = to_agorot(str(text).strip())
    except (TypeError, ValueError) as exc:
        raise EditError(f"{what} is not a number") from exc
    if value < 0:
        raise EditError(f"{what} cannot be below zero")
    return value


def _rate_text(text: Any) -> int:
    """A dollar rate as typed ("3.72"), in 1/10000 of a shekel."""
    try:
        scaled = Decimal(str(text).strip().replace(",", ".")) * RATE_SCALE
    except (InvalidOperation, ValueError) as exc:
        raise EditError("the dollar rate is not a number") from exc
    if scaled != scaled.to_integral_value() or scaled <= 0:
        raise EditError("the dollar rate needs at most four decimals, above zero")
    return int(scaled)


def editor_has(editor: Editor, item_id: Any) -> bool:
    """True when this edit (a batch) already recreated the saving."""
    return any(c.entity == "holding" and c.key == item_id for c in editor.made)


def _points_of(current: State, holding_id: str) -> dict[str, dict[str, Any]]:
    prefix = f"{holding_id}|"
    return {k: f for k, f in current.get("holding_balance", {}).items() if k.startswith(prefix)}


def _holding_point(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """Set or remove one balance point as stored (the undo of a save or a delete)."""
    key = f"{request.get('id')}|{request.get('as_of')}"
    before = current.get("holding_balance", {}).get(key)
    undo = (
        {"kind": "holding_point", "id": request.get("id"), "as_of": request.get("as_of"),
         **({"amount": before.get("amount"), "rate": before.get("rate")} if before else
            {"remove": True})}
    )  # fmt: skip
    if request.get("remove"):
        if before is not None:
            editor.delete("holding_balance", key)
        return {"undo": undo}
    for name in ("amount", "rate"):
        if before is None or before.get(name) != request.get(name):
            editor.set("holding_balance", key, name, request.get(name))
    return {"undo": undo}


def _holding_save(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """A saving typed in by the user (design.md §5 Savings): its details, and optionally a
    balance as of a date (`amount_text`, `as_of`, and `rate_text` for company stock)."""
    holdings = current.get("holding", {})
    item_id = request.get("id") or _new_id()
    if not isinstance(item_id, str) or "|" in item_id:
        raise EditError("no such saving")
    before = holdings.get(item_id)
    fields = request.get("fields") or {}
    if not isinstance(fields, dict):
        raise EditError("a saving needs its fields")
    wanted = {name: (before or {}).get(name) for name in HOLDING_FIELDS}
    for name in HOLDING_FIELDS:
        if name in fields:
            wanted[name] = fields[name]
    if "deposit_text" in fields:
        text = str(fields["deposit_text"] or "").strip()
        wanted["deposit"] = _money_text(text, "the monthly deposit") if text else None
    try:
        holding = parse_holding(item_id, wanted)
    except ConfigError as exc:
        raise EditError(str(exc)) from exc
    points = _points_of(current, item_id)
    if before is not None and points and (before.get("kind") == "rsu") != holding.in_dollars:
        raise EditError("company stock keeps its dollar balances: add a new saving instead")
    for name, value in wanted.items():
        if before is None or before.get(name) != value:
            editor.set("holding", item_id, name, value)
    if before is None:
        last = in_order({k: str(f.get(ORDER, "")) for k, f in holdings.items()})
        editor.set("holding", item_id, ORDER, _order_after(holdings, last[-1] if last else None,
                                                           item_id))  # fmt: skip
    undos: list[dict[str, Any]] = []
    if "amount_text" in request:
        point = _new_point(holding, request)
        undos.append(_holding_point(editor, current, {"id": item_id, "as_of": point.as_of,
                                                      "amount": point.amount,
                                                      "rate": point.rate})["undo"])  # fmt: skip
    if before is None:
        undo: dict[str, Any] = {"kind": "holding_delete", "id": item_id}
    else:
        restore = {"kind": "holding_save", "id": item_id,
                   "fields": {n: before.get(n) for n in HOLDING_FIELDS}}  # fmt: skip
        undo = {"kind": "batch", "edits": [*undos, restore]}
    return {"id": item_id, "undo": undo}


def _new_point(holding: Holding, request: dict[str, Any]) -> BalancePoint:
    amount = _money_text(request.get("amount_text"), "the balance")
    rate = _rate_text(request.get("rate_text")) if holding.in_dollars else None
    try:
        return parse_point({"as_of": request.get("as_of"), "amount": amount, "rate": rate},
                           holding)  # fmt: skip
    except ConfigError as exc:
        raise EditError(str(exc)) from exc


def _holding_delete(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """Delete a saving and every balance it had; the undo brings all of it back."""
    item_id = request.get("id")
    before = current.get("holding", {}).get(item_id)
    if before is None:
        raise EditError("no such saving")
    restore: list[dict[str, Any]] = [
        {"kind": "holding_save", "id": item_id,
         "fields": {n: before.get(n) for n in HOLDING_FIELDS}},
    ]  # fmt: skip
    for key, fields in sorted(_points_of(current, item_id).items()):
        editor.delete("holding_balance", key)
        restore.append({"kind": "holding_point", "id": item_id, "as_of": key.split("|", 1)[1],
                        "amount": fields.get("amount"), "rate": fields.get("rate")})  # fmt: skip
    editor.delete("holding", item_id)
    if ORDER in before:
        restore.append({"kind": "holding_order", "id": item_id, "order": before[ORDER]})
    return {"id": item_id, "undo": {"kind": "batch", "edits": restore}}


def holdings(current: State) -> list[tuple[Holding, list[BalancePoint]]]:
    """Every valid saving in the user's order, with its balance points oldest first. A bad
    one is left out, never fatal."""
    found = []
    items = current.get("holding", {})
    order = in_order({k: str(f.get(ORDER, "")) for k, f in items.items()})
    for item_id in order:
        try:
            holding = parse_holding(item_id, items[item_id])
        except ConfigError:
            continue
        points = []
        for key, fields in sorted(_points_of(current, item_id).items()):
            try:
                points.append(parse_point({"as_of": key.split("|", 1)[1], **fields}, holding))
            except ConfigError:
                continue
        found.append((holding, points))
    return found


SOURCE_MAP_FIELDS = (
    "name", "kind", "sheet", "headers", "date", "description", "amount", "debit", "credit",
    "balance", "billing", "date_order", "spending", "bank_label",
)  # fmt: skip


def _source_map_save(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """A source the user mapped by hand (design.md §12 item 9): the whole mapping at once.
    `file` (optional) names an inbox file to import with it right after saving."""
    fields = request.get("fields")
    if not isinstance(fields, dict):
        raise EditError("a source needs its fields")
    maps = current.get("source_map", {})
    item_id = request.get("id") or _new_id()
    if not isinstance(item_id, str):
        raise EditError("no such source")
    wanted = {name: fields.get(name) for name in SOURCE_MAP_FIELDS}
    try:
        parse_source_map(item_id, wanted)
    except ConfigError as exc:
        raise EditError(str(exc)) from exc
    before = maps.get(item_id)
    for name, value in wanted.items():
        if before is None or before.get(name) != value:
            editor.set("source_map", item_id, name, value)
    undo = (
        {"kind": "source_map_delete", "id": item_id}
        if before is None
        else {"kind": "source_map_save", "id": item_id, "fields": dict(before)}
    )
    return {"id": item_id, "source": f"map_{item_id}", "undo": undo, "file": request.get("file")}


def source_maps(current: State) -> list[SourceMap]:
    """Every mapped source that is valid, oldest id order (a bad one is left out, never fatal)."""
    found = []
    for item_id, fields in sorted(current.get("source_map", {}).items()):
        try:
            found.append(parse_source_map(item_id, fields))
        except ConfigError:
            continue
    return found


MAX_LABEL = 40
LABEL_LANGS = ("he", "en")


def _category(request: dict[str, Any], taxonomy: Taxonomy) -> str:
    name = request.get("category")
    if not isinstance(name, str) or name not in taxonomy.categories:
        raise EditError("no such category")
    return name


def _category_label(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """A category's own name in one language or both (design.md §13 item 8). The key the
    ledger and the rules use never changes; empty text brings back the default name."""
    name = _category(request, taxonomy)
    before = current.get("category_label", {}).get(name, {})
    undo: dict[str, Any] = {"kind": "category_label", "category": name}
    for lang in LABEL_LANGS:
        if lang not in request:
            continue
        text = request[lang]
        if text is not None and not isinstance(text, str):
            raise EditError("a name is text")
        text = " ".join((text or "").split())
        if len(text) > MAX_LABEL:
            raise EditError(f"a name is at most {MAX_LABEL} characters")
        if lang == "he" and text == name:
            text = ""  # the key itself is the Hebrew default
        undo[lang] = before.get(lang)
        if (text or None) != before.get(lang):
            editor.set("category_label", name, lang, text or None)
    return {"category": name, "undo": undo}


def _group(taxonomy: Taxonomy, name: str) -> tuple[str, str | None]:
    spec = taxonomy.categories[name]
    return (spec.kind, spec.bucket if spec.kind == EXPENSE else None)


def category_order(current: State, taxonomy: Taxonomy) -> list[str]:
    """Every category key in display order: groups as in the taxonomy, and inside a group
    the user's order first, then the taxonomy's for categories never moved."""
    stored = current.get("category_label", {})
    names = list(taxonomy.categories)
    first: dict[tuple[str, str | None], int] = {}
    for index, name in enumerate(names):
        first.setdefault(_group(taxonomy, name), index)

    def key(item: tuple[int, str]) -> tuple[int, bool, str, int]:
        index, name = item
        order = stored.get(name, {}).get(ORDER)
        return (first[_group(taxonomy, name)], order is None, str(order or ""), index)

    return [name for _, name in sorted(enumerate(names), key=key)]


def _category_move(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """Place a category right after another of its group (`after`; None: first)."""
    name = _category(request, taxonomy)
    mine = _group(taxonomy, name)
    group = [n for n in category_order(current, taxonomy) if _group(taxonomy, n) == mine]
    after = request.get("after")
    if after is not None and (after not in group or after == name):
        raise EditError("a category moves only inside its group")
    position = group.index(name)
    previous = group[position - 1] if position else None
    undo = {"kind": "category_move", "category": name, "after": previous}
    stored = current.get("category_label", {})
    orders = {n: stored.get(n, {}).get(ORDER) for n in group}
    if any(order is None for order in orders.values()):  # first move in this group: number it
        last = None
        for n in group:
            last = order_between(last, None)
            orders[n] = last
            if n != name:
                editor.set("category_label", n, ORDER, last)
    items = {n: {ORDER: order} for n, order in orders.items()}
    editor.set("category_label", name, ORDER, _order_after(items, after, name))
    return {"category": name, "undo": undo}


def group_labels(current: State) -> dict[str, dict[str, str]]:
    """The user's own spending group names: group key -> {language: name}, only those set."""
    return {
        name: {lang: fields[lang] for lang in LABEL_LANGS if fields.get(lang)}
        for name, fields in current.get("group", {}).items()
        if any(fields.get(lang) for lang in LABEL_LANGS)
    }


def category_labels(current: State) -> dict[str, dict[str, str]]:
    """The user's own category names: key -> {language: name}, only those set."""
    return {
        name: {lang: fields[lang] for lang in LABEL_LANGS if fields.get(lang)}
        for name, fields in current.get("category_label", {}).items()
        if any(fields.get(lang) for lang in LABEL_LANGS)
    }


# ---- Categories and budgets editor, second part (design.md §6)

RENT_GROUP = "שכר דירה"  # tracked apart from the pace: it can be renamed, never deleted
STEP = 10_000  # a budget step: 100 shekels, in agorot


def expense_groups(current: State, taxonomy: Taxonomy) -> list[str]:
    """The expense groups in the taxonomy's order, without the ones the user deleted."""
    gone = {k for k, f in current.get("group", {}).items() if f.get("deleted")}
    found: list[str] = []
    for spec in taxonomy.categories.values():
        if spec.kind == EXPENSE and spec.bucket and spec.bucket not in found:
            found.append(spec.bucket)
    return [g for g in found if g not in gone]


def _pick_group(request: dict[str, Any], current: State, taxonomy: Taxonomy) -> str:
    bucket = request.get("bucket")
    if not isinstance(bucket, str) or bucket not in expense_groups(current, taxonomy):
        raise EditError("no such group")
    return bucket


def _ceiling(current: State, bucket: str) -> int | None:
    fields = current.get("budget_ceiling", {}).get(bucket)
    if not fields or fields.get(VALUE) is None:
        return None
    return to_agorot(decode(fields[VALUE]))


def _budget_ceiling(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """A group's monthly budget: `step` (+1 / -1: to the next 100 shekels), `amount_text` as
    typed, `amount_agorot`, or none of them to remove it. The first one creates the budget."""
    bucket = request.get("bucket")
    if not isinstance(bucket, str) or not bucket:
        raise EditError("a group is needed")
    ceilings = current.get("budget_ceiling", {})
    before = _ceiling(current, bucket)
    undo: dict[str, Any] = {"kind": "budget_ceiling", "bucket": bucket, "amount_agorot": before,
                            "order": ceilings.get(bucket, {}).get(ORDER)}  # fmt: skip
    step = request.get("step")
    if step is not None:
        if step not in (1, -1):
            raise EditError("a step is +1 or -1")
        now = before or 0
        amount = (now // STEP + 1) * STEP if step == 1 else max(0, -(-now // STEP) * STEP - STEP)
    elif "amount_text" in request:
        amount = _money_text(request["amount_text"], "the budget")
    else:
        amount = request.get("amount_agorot")
    if "budget" not in current.get("document", {}):
        if amount is None:
            return {"bucket": bucket, "undo": None}
        editor.set("document", "budget", "present", True)
        editor.set("setting", "budget.start_month", VALUE, encode(date.today().isoformat()[:7]))
        undo = {"kind": "budget_remove"}
    if amount is None:
        if bucket in ceilings:
            editor.delete("budget_ceiling", bucket)
        return {"bucket": bucket, "undo": undo}
    if isinstance(amount, bool) or not isinstance(amount, int) or amount < 0:
        raise EditError("the budget is a whole number of agorot, zero or more")
    editor.set("budget_ceiling", bucket, VALUE, encode(_shekels(amount)))
    if request.get("order"):
        editor.set("budget_ceiling", bucket, ORDER, request["order"])
    elif bucket not in ceilings:
        last = in_order({k: str(f.get(ORDER, "")) for k, f in ceilings.items()})
        editor.set("budget_ceiling", bucket, ORDER,
                   _order_after(ceilings, last[-1] if last else None, bucket))  # fmt: skip
    return {"bucket": bucket, "amount": amount, "undo": undo}


def _budget_remove(editor: Editor, current: State) -> dict[str, Any]:
    """The undo of creating the budget: the document and its ceilings go again."""
    for bucket in current.get("budget_ceiling", {}):
        editor.delete("budget_ceiling", bucket)
    for key in current.get("setting", {}):
        if key.startswith("budget."):
            editor.delete("setting", key)
    editor.delete("document", "budget")
    return {"undo": None}


def _labels(
    editor: Editor, entity: str, key: str, current: State, request: dict[str, Any], default_he: str
) -> dict[str, Any]:
    """Names per language for a category or a group; empty brings back the default."""
    before = current.get(entity, {}).get(key, {})
    undo: dict[str, Any] = {}
    for lang in LABEL_LANGS:
        if lang not in request:
            continue
        text = request[lang]
        if text is not None and not isinstance(text, str):
            raise EditError("a name is text")
        text = " ".join((text or "").split())
        if len(text) > MAX_LABEL:
            raise EditError(f"a name is at most {MAX_LABEL} characters")
        if lang == "he" and text == default_he:
            text = ""
        undo[lang] = before.get(lang)
        if (text or None) != before.get(lang):
            editor.set(entity, key, lang, text or None)
    return undo


def _group_label(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    bucket = _pick_group(request, current, taxonomy)
    undo = _labels(editor, "group", bucket, current, request, bucket)
    return {"bucket": bucket, "undo": {"kind": "group_label", "bucket": bucket, **undo}}


def _group_delete(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """Delete an empty expense group (its categories are moved first, in the same batch).
    Its budget leaves the total; at least one group always remains."""
    bucket = _pick_group(request, current, taxonomy)
    if bucket == RENT_GROUP:
        raise EditError("rent is tracked apart and stays")
    if len(expense_groups(current, taxonomy)) <= 1:
        raise EditError("at least one group remains")
    inside = [
        n for n, spec in taxonomy.categories.items()
        if spec.kind == EXPENSE and spec.bucket == bucket
    ]  # fmt: skip
    into = request.get("into")
    moved: list[dict[str, Any]] = []
    if inside:
        if (
            not isinstance(into, str)
            or into == bucket
            or into not in expense_groups(current, taxonomy)
        ):
            raise EditError("choose the group its categories move to")
        labels = current.get("category_label", {})
        for name in inside:
            moved.append({"kind": "category_group_back", "category": name,
                          "bucket": labels.get(name, {}).get("bucket")})  # fmt: skip
            editor.set("category_label", name, "bucket", into)
    restore: list[dict[str, Any]] = [{"kind": "group_restore", "bucket": bucket}, *moved]
    before = _ceiling(current, bucket)
    if before is not None:
        editor.delete("budget_ceiling", bucket)
        restore.append({"kind": "budget_ceiling", "bucket": bucket, "amount_agorot": before,
                        "order": current["budget_ceiling"][bucket].get(ORDER)})  # fmt: skip
    editor.set("group", bucket, "deleted", True)
    return {"bucket": bucket, "undo": {"kind": "batch", "edits": restore}}


def _category(request: dict[str, Any], taxonomy: Taxonomy) -> str:
    name = request.get("category")
    if not isinstance(name, str) or name not in taxonomy.categories:
        raise EditError("no such category")
    return name


def _category_add(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """A category of the user's in an expense group: one name is enough (it is the key, and
    the other language falls back to it)."""
    bucket = _pick_group(request, current, taxonomy)
    name = " ".join(str(request.get("name") or "").split())
    if not name or len(name) > MAX_LABEL:
        raise EditError(f"a name of up to {MAX_LABEL} characters is needed")
    if (
        name in taxonomy.categories
        or name in taxonomy.aliases
        or name in current.get("category_label", {})
    ):
        raise EditError("there is already a category by that name")
    editor.set("category_label", name, "added", True)
    editor.set("category_label", name, "bucket", bucket)
    return {"category": name, "undo": {"kind": "category_forget", "category": name}}


def _category_group(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """Move an expense category to another group, for every month."""
    name = _category(request, taxonomy)
    if taxonomy.categories[name].kind != EXPENSE:
        raise EditError("only spending categories have a group")
    bucket = _pick_group(request, current, taxonomy)
    before = current.get("category_label", {}).get(name, {}).get("bucket")
    if bucket != taxonomy.categories[name].bucket or before is not None:
        editor.set("category_label", name, "bucket", bucket)
    undo_bucket = before if before is not None else None
    return {"category": name, "undo": {"kind": "category_group_back", "category": name,
                                       "bucket": undo_bucket}}  # fmt: skip


def _category_delete(
    editor: Editor,
    current: State,
    request: dict[str, Any],
    taxonomy: Taxonomy,
    used: Callable[[str], bool] | None,
) -> dict[str, Any]:
    """Delete a category. Unused: a category of the user's goes, a built-in one is hidden.
    Used (transactions, rules or the user's own choices): `into` names the category they
    follow from now on; nothing in the bank files changes."""
    name = _category(request, taxonomy)
    if name in taxonomy.special or name == CASH_CATEGORY:
        raise EditError("the app needs this category; it cannot be deleted")
    fields = current.get("category_label", {}).get(name, {})
    into = request.get("into")
    undo_fields = {k: fields.get(k) for k in ("hidden", "merged_into")}
    if used is not None and used(name):
        if not isinstance(into, str) or into == name or into not in taxonomy.categories:
            raise EditError("choose where its transactions go")
        if taxonomy.categories[into].kind != taxonomy.categories[name].kind:
            raise EditError("choose a category of the same kind")
        editor.set("category_label", name, "merged_into", into)
    elif fields.get("added"):
        editor.delete("category_label", name)
        return {"category": name, "undo": {"kind": "category_bring_back", "category": name,
                                           "fields": dict(fields)}}  # fmt: skip
    else:
        editor.set("category_label", name, "hidden", True)
    return {"category": name, "undo": {"kind": "category_flags", "category": name, **undo_fields}}


def _category_restore(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """Bring back a deleted category (from the "Deleted" list). If its group was deleted
    meanwhile, it comes back in the first group."""
    name = request.get("category")
    fields = current.get("category_label", {}).get(name)
    if not isinstance(name, str) or not fields or not (fields.get("hidden")
                                                         or fields.get("merged_into")):  # fmt: skip
        raise EditError("no such deleted category")
    undo = {"kind": "category_flags", "category": name,
            **{k: fields.get(k) for k in ("hidden", "merged_into")}}  # fmt: skip
    for flag in ("hidden", "merged_into"):
        if fields.get(flag):
            editor.set("category_label", name, flag, None)
    groups = expense_groups(current, taxonomy)
    spec_bucket = fields.get("bucket") or (taxonomy.categories.get(name).bucket
                                           if name in taxonomy.categories else None)  # fmt: skip
    if spec_bucket is None:
        from fin.storage.config_files import load_taxonomy  # noqa: PLC0415 - the built-in one

        base = load_taxonomy().categories.get(name)
        spec_bucket = base.bucket if base else None
    if spec_bucket is not None and groups and spec_bucket not in groups:
        editor.set("category_label", name, "bucket", groups[0])
    return {"category": name, "undo": undo}


def _category_flags(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """Set a category's deletion flags back as they were (an undo)."""
    name = request.get("category")
    if not isinstance(name, str) or not name:
        raise EditError("no such category")
    before = current.get("category_label", {}).get(name, {})
    for flag in ("hidden", "merged_into"):
        if before.get(flag) != request.get(flag):
            editor.set("category_label", name, flag, request.get(flag))
    return {"category": name}


MAX_NOTE = 500


def _note(editor: Editor, current: State, request: dict[str, Any]) -> dict[str, Any]:
    """A free-text note on any transaction, imported or manual. Empty text removes it."""
    tx_hash, text = request.get("tx_hash"), request.get("text")
    if not isinstance(tx_hash, str) or find_transaction(editor.conn, tx_hash) is None:
        raise EditError("no such transaction")
    if text is not None and not isinstance(text, str):
        raise EditError("a note is text")
    text = (text or "").strip()
    if len(text) > MAX_NOTE:
        raise EditError(f"a note is at most {MAX_NOTE} characters")
    before = current.get("note", {}).get(tx_hash, {}).get("text")
    undo = {"kind": "note", "tx_hash": tx_hash, "text": before}
    if not text:
        if tx_hash in current.get("note", {}):
            editor.delete("note", tx_hash)
    elif text != before:
        editor.set("note", tx_hash, "text", text)
    return {"tx_hash": tx_hash, "undo": undo}


def notes(current: State) -> dict[str, str]:
    """Every note, by tx_hash."""
    return {
        tx_hash: str(fields["text"])
        for tx_hash, fields in current.get("note", {}).items()
        if fields.get("text")
    }


def _manual_run_id(conn: sqlite3.Connection) -> int:
    found = conn.execute(
        "SELECT id FROM import_runs WHERE source = ? AND file_sha256 = ? AND started_at = ?",
        MANUAL_RUN,
    ).fetchone()
    if found:
        return found[0]
    cursor = conn.execute(
        "INSERT INTO import_runs (source, file_sha256, started_at, rows_seen, rows_inserted,"
        " rows_duplicate, rows_quarantined) VALUES (?, ?, ?, 0, 0, 0, 0)",
        MANUAL_RUN,
    )
    return int(cursor.lastrowid or 0)


OFFSET = "manual-offset:"  # a cash item's balancing row: it takes its amount out of "cash"
CASH_CATEGORY = "מזומן"  # where ATM withdrawals go (config/categories.yaml)


@dataclass(frozen=True)
class ManualPlan:
    """What the ledger holds for the manual items, worked out from the change log."""

    rows: dict[str, ManualTransaction]  # tx_hash -> the item, for each row to write
    offsets: dict[str, ManualTransaction]  # offset tx_hash -> the cash item it balances
    matched: dict[str, str]  # manual id -> the file row's tx_hash that replaced it
    pending: frozenset[str]  # tx_hashes of provisional items still waiting for a file row


def manual_plan(conn: sqlite3.Connection, current: State, taxonomy: Taxonomy) -> ManualPlan:
    """Provisional items that a file row now covers are left out; cash items get a
    balancing row so the cash line is split, not counted twice (decided 2026-11-18)."""
    items = []
    for item_id, fields in current.get("manual_tx", {}).items():
        try:
            items.append(parse_manual(item_id, fields, taxonomy))
        except ConfigError:
            continue  # a change from a newer app version; it waits for an update
    sources = sorted({item.via for item in items if item.provisional and item.via})
    rows = []
    if sources:
        marks = ", ".join("?" for _ in sources)
        rows = [
            FileRow(row[0], row[1], row[2], row[3])
            for row in conn.execute(
                "SELECT tx_hash, source, tx_date, my_share_agorot FROM transactions"
                f" WHERE source IN ({marks})",
                sources,
            )
        ]
    matched = match_provisional(items, rows)
    keep = {item.tx_hash: item for item in items if item.id not in matched}
    offsets = {
        f"{OFFSET}{item.id}": item
        for item in keep.values()
        if item.via == CASH
        and item.amount_agorot < 0
        and item.category not in (None, CASH_CATEGORY)
        and CASH_CATEGORY in taxonomy.categories
    }
    pending = frozenset(tx_hash for tx_hash, item in keep.items() if item.provisional)
    return ManualPlan(keep, offsets, matched, pending)


def write_manual(conn: sqlite3.Connection, current: State, taxonomy: Taxonomy) -> int:
    """Make the ledger's manual rows match the change log. Returns how many there are."""
    plan = manual_plan(conn, current, taxonomy)
    wanted: dict[str, tuple[str, str, str, int]] = {
        tx_hash: (item.tx_date, item.budget_month, item.description, item.amount_agorot)
        for tx_hash, item in plan.rows.items()
    }
    wanted.update(
        (tx_hash, (item.tx_date, item.budget_month, item.description, -item.amount_agorot))
        for tx_hash, item in plan.offsets.items()
    )
    stored = {
        row[0]
        for row in conn.execute(
            "SELECT tx_hash FROM transactions WHERE source = ?", (MANUAL_SOURCE,)
        )
    }
    if not wanted and not stored:
        return 0  # nothing by hand: the ledger stays exactly as imported
    with conn:
        run_id = _manual_run_id(conn)
        for gone in stored - wanted.keys():
            conn.execute("DELETE FROM transactions WHERE tx_hash = ?", (gone,))
        for tx_hash, (when, month, text, amount) in wanted.items():
            values = (when, month, text, amount, amount, when)
            if tx_hash in stored:
                conn.execute(
                    "UPDATE transactions SET tx_date = ?, budget_month = ?, description = ?,"
                    " total_amount_agorot = ?, my_share_agorot = ?, count_date = ?"
                    " WHERE tx_hash = ?",
                    (*values, tx_hash),
                )
            else:
                conn.execute(
                    "INSERT INTO transactions (tx_hash, source, source_ref, tx_date, budget_month,"
                    " description, total_amount_agorot, my_share_agorot, count_date,"
                    " import_run_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (tx_hash, MANUAL_SOURCE, tx_hash.split(":", 1)[1], *values, run_id),
                )
    return len(plan.rows)


def apply_overrides(conn: sqlite3.Connection, current: State, taxonomy: Taxonomy) -> int:
    """Put the categories set by hand on top of the rules. Returns how many rows changed.

    A manual item's category also goes to the file row that replaced it, and a cash
    item's balancing row always counts as cash.
    """
    chosen = {
        tx_hash: fields.get("category")
        for tx_hash, fields in current.get("category_override", {}).items()
    }
    plan = manual_plan(conn, current, taxonomy)
    for item_id, fields in current.get("manual_tx", {}).items():
        if fields.get("category"):
            chosen.setdefault(f"{MANUAL_SOURCE}:{item_id}", fields["category"])
            if item_id in plan.matched:
                chosen.setdefault(plan.matched[item_id], fields["category"])
    for tx_hash in plan.offsets:
        chosen[tx_hash] = CASH_CATEGORY
    updates = []
    for tx_hash, category in chosen.items():
        if taxonomy.canonical(category) in taxonomy.categories:  # a deleted one: its replacement
            result = resolve(taxonomy, category, OVERRIDE_RULE)
            updates.append((result.category, result.bucket, result.kind, OVERRIDE_RULE, tx_hash))
    with conn:
        cursor = conn.executemany(
            "UPDATE transactions SET category = ?, bucket = ?, flow_kind = ?, category_rule = ?"
            " WHERE tx_hash = ? AND source != ?",
            [(*update, LEGACY_SOURCE) for update in updates],
        )
    return cursor.rowcount if updates else 0
