"""Edits made in the app, as changes in the log, and their effect on the ledger.

An edit request names one thing to change: a budget ceiling, a rule, a goal, a
transaction's category, a manual transaction. It becomes field-level changes,
so an edit on another device to a different field never conflicts with it.
The caller checks the resulting settings with the fin.logic validators before
the changes are saved.

Manual transactions and category overrides live only in the change log; on
every categorization they are written into the ledger again (rows of source
"manual" under one fixed import run, never sent as facts) and the overrides
are put on top of what the rules decided.
"""

import sqlite3
import uuid
from typing import Any

from fin.logic import (
    MANUAL_SOURCE,
    ConfigError,
    State,
    Taxonomy,
    in_order,
    order_between,
    parse_manual,
    resolve,
)
from fin.storage.categorize_apply import LEGACY_SOURCE
from fin.storage.settings_store import ORDER, VALUE, Editor, encode

MANUAL_RUN = (MANUAL_SOURCE, MANUAL_SOURCE, "1970-01-01T00:00:00+00:00")
OVERRIDE_RULE = "manual"
LISTS = {"rule": "rules", "goal": "goals"}  # entity -> document, for save/delete/move
RULE_FIELDS = {"match", "category", "source", "exact", "direction", "bucket", "amount", "estimate"}
GOAL_FIELDS = {"name", "amount", "minimum", "months_of_spend", "by"}
FIELDS = {"rule": RULE_FIELDS, "goal": GOAL_FIELDS}


class EditError(ValueError):
    """An edit request that cannot be applied as asked."""


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


def _order_after(items: dict[str, dict[str, Any]], after: str | None, moving: str) -> str:
    """An order key that places an item right after `after` (None: first)."""
    orders = {key: str(f.get(ORDER, "")) for key, f in items.items() if key != moving}
    sequence = in_order(orders)
    if after is not None and after not in orders:
        raise EditError("no such item to place it after")
    index = 0 if after is None else sequence.index(after) + 1
    low = orders[sequence[index - 1]] if index > 0 else None
    high = orders[sequence[index]] if index < len(sequence) else None
    if low is not None and high is not None and not low < high:
        high = None  # equal keys (made on two devices at once): go after both
    return order_between(low or None, high or None)


def _ensure_document(editor: Editor, current: State, document: str) -> None:
    if document not in current.get("document", {}):
        editor.set("document", document, "present", True)


def _shekels(agorot: int) -> int | float:
    whole, rest = divmod(agorot, 100)
    return whole if rest == 0 else agorot / 100


def plan_edit(
    editor: Editor, current: State, request: dict[str, Any], taxonomy: Taxonomy
) -> dict[str, Any]:
    """Turn one request into changes on `editor` (not saved). Returns what the app shows next."""
    kind = request.get("kind")
    if kind == "budget_ceiling":
        bucket, amount = request.get("bucket"), request.get("amount_agorot")
        if not isinstance(bucket, str) or not bucket:
            raise EditError("a bucket is needed")
        if "budget" not in current.get("document", {}):
            raise EditError("no budget is saved yet")
        ceilings = current.get("budget_ceiling", {})
        if amount is None:
            if bucket in ceilings:
                editor.delete("budget_ceiling", bucket)
            return {"bucket": bucket}
        if isinstance(amount, bool) or not isinstance(amount, int) or amount < 0:
            raise EditError("the ceiling is a whole number of agorot, zero or more")
        editor.set("budget_ceiling", bucket, VALUE, encode(_shekels(amount)))
        if bucket not in ceilings:
            last = in_order({k: str(f.get(ORDER, "")) for k, f in ceilings.items()})
            after = last[-1] if last else None
            editor.set("budget_ceiling", bucket, ORDER, _order_after(ceilings, after, bucket))
        return {"bucket": bucket}
    if kind in ("rule_save", "goal_save"):
        entity = kind.removesuffix("_save")
        items = current.get(entity, {})
        item_id = request.get("id") or _new_id()
        fields = request.get("fields")
        if not isinstance(fields, dict) or not fields:
            raise EditError("the fields to save are needed")
        unknown = set(fields) - FIELDS[entity]
        if unknown:
            raise EditError(f"unknown fields: {', '.join(sorted(unknown))}")
        _ensure_document(editor, current, LISTS[entity])
        old = items.get(item_id, {})
        for name, value in fields.items():
            if value is not None and old.get(name) != encode(value):
                editor.set(entity, item_id, name, encode(value))
        for name in FIELDS[entity] & set(old) - {k for k, v in fields.items() if v is not None}:
            if old.get(name) is not None:
                editor.set(entity, item_id, name, None)
        if item_id not in items:
            last = in_order({k: str(f.get(ORDER, "")) for k, f in items.items()})
            editor.set(
                entity, item_id, ORDER, _order_after(items, last[-1] if last else None, item_id)
            )
        return {"id": item_id}
    if kind in ("rule_delete", "goal_delete", "manual_delete"):
        entity = {"rule_delete": "rule", "goal_delete": "goal", "manual_delete": "manual_tx"}[kind]
        item_id = request.get("id")
        if item_id not in current.get(entity, {}):
            raise EditError("no such item")
        editor.delete(entity, item_id)
        return {"id": item_id}
    if kind in ("rule_move", "goal_move"):
        entity = kind.removesuffix("_move")
        items = current.get(entity, {})
        item_id = request.get("id")
        if item_id not in items:
            raise EditError("no such item")
        editor.set(entity, item_id, ORDER, _order_after(items, request.get("after"), item_id))
        return {"id": item_id}
    if kind == "category":
        tx_hash, category = request.get("tx_hash"), request.get("category")
        if not isinstance(tx_hash, str) or not tx_hash:
            raise EditError("a transaction is needed")
        if category is None:
            if tx_hash in current.get("category_override", {}):
                editor.delete("category_override", tx_hash)
            return {"tx_hash": tx_hash}
        if category not in taxonomy.categories:
            raise EditError(f"unknown category {category!r}")
        editor.set("category_override", tx_hash, "category", category)
        return {"tx_hash": tx_hash}
    if kind == "manual_save":
        item_id = request.get("id") or _new_id()
        wanted = {k: request.get(k) for k in ("date", "amount_agorot", "description", "category")}
        try:
            parse_manual(item_id, wanted, taxonomy)
        except ConfigError as exc:
            raise EditError(str(exc)) from exc
        old = current.get("manual_tx", {}).get(item_id, {})
        for name, value in wanted.items():
            if old.get(name) != value and (value is not None or name in old):
                editor.set("manual_tx", item_id, name, value)
        return {"id": item_id}
    raise EditError("unknown kind of edit")


def _manual_run_id(conn: sqlite3.Connection) -> int:
    found = conn.execute(
        "SELECT id FROM import_runs WHERE source = ? AND file_sha256 = ? AND started_at = ?",
        MANUAL_RUN,
    ).fetchone()
    if found:
        return found[0]
    cursor = conn.execute(
        "INSERT INTO import_runs (source, file_sha256, started_at, rows_seen, rows_inserted,"
        " rows_duplicate, rows_quarantined) VALUES (?, ?, ?, 0, 0, 0, 0)",
        MANUAL_RUN,
    )
    return int(cursor.lastrowid or 0)


def write_manual(conn: sqlite3.Connection, current: State, taxonomy: Taxonomy) -> int:
    """Make the ledger's manual rows match the change log. Returns how many there are."""
    wanted = {}
    for item_id, fields in current.get("manual_tx", {}).items():
        try:
            tx = parse_manual(item_id, fields, taxonomy)
        except ConfigError:
            continue  # a change from a newer app version; it waits for an update
        wanted[tx.tx_hash] = tx
    stored = {
        row[0]
        for row in conn.execute(
            "SELECT tx_hash FROM transactions WHERE source = ?", (MANUAL_SOURCE,)
        )
    }
    if not wanted and not stored:
        return 0  # nothing by hand: the ledger stays exactly as imported
    with conn:
        run_id = _manual_run_id(conn)
        for gone in stored - wanted.keys():
            conn.execute("DELETE FROM transactions WHERE tx_hash = ?", (gone,))
        for tx_hash, tx in wanted.items():
            values = (
                tx.tx_date,
                tx.budget_month,
                tx.description,
                tx.amount_agorot,
                tx.amount_agorot,
            )
            if tx_hash in stored:
                conn.execute(
                    "UPDATE transactions SET tx_date = ?, budget_month = ?, description = ?,"
                    " total_amount_agorot = ?, my_share_agorot = ? WHERE tx_hash = ?",
                    (*values, tx_hash),
                )
            else:
                conn.execute(
                    "INSERT INTO transactions (tx_hash, source, source_ref, tx_date, budget_month,"
                    " description, total_amount_agorot, my_share_agorot, import_run_id)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (tx_hash, MANUAL_SOURCE, tx.id, *values, run_id),
                )
    return len(wanted)


def apply_overrides(conn: sqlite3.Connection, current: State, taxonomy: Taxonomy) -> int:
    """Put the categories set by hand on top of the rules. Returns how many rows changed."""
    chosen = {
        tx_hash: fields.get("category")
        for tx_hash, fields in current.get("category_override", {}).items()
    }
    for item_id, fields in current.get("manual_tx", {}).items():
        if fields.get("category"):
            chosen.setdefault(f"{MANUAL_SOURCE}:{item_id}", fields["category"])
    updates = []
    for tx_hash, category in chosen.items():
        if category in taxonomy.categories:
            result = resolve(taxonomy, category, OVERRIDE_RULE)
            updates.append((result.category, result.bucket, result.kind, OVERRIDE_RULE, tx_hash))
    with conn:
        cursor = conn.executemany(
            "UPDATE transactions SET category = ?, bucket = ?, flow_kind = ?, category_rule = ?"
            " WHERE tx_hash = ? AND source != ?",
            [(*update, LEGACY_SOURCE) for update in updates],
        )
    return cursor.rowcount if updates else 0
