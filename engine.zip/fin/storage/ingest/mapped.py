"""The adapter for a source the user mapped by hand (fin.logic.source_map).

It recognizes a file by its header row (and sheet name, for a workbook), reads
the rows with the mapping, and refuses the whole file when any row cannot be
read. Such a file has no control total of its own; the result says so.

A bank becomes bank rows (with the running balance when mapped). A card
becomes card rows: the billing date when the file has one, else the
transaction date, which is also the month the row counts in (spec v0.35).
"""

from pathlib import Path

from fin.logic import BANK, MappedRows, SourceMap, map_rows
from fin.storage.ingest.adapter import ControlTotalError
from fin.storage.ingest.records import (
    BankParseResult,
    BankTransaction,
    CardParseResult,
    CardTransaction,
)
from fin.storage.ingest.table import Table, read_tables


class MappedAdapter:
    def __init__(self, mapping: SourceMap) -> None:
        self.mapping = mapping
        self.source = mapping.source

    def _table(self, path: Path) -> Table | None:
        for table in read_tables(path):
            if self.mapping.sheet is not None and table.sheet != self.mapping.sheet:
                continue
            if table.headers() == self.mapping.headers:
                return table
        return None

    def detect(self, path: Path) -> bool:
        return self._table(path) is not None

    def read(self, path: Path) -> MappedRows:
        table = self._table(path)
        if table is None:
            raise ControlTotalError("the file no longer matches this source's columns")
        headers = table.headers() or ()
        return map_rows(self.mapping, headers, table.body())

    def parse(self, path: Path) -> BankParseResult | CardParseResult:
        mapped = self.read(path)
        if mapped.problems:
            raise ControlTotalError(f"{len(mapped.problems)} row(s) could not be read")
        refs = [f"row{n}" for n in range(1, len(mapped.rows) + 1)]
        if self.mapping.kind == BANK:
            return BankParseResult(
                self.source,
                [
                    BankTransaction(ref, r.tx_date, r.description, r.amount_agorot,
                                    r.balance_agorot)
                    for ref, r in zip(refs, mapped.rows, strict=True)
                ],
            )  # fmt: skip
        return CardParseResult(
            self.source,
            [
                CardTransaction(
                    source_ref=ref, tx_date=r.tx_date, billing_date=r.billing_date or r.tx_date,
                    description=r.description, card_last4=None, tx_type=None,
                    charge_agorot=-r.amount_agorot, original_amount_agorot=None,
                    original_currency=None, installment=None, source_category=None, notes=None,
                )
                for ref, r in zip(refs, mapped.rows, strict=True)
            ],
        )  # fmt: skip

    def validate(self, parsed: BankParseResult | CardParseResult) -> None:
        """Nothing more to check: every row was read, and such a file declares no total."""
