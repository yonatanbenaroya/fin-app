"""Small helpers for reading spreadsheet cells."""

import warnings
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook

from fin.logic import to_agorot

HEADER_SCAN_ROWS = 10
_EXCEL_SUFFIXES = {".xlsx", ".xlsm"}


class RowError(ValueError):
    """A row-level problem; the message is the quarantine reason."""


def open_workbook(path: Path) -> Workbook:
    """Load a workbook with cached formula values, silencing style warnings."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return load_workbook(path, data_only=True)


def read_header_rows(path: Path) -> list[list[tuple[Any, ...]]] | None:
    """Return the top rows of every sheet, or None when the file is not a readable workbook."""
    if path.suffix.lower() not in _EXCEL_SUFFIXES:
        return None
    try:
        workbook = open_workbook(path)
    except Exception:  # noqa: BLE001 - any unreadable file is simply "not a workbook"
        return None
    return [
        list(sheet.iter_rows(max_row=HEADER_SCAN_ROWS, values_only=True))
        for sheet in workbook.worksheets
    ]


def clean(value: Any) -> str | None:
    """Collapse whitespace (including line breaks); None for empty cells."""
    if value is None:
        return None
    text = " ".join(str(value).split())
    return text or None


def required_text(value: Any, name: str) -> str:
    text = clean(value)
    if text is None:
        raise RowError(f"{name}_missing")
    return text


def amount(value: Any, name: str) -> int:
    """Convert a numeric cell to agorot, keeping its sign."""
    if value is None:
        raise RowError(f"{name}_missing")
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise RowError(f"{name}_not_number")
    try:
        return to_agorot(value)
    except ValueError as exc:
        raise RowError(f"{name}_not_number") from exc


def find_header_row(rows: Sequence[Sequence[Any]], headers: Sequence[str]) -> int | None:
    """Return the 0-based index of the row whose first cells equal the headers."""
    width = len(headers)
    for index, row in enumerate(rows[:HEADER_SCAN_ROWS]):
        if [clean(cell) for cell in row[:width]] == list(headers):
            return index
    return None


def raw_row(headers: Sequence[str], values: Sequence[Any]) -> dict[str, str | None]:
    """Stringify a row for the quarantine table."""
    return {
        header: None if value is None else str(value)
        for header, value in zip(headers, values, strict=False)
    }
