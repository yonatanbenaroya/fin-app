"""Idempotent persistence of a parsed legacy workbook."""

import hashlib
import json
import sqlite3
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from fin.storage.ingest.legacy_excel import LegacyTransaction, ParseResult


@dataclass(frozen=True)
class ImportSummary:
    rows_seen: int
    rows_inserted: int
    rows_duplicate: int
    rows_quarantined: int
    rows_stale: int
    incomes: int
    budgets: int
    skipped_sheets: int
    share_exceeds_total: int


def file_sha256(path: Path) -> str:
    """Return the SHA-256 hex digest of a file."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def transaction_hashes(transactions: Sequence[LegacyTransaction], source: str) -> list[str]:
    """Return a stable identity hash per transaction.

    Identical rows inside one budget month are numbered, so two genuinely
    identical purchases both survive while a re-import adds nothing, even if
    rows were reordered or new rows were inserted between them.
    """
    occurrences: Counter[tuple[object, ...]] = Counter()
    hashes = []
    for tx in transactions:
        key = (
            source,
            tx.budget_month,
            tx.tx_date.isoformat(),
            tx.description,
            tx.total_amount_agorot,
            tx.my_share_agorot,
            tx.paid_by,
        )
        payload = json.dumps([*key, occurrences[key]], ensure_ascii=False)
        occurrences[key] += 1
        hashes.append(hashlib.sha256(payload.encode("utf-8")).hexdigest())
    return hashes


def store_legacy_import(
    conn: sqlite3.Connection, result: ParseResult, source: str, file_hash: str
) -> ImportSummary:
    """Write a parse result in one transaction and return what happened.

    Transactions are insert-or-ignore on their hash. Income and budget rows are
    upserted. The quarantine for this source is rebuilt, so it always mirrors
    the latest state of the file.
    """
    hashes = transaction_hashes(result.transactions, source)
    with conn:
        run_id = conn.execute(
            "INSERT INTO import_runs (source, file_sha256, started_at, rows_seen,"
            " rows_inserted, rows_duplicate, rows_quarantined) VALUES (?, ?, ?, 0, 0, 0, 0)",
            (source, file_hash, datetime.now(UTC).isoformat(timespec="seconds")),
        ).lastrowid
        inserted = 0
        for tx, tx_hash in zip(result.transactions, hashes, strict=True):
            inserted += conn.execute(
                "INSERT OR IGNORE INTO transactions (tx_hash, source, source_ref, tx_date,"
                " budget_month, description, bucket_raw, category_raw, bucket, category,"
                " total_amount_agorot, my_share_agorot, paid_by, notes, import_run_id)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    tx_hash,
                    source,
                    tx.source_ref,
                    tx.tx_date.isoformat(),
                    tx.budget_month,
                    tx.description,
                    tx.bucket_raw,
                    tx.category_raw,
                    tx.bucket,
                    tx.category,
                    tx.total_amount_agorot,
                    tx.my_share_agorot,
                    tx.paid_by,
                    tx.notes,
                    run_id,
                ),
            ).rowcount
        conn.execute("DELETE FROM quarantine WHERE source = ?", (source,))
        conn.executemany(
            "INSERT INTO quarantine (source, source_ref, reason, raw_json, import_run_id,"
            " budget_month) VALUES (?, ?, ?, ?, ?, ?)",
            [
                (
                    source,
                    row.source_ref,
                    row.reason,
                    json.dumps(row.raw, ensure_ascii=False),
                    run_id,
                    row.budget_month,
                )
                for row in result.quarantined
            ],
        )
        conn.executemany(
            "INSERT INTO income (source, month, gross_agorot, net_agorot, notes)"
            " VALUES (?, ?, ?, ?, ?) ON CONFLICT (source, month) DO UPDATE SET"
            " gross_agorot = excluded.gross_agorot, net_agorot = excluded.net_agorot,"
            " notes = excluded.notes",
            [(source, i.month, i.gross_agorot, i.net_agorot, i.notes) for i in result.incomes],
        )
        conn.executemany(
            "INSERT INTO budgets (source, budget_month, bucket, budget_agorot)"
            " VALUES (?, ?, ?, ?) ON CONFLICT (source, budget_month, bucket) DO UPDATE SET"
            " budget_agorot = excluded.budget_agorot",
            [(source, b.budget_month, b.bucket, b.budget_agorot) for b in result.budgets],
        )
        in_db = conn.execute(
            "SELECT COUNT(*) FROM transactions WHERE source = ?", (source,)
        ).fetchone()[0]
        summary = ImportSummary(
            rows_seen=result.rows_seen,
            rows_inserted=inserted,
            rows_duplicate=len(result.transactions) - inserted,
            rows_quarantined=len(result.quarantined),
            rows_stale=in_db - len(set(hashes)),
            incomes=len(result.incomes),
            budgets=len(result.budgets),
            skipped_sheets=len(result.skipped_sheets),
            share_exceeds_total=result.share_exceeds_total,
        )
        conn.execute(
            "UPDATE import_runs SET rows_seen = ?, rows_inserted = ?, rows_duplicate = ?,"
            " rows_quarantined = ? WHERE id = ?",
            (
                summary.rows_seen,
                summary.rows_inserted,
                summary.rows_duplicate,
                summary.rows_quarantined,
                run_id,
            ),
        )
    return summary
