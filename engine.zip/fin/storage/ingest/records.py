"""Record types shared by the ingestion parsers."""

from dataclasses import dataclass, field
from datetime import date


@dataclass(frozen=True)
class QuarantinedRow:
    source_ref: str
    reason: str
    raw: dict[str, str | None]
    budget_month: str | None = None


@dataclass(frozen=True)
class CardTransaction:
    """One charged line of a credit card export.

    Amounts keep the sign of the export: a positive charge is money spent and
    a negative charge is a refund.
    """

    source_ref: str
    tx_date: date
    billing_date: date
    description: str
    card_last4: str | None
    tx_type: str | None
    charge_agorot: int
    original_amount_agorot: int | None
    original_currency: str | None
    installment: tuple[int, int] | None
    source_category: str | None
    notes: str | None

    @property
    def budget_month(self) -> str:
        """Month the charge counts toward.

        An installment counts in the month it is billed, so a purchase paid in
        twelve installments spreads over twelve months. Anything else counts in
        the month of the purchase.
        """
        day = self.billing_date if self.installment else self.tx_date
        return f"{day.year:04d}-{day.month:02d}"


@dataclass
class CardParseResult:
    source: str
    transactions: list[CardTransaction] = field(default_factory=list)
    quarantined: list[QuarantinedRow] = field(default_factory=list)
    skipped_no_charge: int = 0
    # Sheets whose charge column does not add up to the total the file declares.
    total_mismatches: list[str] = field(default_factory=list)

    @property
    def rows_seen(self) -> int:
        return len(self.transactions) + len(self.quarantined)


@dataclass(frozen=True)
class BankTransaction:
    """One line of a bank statement. Credits are positive, debits negative."""

    source_ref: str
    tx_date: date
    description: str
    amount_agorot: int
    # None for a mapped bank export without a balance column (never the opening balance).
    balance_after_agorot: int | None

    @property
    def budget_month(self) -> str:
        return f"{self.tx_date.year:04d}-{self.tx_date.month:02d}"


@dataclass
class BankParseResult:
    source: str
    transactions: list[BankTransaction] = field(default_factory=list)
    # Consecutive rows whose balances do not differ by exactly the signed amount.
    chain_breaks: int = 0
    # Lines that look like transactions but could not be decoded.
    unparsed_lines: int = 0

    @property
    def is_consistent(self) -> bool:
        """True when every line was decoded and the running balance checks out."""
        return self.chain_breaks == 0 and self.unparsed_lines == 0
