"""Parser for the legacy budget workbook. Pure: reads the file, touches no database.

Rows that cannot be decoded with confidence are quarantined, never dropped
and never guessed.
"""

from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.worksheet.worksheet import Worksheet

from fin.logic import to_agorot
from fin.storage.ingest.legacy_config import LegacyExcelConfig
from fin.storage.ingest.legacy_dates import LegacyDateError, parse_day_month, parse_sheet_period
from fin.storage.ingest.records import QuarantinedRow

_BUDGET_HEADER_SCAN_ROWS = 5


@dataclass(frozen=True)
class LegacyTransaction:
    source_ref: str
    tx_date: date
    budget_month: str
    description: str
    bucket_raw: str
    category_raw: str
    bucket: str
    category: str
    total_amount_agorot: int
    my_share_agorot: int
    paid_by: str
    notes: str | None


@dataclass(frozen=True)
class LegacyIncome:
    month: str
    gross_agorot: int
    net_agorot: int
    notes: str | None


@dataclass(frozen=True)
class LegacyBudget:
    budget_month: str
    bucket: str
    budget_agorot: int


@dataclass
class ParseResult:
    transactions: list[LegacyTransaction] = field(default_factory=list)
    incomes: list[LegacyIncome] = field(default_factory=list)
    budgets: list[LegacyBudget] = field(default_factory=list)
    quarantined: list[QuarantinedRow] = field(default_factory=list)
    skipped_sheets: list[str] = field(default_factory=list)
    share_exceeds_total: int = 0

    @property
    def rows_seen(self) -> int:
        """Transaction rows found in the workbook, parsed or quarantined."""
        tx_quarantined = sum(1 for row in self.quarantined if row.reason.startswith("tx:"))
        return len(self.transactions) + tx_quarantined


class _RowError(ValueError):
    """A row-level problem; the message is the quarantine reason."""


def parse_workbook(path: Path, cfg: LegacyExcelConfig) -> ParseResult:
    """Parse every sheet of the legacy workbook into typed records."""
    workbook = load_workbook(path, data_only=True)
    result = ParseResult()
    for sheet in workbook.worksheets:
        title = sheet.title.strip()
        if title == cfg.salary_sheet and _header(sheet, 1, 1, 4) == cfg.salary_headers:
            _parse_salaries(sheet, result)
        elif _header(sheet, 1, 1, len(cfg.transaction_headers)) == cfg.transaction_headers:
            period = parse_sheet_period(title, cfg.months)
            if period is None:
                result.skipped_sheets.append(f"{title}: unknown period")
                continue
            _parse_transactions(sheet, period, cfg, result)
            _parse_budget(sheet, period, cfg, result)
        else:
            result.skipped_sheets.append(f"{title}: unrecognized layout")
    return result


def _parse_transactions(
    sheet: Worksheet, period: tuple[int, int], cfg: LegacyExcelConfig, result: ParseResult
) -> None:
    year, month = period
    width = len(cfg.transaction_headers)
    rows = sheet.iter_rows(min_row=2, max_col=width, values_only=True)
    for row_number, row in enumerate(rows, start=2):
        if all(cell is None for cell in row):
            continue
        ref = f"{sheet.title.strip()}!{row_number}"
        try:
            date_cell, description, bucket, category, total, paid_by, share, notes = row
            try:
                tx_date = parse_day_month(date_cell, year, month)
            except LegacyDateError as exc:
                raise _RowError(str(exc)) from exc
            bucket_raw = _required_text(bucket, "bucket")
            category_raw = _required_text(category, "category")
            transaction = LegacyTransaction(
                source_ref=ref,
                tx_date=tx_date,
                budget_month=f"{year:04d}-{month:02d}",
                description=_required_text(description, "description"),
                bucket_raw=bucket_raw,
                category_raw=category_raw,
                bucket=cfg.bucket_aliases.get(bucket_raw, bucket_raw),
                category=cfg.category_aliases.get(category_raw, category_raw),
                total_amount_agorot=-_amount(total, "total"),
                my_share_agorot=-_amount(share, "my_share"),
                paid_by=_required_text(paid_by, "paid_by"),
                notes=_clean(notes),
            )
        except _RowError as exc:
            raw = dict(zip(cfg.transaction_headers, map(_raw, row), strict=True))
            budget_month = f"{year:04d}-{month:02d}"
            result.quarantined.append(QuarantinedRow(ref, f"tx:{exc}", raw, budget_month))
            continue
        if abs(transaction.my_share_agorot) > abs(transaction.total_amount_agorot):
            result.share_exceeds_total += 1
        result.transactions.append(transaction)


def _parse_budget(
    sheet: Worksheet, period: tuple[int, int], cfg: LegacyExcelConfig, result: ParseResult
) -> None:
    location = _find_budget_header(sheet, cfg)
    if location is None:
        return
    header_row, column = location
    budget_month = f"{period[0]:04d}-{period[1]:02d}"
    rows = sheet.iter_rows(
        min_row=header_row + 1, min_col=column, max_col=column + 1, values_only=True
    )
    for row_number, (bucket, budget) in enumerate(rows, start=header_row + 1):
        label = _clean(bucket)
        if label is None:
            break
        if label == cfg.budget_total_label:
            continue
        try:
            amount = _amount(budget, "budget")
        except _RowError as exc:
            ref = f"{sheet.title.strip()}!budget:{row_number}"
            raw = {"bucket": label, "budget": _raw(budget)}
            result.quarantined.append(QuarantinedRow(ref, f"budget:{exc}", raw, budget_month))
            continue
        result.budgets.append(
            LegacyBudget(budget_month, cfg.bucket_aliases.get(label, label), amount)
        )


def _find_budget_header(sheet: Worksheet, cfg: LegacyExcelConfig) -> tuple[int, int] | None:
    width = len(cfg.budget_headers)
    first_column = len(cfg.transaction_headers) + 1
    for row in range(1, _BUDGET_HEADER_SCAN_ROWS + 1):
        for column in range(first_column, sheet.max_column - width + 2):
            if _header(sheet, row, column, width) == cfg.budget_headers:
                return row, column
    return None


def _parse_salaries(sheet: Worksheet, result: ParseResult) -> None:
    for row_number, row in enumerate(sheet.iter_rows(min_row=2, max_col=4, values_only=True), 2):
        month_cell, gross, net, notes = row
        if month_cell is None:  # free-text remark rows carry no month
            continue
        ref = f"{sheet.title.strip()}!{row_number}"
        try:
            if not isinstance(month_cell, date | datetime):
                raise _RowError("month_not_date")
            income = LegacyIncome(
                month=f"{month_cell.year:04d}-{month_cell.month:02d}",
                gross_agorot=_amount(gross, "gross"),
                net_agorot=_amount(net, "net"),
                notes=_clean(notes),
            )
        except _RowError as exc:
            raw = {"month": _raw(month_cell), "gross": _raw(gross), "net": _raw(net)}
            result.quarantined.append(QuarantinedRow(ref, f"income:{exc}", raw))
            continue
        result.incomes.append(income)


def _header(sheet: Worksheet, row: int, column: int, width: int) -> tuple[str | None, ...]:
    cells = next(
        sheet.iter_rows(
            min_row=row, max_row=row, min_col=column, max_col=column + width - 1, values_only=True
        )
    )
    return tuple(_clean(cell) for cell in cells)


def _clean(value: Any) -> str | None:
    """Collapse whitespace; return None for empty or non-text-like cells."""
    if value is None:
        return None
    text = " ".join(str(value).split())
    return text or None


def _required_text(value: Any, name: str) -> str:
    text = _clean(value)
    if text is None:
        raise _RowError(f"{name}_missing")
    return text


def _amount(value: Any, name: str) -> int:
    """Convert a numeric cell to agorot. Empty also covers formulas with no cached value."""
    if value is None:
        raise _RowError(f"{name}_missing")
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise _RowError(f"{name}_not_number")
    try:
        return to_agorot(value)
    except ValueError as exc:
        raise _RowError(f"{name}_not_number") from exc


def _raw(value: Any) -> str | None:
    return None if value is None else str(value)
