"""Reading any CSV or Excel export as plain tables, for sources the user mapped by hand.

A table is a sheet's rows as cell values (a CSV file is one table). The header row is
the first of the top rows with at least two named cells and nothing that looks like a
number or a date: the row the user maps.
"""

import csv
import io
from dataclasses import dataclass
from itertools import islice
from pathlib import Path
from typing import Any

from fin.logic import header_cells
from fin.storage.ingest.cells import open_workbook

TABLE_SUFFIXES = frozenset({".csv", ".xlsx", ".xlsm"})
MAX_ROWS = 20_000
HEADER_SCAN = 15
_ENCODINGS = ("utf-8-sig", "cp1255")  # Israeli banks still export Windows-1255


@dataclass(frozen=True)
class Table:
    sheet: str | None  # None for a CSV file
    rows: tuple[tuple[Any, ...], ...]

    def header_index(self) -> int | None:
        for index, row in enumerate(self.rows[:HEADER_SCAN]):
            cells = header_cells(row)
            named = [c for c in cells if c]
            if len(named) >= 2 and not any(_looks_like_data(c) for c in named):
                return index
        return None

    def headers(self) -> tuple[str, ...] | None:
        index = self.header_index()
        return None if index is None else header_cells(self.rows[index])

    def body(self) -> tuple[tuple[Any, ...], ...]:
        index = self.header_index()
        return () if index is None else self.rows[index + 1 :]


def _looks_like_data(text: str) -> bool:
    digits = sum(ch.isdigit() for ch in text)
    return digits >= max(3, len(text) // 2)


def _read_csv(data: bytes) -> list[list[str]]:
    for encoding in _ENCODINGS:
        try:
            text = data.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        return []
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    return list(islice(csv.reader(io.StringIO(text), dialect), MAX_ROWS))


def read_tables(path: Path) -> list[Table]:
    """Every table in the file; an empty list when it is not a readable CSV or workbook."""
    suffix = path.suffix.lower()
    if suffix not in TABLE_SUFFIXES:
        return []
    try:
        if suffix == ".csv":
            return [Table(None, tuple(tuple(row) for row in _read_csv(path.read_bytes())))]
        workbook = open_workbook(path)
    except Exception:  # noqa: BLE001 - an unreadable file is simply not a table
        return []
    return [
        Table(sheet.title, tuple(sheet.iter_rows(max_row=MAX_ROWS, values_only=True)))
        for sheet in workbook.worksheets
    ]


def preview(path: Path, rows: int = 8) -> dict[str, Any] | None:
    """What the mapping step shows: per table with a header row, the headers and the first
    rows as text. None when the file has no table to map."""
    found = []
    for table in read_tables(path):
        headers = table.headers()
        if headers is None:
            continue
        sample = [
            [_shown(row[i]) if i < len(row) else "" for i in range(len(headers))]
            for row in table.body()
            if any(_shown(v) for v in row)
        ][:rows]
        found.append({"sheet": table.sheet, "headers": list(headers), "rows": sample})
    return {"tables": found} if found else None


def _shown(value: Any) -> str:
    if value is None:
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%d/%m/%Y")
    return " ".join(str(value).split())
