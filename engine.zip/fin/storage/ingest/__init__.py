"""File ingestion into SQLite (bank, card and legacy Excel imports)."""
