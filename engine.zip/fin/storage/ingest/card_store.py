"""Idempotent persistence of parsed credit card exports."""

import hashlib
import json
import sqlite3
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime

from fin.storage.ingest.adapter import ControlTotalError
from fin.storage.ingest.checks import check_card_totals
from fin.storage.ingest.records import CardParseResult, CardTransaction

__all__ = ["CardImportSummary", "ControlTotalError", "card_hashes", "store_card_import"]


@dataclass(frozen=True)
class CardImportSummary:
    rows_seen: int
    rows_inserted: int
    rows_duplicate: int
    rows_quarantined: int
    skipped_no_charge: int


def card_hashes(transactions: Sequence[CardTransaction], source: str) -> list[str]:
    """Return a stable identity hash per card transaction.

    Rows that are identical in every identifying field are numbered, so two
    real identical purchases both survive while overlapping or repeated
    exports add nothing.
    """
    occurrences: Counter[tuple[object, ...]] = Counter()
    hashes = []
    for tx in transactions:
        key = (
            source,
            tx.card_last4,
            tx.tx_date.isoformat(),
            tx.description,
            tx.original_amount_agorot,
            tx.charge_agorot,
            tx.billing_date.isoformat(),
        )
        payload = json.dumps([*key, occurrences[key]], ensure_ascii=False)
        occurrences[key] += 1
        hashes.append(hashlib.sha256(payload.encode("utf-8")).hexdigest())
    return hashes


def store_card_import(
    conn: sqlite3.Connection, result: CardParseResult, file_name: str, file_hash: str
) -> CardImportSummary:
    """Write one parsed card file in a single transaction.

    Refuses the whole file when its control total does not match. Spending is
    stored negative and refunds positive; the user's share equals the charge.
    The quarantine is rebuilt per file, leaving other files of the source alone.
    """
    check_card_totals(result)
    source = result.source
    hashes = card_hashes(result.transactions, source)
    with conn:
        run_id = conn.execute(
            "INSERT INTO import_runs (source, file_sha256, started_at, rows_seen,"
            " rows_inserted, rows_duplicate, rows_quarantined) VALUES (?, ?, ?, 0, 0, 0, 0)",
            (source, file_hash, datetime.now(UTC).isoformat(timespec="seconds")),
        ).lastrowid
        inserted = 0
        for tx, tx_hash in zip(result.transactions, hashes, strict=True):
            number, total = tx.installment or (None, None)
            original = tx.original_amount_agorot
            inserted += conn.execute(
                "INSERT OR IGNORE INTO transactions (tx_hash, source, source_ref, tx_date,"
                " budget_month, description, total_amount_agorot, my_share_agorot, notes,"
                " import_run_id, billing_date, original_amount_agorot, original_currency,"
                " card_last4, tx_type, installment_number, installment_total, source_category)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    tx_hash,
                    source,
                    tx.source_ref,
                    tx.tx_date.isoformat(),
                    tx.budget_month,
                    tx.description,
                    -tx.charge_agorot,
                    -tx.charge_agorot,
                    tx.notes,
                    run_id,
                    tx.billing_date.isoformat(),
                    None if original is None else -original,
                    tx.original_currency,
                    tx.card_last4,
                    tx.tx_type,
                    number,
                    total,
                    tx.source_category,
                ),
            ).rowcount
        conn.execute(
            "DELETE FROM quarantine WHERE source = ? AND source_file = ?", (source, file_name)
        )
        conn.executemany(
            "INSERT INTO quarantine (source, source_ref, reason, raw_json, import_run_id,"
            " source_file) VALUES (?, ?, ?, ?, ?, ?)",
            [
                (
                    source,
                    row.source_ref,
                    row.reason,
                    json.dumps(row.raw, ensure_ascii=False),
                    run_id,
                    file_name,
                )
                for row in result.quarantined
            ],
        )
        summary = CardImportSummary(
            rows_seen=result.rows_seen,
            rows_inserted=inserted,
            rows_duplicate=len(result.transactions) - inserted,
            rows_quarantined=len(result.quarantined),
            skipped_no_charge=result.skipped_no_charge,
        )
        conn.execute(
            "UPDATE import_runs SET rows_seen = ?, rows_inserted = ?, rows_duplicate = ?,"
            " rows_quarantined = ? WHERE id = ?",
            (
                summary.rows_seen,
                summary.rows_inserted,
                summary.rows_duplicate,
                summary.rows_quarantined,
                run_id,
            ),
        )
    return summary
