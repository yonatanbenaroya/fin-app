"""The one interface every bank or card source implements.

An adapter knows a single export format and does three things: recognize the
file, parse it, and run the source's own control check. It never touches the
database; storing the parsed records is the pipeline's job.

To add a source: write one adapter and add its factory to
``fin.storage.ingest.registry.ADAPTER_FACTORIES``. Nothing else changes.
"""

from pathlib import Path
from typing import Protocol, TypeVar

ParsedT = TypeVar("ParsedT")


class ControlTotalError(Exception):
    """The file fails its own control check; nothing from it may be imported."""


class SourceAdapter(Protocol[ParsedT]):
    """One ingestion source: detect the file, parse it, validate the result."""

    source: str

    def detect(self, path: Path) -> bool:
        """True when the file is this source's export.

        Decided by content, never by the file name. An unreadable or foreign
        file is simply not recognized: return False, do not raise.
        """
        ...

    def parse(self, path: Path) -> ParsedT:
        """Read the file into records. Pure: no database, no side effects."""
        ...

    def validate(self, parsed: ParsedT) -> None:
        """Run the source's control check; raise ControlTotalError on a mismatch."""
        ...
