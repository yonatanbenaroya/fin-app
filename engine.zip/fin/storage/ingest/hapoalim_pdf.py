"""Parser for Bank Hapoalim current-account statements exported as PDF.

The extracted text has one line per transaction: date, description, amount,
currency symbol, running balance, then a marker prefix and a one-digit
direction marker (credit or debit). The amount itself is always positive and
always has two decimals.

Two independent signals are cross-checked: the marker gives the direction,
and the running balance must change by exactly the signed amount between
consecutive rows. A file that fails the check is not imported at all.
"""

import re
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from pypdf import PdfReader

from fin.logic import to_agorot
from fin.storage.ingest.bank_config import HapoalimConfig, load_bank_config
from fin.storage.ingest.checks import check_bank_chain
from fin.storage.ingest.records import BankParseResult, BankTransaction

_NUMBER = r"[\d,]+\.\d{2}"
# Amounts below one shekel are printed without the leading zero and come out of
# the text layer as ". 23" (a dot, a space, two digits).
_SUB_SHEKEL = r"\.\s*\d{2}"
_DATE_AT_START = re.compile(r"^\s*\d{2}/\d{2}/\d{4}")


def extract_pdf_lines(path: Path) -> list[list[str]]:
    """Return the text lines of each page of a PDF."""
    reader = PdfReader(path)
    return [(page.extract_text() or "").splitlines() for page in reader.pages]


def is_hapoalim_statement(pages: list[list[str]], cfg: HapoalimConfig) -> bool:
    """True when any line is the statement's table header (spaces ignored)."""
    wanted = "".join(cfg.table_header.split())
    return any(wanted in "".join(line.split()) for page in pages for line in page)


def parse_statement(pages: list[list[str]], cfg: HapoalimConfig, file_name: str) -> BankParseResult:
    """Decode all transaction lines and verify the running balance."""
    row = re.compile(
        rf"^\s*(\d{{2}})/(\d{{2}})/(\d{{4}})\s*(.*?)\s*({_NUMBER}|{_SUB_SHEKEL})\s*"
        rf"{re.escape(cfg.currency_symbol)}\s*(-?{_NUMBER})\s*"
        rf"{re.escape(cfg.marker_prefix)}\s*(\d?)\s*$"
    )
    signs = {cfg.credit_marker: 1, cfg.debit_marker: -1}
    result = BankParseResult(source=cfg.source)
    for page_number, lines in enumerate(pages, start=1):
        for line_number, line in enumerate(lines, start=1):
            if not _DATE_AT_START.match(line) or cfg.currency_symbol not in line:
                continue  # page headers, the statement period, labels
            match = row.match(line)
            marker = match.group(7) if match else ""
            if match and not marker and line_number < len(lines):
                marker = lines[line_number].strip()  # marker wrapped to the next line
            description = match.group(4).strip() if match else ""
            if match is None or marker not in signs or not description:
                result.unparsed_lines += 1
                continue
            day, month, year = (int(match.group(i)) for i in (1, 2, 3))
            try:
                tx_date = date(year, month, day)
            except ValueError:
                result.unparsed_lines += 1
                continue
            result.transactions.append(
                BankTransaction(
                    source_ref=f"{file_name}:{page_number}!{line_number}",
                    tx_date=tx_date,
                    description=" ".join(description.split()),
                    amount_agorot=signs[marker] * _amount(match.group(5)),
                    balance_after_agorot=to_agorot(match.group(6)),
                )
            )
    result.chain_breaks = _chain_breaks(result.transactions)
    return result


def _amount(text: str) -> int:
    """Convert an amount token to agorot, including the sub-shekel ". 23" form."""
    compact = "".join(text.split())
    return to_agorot("0" + compact if compact.startswith(".") else compact)


def _chain_breaks(transactions: list[BankTransaction]) -> int:
    """Count consecutive pairs whose balances disagree with the signed amount.

    Statements list the newest transaction first; an oldest-first statement is
    handled by walking it in reverse.
    """
    rows = transactions
    if rows and rows[0].tx_date < rows[-1].tx_date:
        rows = rows[::-1]
    return sum(
        newer.balance_after_agorot - older.balance_after_agorot != newer.amount_agorot
        for newer, older in zip(rows, rows[1:], strict=False)
    )


@dataclass(frozen=True)
class HapoalimAdapter:
    """The Hapoalim PDF statement as an ingestion source (see fin.storage.ingest.adapter)."""

    cfg: HapoalimConfig

    @property
    def source(self) -> str:
        return self.cfg.source

    def detect(self, path: Path) -> bool:
        if path.suffix.lower() != ".pdf":
            return False
        try:
            pages = extract_pdf_lines(path)
        except Exception:  # noqa: BLE001 - any unreadable file is simply "not recognized"
            return False
        return is_hapoalim_statement(pages, self.cfg)

    def parse(self, path: Path) -> BankParseResult:
        return parse_statement(extract_pdf_lines(path), self.cfg, path.name)

    def validate(self, parsed: BankParseResult) -> None:
        check_bank_chain(parsed)


def build_adapter() -> HapoalimAdapter:
    """Build the adapter from the bank layouts in config."""
    return HapoalimAdapter(load_bank_config().hapoalim)
