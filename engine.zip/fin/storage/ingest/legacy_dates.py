"""Date decoding for the legacy workbook.

Sheets are named after a budget month ("<month name> <yy>", in any order, with
stray spaces). Transaction dates are stored as day.month numbers, so 1.1 and
1.10 are the same value; the sheet's month resolves the ambiguity.
"""

import re
from collections.abc import Mapping
from datetime import date

_TWO_DIGIT_YEAR = re.compile(r"(?<!\d)(\d{2})(?!\d)")
# Offsets from the sheet month that a transaction date may have, in priority order.
_ALLOWED_MONTH_OFFSETS = (0, -1, 1)


class LegacyDateError(ValueError):
    """Raised when a date cell cannot be decoded with confidence."""


def parse_sheet_period(title: str, months: Mapping[str, int]) -> tuple[int, int] | None:
    """Return (year, month) for a sheet title, or None when it has no period."""
    cleaned = title.strip()
    year_match = _TWO_DIGIT_YEAR.search(cleaned)
    if year_match is None:
        return None
    for name in sorted(months, key=len, reverse=True):
        if name in cleaned:
            return 2000 + int(year_match.group(1)), months[name]
    return None


def parse_day_month(value: object, sheet_year: int, sheet_month: int) -> date:
    """Decode a day.month number using the sheet's budget month as context.

    The month must be the sheet's month or an adjacent one; anything further
    away raises LegacyDateError so the row can be quarantined.
    """
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise LegacyDateError("date_not_number")
    text = repr(float(value))
    if "e" in text or "n" in text:  # exponent notation, nan or inf
        raise LegacyDateError("date_not_day_month")
    whole, fraction = text.split(".")
    if fraction == "0" or len(fraction) > 2:
        raise LegacyDateError("date_not_day_month")
    candidates = {int(fraction)}
    if len(fraction) == 1:
        candidates.add(int(fraction) * 10)  # ".1" is January or October
    for offset in _ALLOWED_MONTH_OFFSETS:
        index = (sheet_year * 12 + sheet_month - 1) + offset
        year, month = index // 12, index % 12 + 1
        if month in candidates:
            try:
                return date(year, month, int(whole))
            except ValueError as exc:
                raise LegacyDateError("date_invalid_day") from exc
    raise LegacyDateError("date_far_from_sheet_month")
