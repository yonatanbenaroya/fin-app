"""Layout description of the bank statement exports, loaded from YAML."""

from dataclasses import dataclass
from pathlib import Path

import yaml

from fin.storage.config_files import CONFIG_DIR
from fin.storage.settings import ConfigError

DEFAULT_BANK_CONFIG_PATH = CONFIG_DIR / "bank_exports.yaml"


@dataclass(frozen=True)
class HapoalimConfig:
    source: str
    table_header: str
    currency_symbol: str
    marker_prefix: str
    credit_marker: str
    debit_marker: str


@dataclass(frozen=True)
class BankExportsConfig:
    hapoalim: HapoalimConfig


def load_bank_config(path: Path | None = None) -> BankExportsConfig:
    """Load the bank statement layouts from YAML."""
    config_path = path or DEFAULT_BANK_CONFIG_PATH
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))["hapoalim"]
        return BankExportsConfig(
            hapoalim=HapoalimConfig(
                source=str(raw["source"]),
                table_header=str(raw["table_header"]),
                currency_symbol=str(raw["currency_symbol"]),
                marker_prefix=str(raw["marker_prefix"]),
                credit_marker=str(raw["credit_marker"]),
                debit_marker=str(raw["debit_marker"]),
            )
        )
    except FileNotFoundError as exc:
        raise ConfigError(f"bank config not found: {config_path}") from exc
    except (yaml.YAMLError, KeyError, TypeError) as exc:
        raise ConfigError(f"invalid bank config: {config_path}") from exc
