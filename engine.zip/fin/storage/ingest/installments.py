"""Decoding of installment markers such as "payment 3 of 12" in card notes."""

import re


def parse_installment(notes: str | None, pattern: re.Pattern[str]) -> tuple[int, int] | None:
    """Return (number, total) when the notes mark an installment, else None.

    The pattern must capture the payment number and the payment count, in
    that order. Nonsensical markers (zero, or number above total) are ignored.
    """
    if not notes:
        return None
    match = pattern.search(notes)
    if match is None:
        return None
    number, total = int(match.group(1)), int(match.group(2))
    if number < 1 or total < 1 or number > total:
        return None
    return number, total
