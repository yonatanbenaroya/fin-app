"""Import one inbox file through its adapter: parse, validate, then store.

This is the only place that joins the pure adapters to the stores. The store
is chosen by the kind of records the adapter returned, never by source name.
"""

import sqlite3
from pathlib import Path
from typing import Any

from fin.storage.ingest.adapter import SourceAdapter
from fin.storage.ingest.bank_store import store_bank_import
from fin.storage.ingest.card_store import CardImportSummary, store_card_import
from fin.storage.ingest.records import BankParseResult, CardParseResult
from fin.storage.ingest.store import file_sha256


def import_file(
    conn: sqlite3.Connection, adapter: SourceAdapter[Any], path: Path
) -> CardImportSummary:
    """Parse, validate and store one recognized file.

    Raises ControlTotalError, before anything is written, when the file fails
    its control check.
    """
    parsed = adapter.parse(path)
    adapter.validate(parsed)
    file_hash = file_sha256(path)
    if isinstance(parsed, CardParseResult):
        return store_card_import(conn, parsed, path.name, file_hash)
    if isinstance(parsed, BankParseResult):
        return store_bank_import(conn, parsed, file_hash)
    raise TypeError(f"no store for records of type {type(parsed).__name__}")
