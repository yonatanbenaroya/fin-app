"""Layout description of the legacy budget workbook, loaded from YAML."""

from dataclasses import dataclass
from pathlib import Path

import yaml

from fin.storage.config_files import CONFIG_DIR
from fin.storage.settings import ConfigError

DEFAULT_LEGACY_CONFIG_PATH = CONFIG_DIR / "legacy_excel.yaml"


@dataclass(frozen=True)
class LegacyExcelConfig:
    source: str
    transaction_headers: tuple[str, ...]
    budget_headers: tuple[str, ...]
    budget_total_label: str
    salary_sheet: str
    salary_headers: tuple[str, ...]
    months: dict[str, int]
    bucket_aliases: dict[str, str]
    category_aliases: dict[str, str]


def load_legacy_config(path: Path | None = None) -> LegacyExcelConfig:
    """Load the legacy workbook layout from YAML."""
    config_path = path or DEFAULT_LEGACY_CONFIG_PATH
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        return LegacyExcelConfig(
            source=str(raw["source"]),
            transaction_headers=tuple(raw["transaction_headers"]),
            budget_headers=tuple(raw["budget_headers"]),
            budget_total_label=str(raw["budget_total_label"]),
            salary_sheet=str(raw["salary_sheet"]),
            salary_headers=tuple(raw["salary_headers"]),
            months={str(k): int(v) for k, v in raw["months"].items()},
            bucket_aliases=dict(raw.get("bucket_aliases") or {}),
            category_aliases=dict(raw.get("category_aliases") or {}),
        )
    except FileNotFoundError as exc:
        raise ConfigError(f"legacy config not found: {config_path}") from exc
    except (yaml.YAMLError, KeyError, TypeError, ValueError, AttributeError) as exc:
        raise ConfigError(f"invalid legacy config: {config_path}") from exc
