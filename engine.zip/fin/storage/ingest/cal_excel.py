"""Parser for Cal credit card exports. Pure: reads the file, touches no database.

One file covers one billing cycle of one card. The preamble carries the card
(last four digits, at the end of the title) and a line with the billing date
and the cycle total, which is used as a control total.
"""

import re
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any

from openpyxl.cell.cell import Cell

from fin.logic import to_agorot
from fin.storage.ingest.card_config import CardExportsConfig, load_card_config
from fin.storage.ingest.cells import (
    RowError,
    amount,
    clean,
    find_header_row,
    open_workbook,
    raw_row,
    read_header_rows,
    required_text,
)
from fin.storage.ingest.checks import check_card_totals
from fin.storage.ingest.installments import parse_installment
from fin.storage.ingest.records import CardParseResult, CardTransaction, QuarantinedRow

_CARD_AT_END = re.compile(r"(\d{4})\s*$")
_BILLING_LINE = r"(\d{2})/(\d{2})/(\d{4})\s*:\s*(-?[\d,]+(?:\.\d+)?)"
_CURRENCY_IN_FORMAT = re.compile(r"\[\$([^\]\-]+)")


def is_cal_workbook(sheets: list[list[tuple[Any, ...]]], cfg: CardExportsConfig) -> bool:
    """True when the first sheet carries the Cal header row."""
    return bool(sheets) and find_header_row(sheets[0], cfg.cal.headers) is not None


def parse_cal_workbook(path: Path, cfg: CardExportsConfig) -> CardParseResult:
    """Parse a Cal export (first sheet)."""
    result = CardParseResult(source=cfg.cal.source)
    sheet = open_workbook(path).worksheets[0]
    cell_rows = list(sheet.iter_rows())
    rows = [tuple(cell.value for cell in row) for row in cell_rows]
    sheet_ref = f"{path.name}:{sheet.title.strip()}"
    header_index = find_header_row(rows, cfg.cal.headers)
    billing = _billing_line(rows[: header_index or 0], cfg)
    if header_index is None or billing is None:
        result.total_mismatches.append(sheet_ref)
        return result
    billing_date, declared_total = billing
    card_last4 = _card_last4(rows[:header_index])
    width = len(cfg.cal.headers)
    charges_seen = 0
    for row_number, cell_row in enumerate(cell_rows[header_index + 1 :], start=header_index + 2):
        cells = tuple(cell.value for cell in cell_row[:width])
        if all(value is None for value in cells) or isinstance(cells[0], str):
            continue  # blank rows and the free-text footer
        if cells[3] is None:  # not charged yet (pending) or informational (club points)
            result.skipped_no_charge += 1
            continue
        if isinstance(cells[3], int | float) and not isinstance(cells[3], bool):
            charges_seen += to_agorot(cells[3])
        ref = f"{sheet_ref}!{row_number}"
        try:
            result.transactions.append(
                _parse_row(ref, cells, cell_row[2], billing_date, card_last4, cfg)
            )
        except RowError as exc:
            raw = raw_row(cfg.cal.headers, cells)
            result.quarantined.append(QuarantinedRow(ref, f"tx:{exc}", raw))
    if declared_total != charges_seen:
        result.total_mismatches.append(sheet_ref)
    return result


def _parse_row(
    ref: str,
    cells: tuple[Any, ...],
    original_cell: Cell,
    billing_date: date,
    card_last4: str | None,
    cfg: CardExportsConfig,
) -> CardTransaction:
    tx_date, merchant, original, charge, tx_type, branch, notes = cells
    if isinstance(tx_date, datetime):
        tx_date = tx_date.date()
    if not isinstance(tx_date, date):
        raise RowError("tx_date_invalid")
    notes_text = clean(notes)
    currency = _CURRENCY_IN_FORMAT.search(original_cell.number_format or "")
    return CardTransaction(
        source_ref=ref,
        tx_date=tx_date,
        billing_date=billing_date,
        description=required_text(merchant, "description"),
        card_last4=card_last4,
        tx_type=clean(tx_type),
        charge_agorot=amount(charge, "charge"),
        original_amount_agorot=None if original is None else amount(original, "original"),
        original_currency=currency.group(1).strip() if currency else None,
        installment=parse_installment(notes_text, cfg.installment_pattern),
        source_category=clean(branch),
        notes=notes_text,
    )


def _billing_line(
    preamble: list[tuple[Any, ...]], cfg: CardExportsConfig
) -> tuple[date, int] | None:
    """Find the billing date and the declared cycle total in the preamble."""
    pattern = re.compile(re.escape(cfg.cal.billing_line_prefix) + _BILLING_LINE)
    for row in preamble:
        match = pattern.search(clean(row[0]) or "") if row else None
        if match:
            day, month, year, total = match.groups()
            try:
                return date(int(year), int(month), int(day)), to_agorot(total)
            except ValueError:
                return None
    return None


def _card_last4(preamble: list[tuple[Any, ...]]) -> str | None:
    title = clean(preamble[0][0]) if preamble and preamble[0] else None
    match = _CARD_AT_END.search(title or "")
    return match.group(1) if match else None


@dataclass(frozen=True)
class CalAdapter:
    """The Cal export as an ingestion source (see fin.storage.ingest.adapter)."""

    cfg: CardExportsConfig

    @property
    def source(self) -> str:
        return self.cfg.cal.source

    def detect(self, path: Path) -> bool:
        sheets = read_header_rows(path)
        return sheets is not None and is_cal_workbook(sheets, self.cfg)

    def parse(self, path: Path) -> CardParseResult:
        return parse_cal_workbook(path, self.cfg)

    def validate(self, parsed: CardParseResult) -> None:
        check_card_totals(parsed)


def build_adapter() -> CalAdapter:
    """Build the adapter from the card layouts in config."""
    return CalAdapter(load_card_config())
