"""Idempotent persistence of parsed bank statements."""

import hashlib
import json
import sqlite3
from collections import Counter
from collections.abc import Sequence
from datetime import UTC, datetime

from fin.storage.ingest.card_store import CardImportSummary
from fin.storage.ingest.checks import check_bank_chain
from fin.storage.ingest.records import BankParseResult, BankTransaction


def bank_hashes(transactions: Sequence[BankTransaction], source: str) -> list[str]:
    """Return a stable identity hash per bank transaction.

    The balance after the transaction is part of the identity, so overlapping
    statements map the same line to the same hash. Fully identical lines are
    numbered so that both survive.
    """
    occurrences: Counter[tuple[object, ...]] = Counter()
    hashes = []
    for tx in transactions:
        key = (
            source,
            tx.tx_date.isoformat(),
            tx.description,
            tx.amount_agorot,
            tx.balance_after_agorot,
        )
        payload = json.dumps([*key, occurrences[key]], ensure_ascii=False)
        occurrences[key] += 1
        hashes.append(hashlib.sha256(payload.encode("utf-8")).hexdigest())
    return hashes


def store_bank_import(
    conn: sqlite3.Connection, result: BankParseResult, file_hash: str
) -> CardImportSummary:
    """Write one parsed statement in a single transaction.

    Refuses the whole file when a line could not be decoded or the running
    balance does not check out.
    """
    check_bank_chain(result)
    source = result.source
    hashes = bank_hashes(result.transactions, source)
    with conn:
        run_id = conn.execute(
            "INSERT INTO import_runs (source, file_sha256, started_at, rows_seen,"
            " rows_inserted, rows_duplicate, rows_quarantined) VALUES (?, ?, ?, ?, 0, 0, 0)",
            (
                source,
                file_hash,
                datetime.now(UTC).isoformat(timespec="seconds"),
                len(result.transactions),
            ),
        ).lastrowid
        inserted = 0
        for tx, tx_hash in zip(result.transactions, hashes, strict=True):
            inserted += conn.execute(
                "INSERT OR IGNORE INTO transactions (tx_hash, source, source_ref, tx_date,"
                " budget_month, description, total_amount_agorot, my_share_agorot,"
                " balance_after_agorot, import_run_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    tx_hash,
                    source,
                    tx.source_ref,
                    tx.tx_date.isoformat(),
                    tx.budget_month,
                    tx.description,
                    tx.amount_agorot,
                    tx.amount_agorot,
                    tx.balance_after_agorot,
                    run_id,
                ),
            ).rowcount
        duplicate = len(result.transactions) - inserted
        conn.execute(
            "UPDATE import_runs SET rows_inserted = ?, rows_duplicate = ? WHERE id = ?",
            (inserted, duplicate, run_id),
        )
    return CardImportSummary(
        rows_seen=len(result.transactions),
        rows_inserted=inserted,
        rows_duplicate=duplicate,
        rows_quarantined=0,
        skipped_no_charge=0,
    )
