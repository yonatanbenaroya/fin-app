"""Control checks over parsed files. Pure: no file or database access."""

from fin.storage.ingest.adapter import ControlTotalError
from fin.storage.ingest.records import BankParseResult, CardParseResult


def check_card_totals(result: CardParseResult) -> None:
    """Fail when a sheet's charges do not add up to the total the file declares."""
    if result.total_mismatches:
        raise ControlTotalError(
            f"control total mismatch in {len(result.total_mismatches)} sheet(s)"
        )


def check_bank_chain(result: BankParseResult) -> None:
    """Fail when a line could not be decoded or the running balance breaks."""
    if not result.is_consistent:
        raise ControlTotalError(
            f"{result.chain_breaks} balance break(s), {result.unparsed_lines} unparsed line(s)"
        )
