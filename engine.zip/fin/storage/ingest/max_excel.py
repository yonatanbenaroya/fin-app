"""Parser for Max credit card exports. Pure: reads the file, touches no database.

Every sheet has a few preamble rows, a 16-column header, transaction rows,
and a footer with a total label followed by the total of the charge column.
"""

import re
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any

from fin.logic import to_agorot
from fin.storage.ingest.card_config import CardExportsConfig, load_card_config
from fin.storage.ingest.cells import (
    RowError,
    amount,
    clean,
    find_header_row,
    open_workbook,
    raw_row,
    read_header_rows,
    required_text,
)
from fin.storage.ingest.checks import check_card_totals
from fin.storage.ingest.installments import parse_installment
from fin.storage.ingest.records import CardParseResult, CardTransaction, QuarantinedRow

_DATE_FORMAT = "%d-%m-%Y"
_NUMBER = re.compile(r"-?[\d,]+(?:\.\d+)?")


def is_max_workbook(sheets: list[list[tuple[Any, ...]]], cfg: CardExportsConfig) -> bool:
    """True when any sheet carries the Max header row."""
    return any(find_header_row(rows, cfg.max.headers) is not None for rows in sheets)


def parse_max_workbook(path: Path, cfg: CardExportsConfig) -> CardParseResult:
    """Parse all sheets of a Max export."""
    result = CardParseResult(source=cfg.max.source)
    for sheet in open_workbook(path).worksheets:
        rows = list(sheet.iter_rows(values_only=True))
        header_index = find_header_row(rows, cfg.max.headers)
        if header_index is None:
            continue
        _parse_sheet(f"{path.name}:{sheet.title.strip()}", rows, header_index, cfg, result)
    return result


def _parse_sheet(
    sheet_ref: str,
    rows: list[tuple[Any, ...]],
    header_index: int,
    cfg: CardExportsConfig,
    result: CardParseResult,
) -> None:
    width = len(cfg.max.headers)
    charges_seen = 0
    declared_total: int | None = None
    expect_total = False
    for row_number, row in enumerate(rows[header_index + 1 :], start=header_index + 2):
        cells = tuple(row[:width]) + (None,) * (width - len(row))
        if all(cell is None for cell in cells):
            continue
        first = clean(cells[0])
        if cells[1] is None:  # footer: the total label, then the total itself
            if expect_total and first is not None:
                declared_total = _declared_total(first)
                expect_total = False
            elif first == cfg.max.total_label:
                expect_total = True
            continue
        if isinstance(cells[5], int | float) and not isinstance(cells[5], bool):
            charges_seen += to_agorot(cells[5])
        ref = f"{sheet_ref}!{row_number}"
        try:
            result.transactions.append(_parse_row(ref, cells, cfg))
        except RowError as exc:
            raw = raw_row(cfg.max.headers, cells)
            result.quarantined.append(QuarantinedRow(ref, f"tx:{exc}", raw))
    if declared_total is None or declared_total != charges_seen:
        result.total_mismatches.append(sheet_ref)


def _parse_row(ref: str, cells: tuple[Any, ...], cfg: CardExportsConfig) -> CardTransaction:
    (tx_date, merchant, category, card, tx_type, charge, charge_currency) = cells[:7]
    original, original_currency, billing_date, notes = cells[7:11]
    if clean(charge_currency) != cfg.max.shekel_symbol:
        raise RowError("charge_currency_not_shekel")
    notes_text = clean(notes)
    return CardTransaction(
        source_ref=ref,
        tx_date=_date(tx_date, "tx_date"),
        billing_date=_date(billing_date, "billing_date"),
        description=required_text(merchant, "description"),
        card_last4=clean(card),
        tx_type=clean(tx_type),
        charge_agorot=amount(charge, "charge"),
        original_amount_agorot=None if original is None else amount(original, "original"),
        original_currency=clean(original_currency),
        installment=parse_installment(notes_text, cfg.installment_pattern),
        source_category=clean(category),
        notes=notes_text,
    )


def _date(value: Any, name: str) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = clean(value)
    if text is None:
        raise RowError(f"{name}_missing")
    try:
        return datetime.strptime(text, _DATE_FORMAT).date()
    except ValueError as exc:
        raise RowError(f"{name}_invalid") from exc


def _declared_total(text: str) -> int | None:
    match = _NUMBER.search(text)
    if match is None:
        return None
    return to_agorot(match.group(0))


@dataclass(frozen=True)
class MaxAdapter:
    """The Max export as an ingestion source (see fin.storage.ingest.adapter)."""

    cfg: CardExportsConfig

    @property
    def source(self) -> str:
        return self.cfg.max.source

    def detect(self, path: Path) -> bool:
        sheets = read_header_rows(path)
        return sheets is not None and is_max_workbook(sheets, self.cfg)

    def parse(self, path: Path) -> CardParseResult:
        return parse_max_workbook(path, self.cfg)

    def validate(self, parsed: CardParseResult) -> None:
        check_card_totals(parsed)


def build_adapter() -> MaxAdapter:
    """Build the adapter from the card layouts in config."""
    return MaxAdapter(load_card_config())
