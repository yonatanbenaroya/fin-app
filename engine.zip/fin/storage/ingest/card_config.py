"""Layout description of the credit card exports, loaded from YAML."""

import re
from dataclasses import dataclass
from pathlib import Path

import yaml

from fin.storage.config_files import CONFIG_DIR
from fin.storage.settings import ConfigError

DEFAULT_CARD_CONFIG_PATH = CONFIG_DIR / "card_exports.yaml"


@dataclass(frozen=True)
class MaxConfig:
    source: str
    headers: tuple[str, ...]
    total_label: str
    shekel_symbol: str


@dataclass(frozen=True)
class CalConfig:
    source: str
    headers: tuple[str, ...]
    billing_line_prefix: str


@dataclass(frozen=True)
class CardExportsConfig:
    installment_pattern: re.Pattern[str]
    max: MaxConfig
    cal: CalConfig


def load_card_config(path: Path | None = None) -> CardExportsConfig:
    """Load the card export layouts from YAML."""
    config_path = path or DEFAULT_CARD_CONFIG_PATH
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        return CardExportsConfig(
            installment_pattern=re.compile(raw["installment_pattern"]),
            max=MaxConfig(
                source=str(raw["max"]["source"]),
                headers=tuple(raw["max"]["headers"]),
                total_label=str(raw["max"]["total_label"]),
                shekel_symbol=str(raw["max"]["shekel_symbol"]),
            ),
            cal=CalConfig(
                source=str(raw["cal"]["source"]),
                headers=tuple(raw["cal"]["headers"]),
                billing_line_prefix=str(raw["cal"]["billing_line_prefix"]),
            ),
        )
    except FileNotFoundError as exc:
        raise ConfigError(f"card config not found: {config_path}") from exc
    except (yaml.YAMLError, KeyError, TypeError, ValueError, re.error) as exc:
        raise ConfigError(f"invalid card config: {config_path}") from exc
