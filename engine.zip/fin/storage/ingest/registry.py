"""The list of ingestion sources. Registering an adapter here is all a new source needs."""

from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any

from fin.storage.ingest import cal_excel, hapoalim_pdf, max_excel
from fin.storage.ingest.adapter import SourceAdapter

AdapterFactory = Callable[[], SourceAdapter[Any]]

# Order matters: the first adapter that recognizes a file takes it.
ADAPTER_FACTORIES: tuple[AdapterFactory, ...] = (
    max_excel.build_adapter,
    cal_excel.build_adapter,
    hapoalim_pdf.build_adapter,
)


def build_adapters() -> tuple[SourceAdapter[Any], ...]:
    """Build every registered adapter. Raises ConfigError when a layout config is bad."""
    return tuple(factory() for factory in ADAPTER_FACTORIES)


def find_adapter(path: Path, adapters: Sequence[SourceAdapter[Any]]) -> SourceAdapter[Any] | None:
    """Return the first adapter that recognizes the file, else None."""
    for adapter in adapters:
        if adapter.detect(path):
            return adapter
    return None
