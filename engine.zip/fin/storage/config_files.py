"""Reading and writing the YAML configuration files. Validation lives in logic."""

from pathlib import Path
from typing import Any

import yaml

from fin.logic import (
    AGOROT_PER_SHEKEL,
    BaselineConfig,
    BudgetConfig,
    ConfigError,
    GoalsConfig,
    Rule,
    Scenario,
    Taxonomy,
    parse_baseline_config,
    parse_budget_config,
    parse_goals_config,
    parse_private_rules,
    parse_scenarios,
    parse_taxonomy,
)

# The committed configuration that ships with the code.
CONFIG_DIR = Path(__file__).resolve().parents[2] / "config"
DEFAULT_TAXONOMY_PATH = CONFIG_DIR / "categories.yaml"
DEFAULT_SCENARIOS_PATH = CONFIG_DIR / "scenarios.yaml"
_MISSING = object()


def _read(path: Path) -> dict[str, Any]:
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ConfigError(f"config file not found: {path}") from exc
    except yaml.YAMLError as exc:
        raise ConfigError(f"invalid YAML in {path}") from exc
    if not isinstance(raw, dict):
        raise ConfigError(f"config root must be a mapping: {path}")
    return raw


def _read_optional(path: Path) -> Any:
    """The parsed YAML document, or _MISSING when the file does not exist."""
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return _MISSING
    except yaml.YAMLError as exc:
        raise ConfigError(f"invalid YAML in {path}") from exc


def load_taxonomy(path: Path | None = None) -> Taxonomy:
    """Load the taxonomy; every rule and mapping must point at a known category."""
    config_path = path or DEFAULT_TAXONOMY_PATH
    return parse_taxonomy(_read(config_path), str(config_path))


def load_private_rules(path: Path, taxonomy: Taxonomy) -> tuple[Rule, ...]:
    """Load personal rules; a missing file simply means there are none."""
    if not path.is_file():
        return ()
    return parse_private_rules(_read(path), taxonomy, str(path))


def load_baseline_config(path: Path) -> BaselineConfig:
    """Load the declared baseline values; a missing file means nothing is declared."""
    raw = _read_optional(path)
    return BaselineConfig() if raw is _MISSING else parse_baseline_config(raw, str(path))


def load_goals_config(path: Path) -> GoalsConfig:
    """Load goals and timeline; a missing file means there are none."""
    raw = _read_optional(path)
    return GoalsConfig() if raw is _MISSING else parse_goals_config(raw, str(path))


def load_budget_config(path: Path) -> BudgetConfig | None:
    """Load the saved budget, or None when no budget was saved yet."""
    raw = _read_optional(path)
    return None if raw is _MISSING else parse_budget_config(raw, str(path))


def load_scenarios(paths: list[Path] | tuple[Path, ...]) -> tuple[Scenario, ...]:
    """Load scenarios from every file that exists; names must be unique."""
    documents = [
        (raw, str(path)) for path in paths if (raw := _read_optional(path)) is not _MISSING
    ]
    return parse_scenarios(documents)


_HEADER = (
    "# Monthly budget (gitignored): a spending ceiling per bucket, in shekels.\n"
    "# Written by `fin budget --save`; edit any ceiling by hand and run `fin budget`\n"
    "# to check that the plan still keeps the monthly cash flow positive.\n"
)


def save_budget_config(path: Path, config: BudgetConfig) -> None:
    """Write the budget as YAML, with amounts in shekels."""
    body = yaml.safe_dump(
        {
            "start_month": config.start_month,
            "target_surplus": _shekels(config.target_surplus_agorot),
            "ceilings": {b: _shekels(amount) for b, amount in config.ceilings.items()},
        },
        allow_unicode=True,
        sort_keys=False,
    )
    path.write_text(_HEADER + "\n" + body, encoding="utf-8")


def _shekels(agorot: int) -> int | float:
    whole, rest = divmod(agorot, AGOROT_PER_SHEKEL)
    return whole if rest == 0 else agorot / AGOROT_PER_SHEKEL
