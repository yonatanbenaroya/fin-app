"""SQLite connection and schema migrations, tracked with PRAGMA user_version."""

import sqlite3
from pathlib import Path

# Append-only: each entry upgrades the schema by one version. Never edit an
# entry that has already been applied to a real database.
MIGRATIONS: tuple[str, ...] = (
    """
    CREATE TABLE meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    """,
    """
    CREATE TABLE import_runs (
        id INTEGER PRIMARY KEY,
        source TEXT NOT NULL,
        file_sha256 TEXT NOT NULL,
        started_at TEXT NOT NULL,
        rows_seen INTEGER NOT NULL,
        rows_inserted INTEGER NOT NULL,
        rows_duplicate INTEGER NOT NULL,
        rows_quarantined INTEGER NOT NULL
    );
    -- Amounts are integer agorot; expenses are negative, income is positive.
    CREATE TABLE transactions (
        id INTEGER PRIMARY KEY,
        tx_hash TEXT NOT NULL UNIQUE,
        source TEXT NOT NULL,
        source_ref TEXT NOT NULL,
        tx_date TEXT NOT NULL,
        budget_month TEXT NOT NULL,
        description TEXT NOT NULL,
        bucket_raw TEXT,
        category_raw TEXT,
        bucket TEXT,
        category TEXT,
        total_amount_agorot INTEGER NOT NULL,
        my_share_agorot INTEGER NOT NULL,
        paid_by TEXT,
        notes TEXT,
        import_run_id INTEGER NOT NULL REFERENCES import_runs(id)
    );
    CREATE INDEX idx_transactions_tx_date ON transactions(tx_date);
    CREATE INDEX idx_transactions_budget_month ON transactions(budget_month);
    CREATE TABLE quarantine (
        id INTEGER PRIMARY KEY,
        source TEXT NOT NULL,
        source_ref TEXT NOT NULL,
        reason TEXT NOT NULL,
        raw_json TEXT NOT NULL,
        import_run_id INTEGER NOT NULL REFERENCES import_runs(id)
    );
    CREATE TABLE income (
        id INTEGER PRIMARY KEY,
        source TEXT NOT NULL,
        month TEXT NOT NULL,
        gross_agorot INTEGER NOT NULL,
        net_agorot INTEGER NOT NULL,
        notes TEXT,
        UNIQUE (source, month)
    );
    CREATE TABLE budgets (
        id INTEGER PRIMARY KEY,
        source TEXT NOT NULL,
        budget_month TEXT NOT NULL,
        bucket TEXT NOT NULL,
        budget_agorot INTEGER NOT NULL,
        UNIQUE (source, budget_month, bucket)
    );
    """,
    """
    ALTER TABLE quarantine ADD COLUMN budget_month TEXT;
    """,
    """
    ALTER TABLE transactions ADD COLUMN billing_date TEXT;
    ALTER TABLE transactions ADD COLUMN original_amount_agorot INTEGER;
    ALTER TABLE transactions ADD COLUMN original_currency TEXT;
    ALTER TABLE transactions ADD COLUMN card_last4 TEXT;
    ALTER TABLE transactions ADD COLUMN tx_type TEXT;
    ALTER TABLE transactions ADD COLUMN installment_number INTEGER;
    ALTER TABLE transactions ADD COLUMN installment_total INTEGER;
    ALTER TABLE transactions ADD COLUMN source_category TEXT;
    ALTER TABLE quarantine ADD COLUMN source_file TEXT;
    """,
    """
    ALTER TABLE transactions ADD COLUMN balance_after_agorot INTEGER;
    """,
    """
    ALTER TABLE transactions ADD COLUMN flow_kind TEXT;
    ALTER TABLE transactions ADD COLUMN category_rule TEXT;
    """,
    """
    -- Part of a card bill payment that is already detailed in a card ledger.
    ALTER TABLE transactions ADD COLUMN detail_covered_agorot INTEGER;
    """,
    """
    -- The change log of the account: every edit to settings, made on any device.
    -- The state is the fold of all changes (fin.logic: fold_changes).
    CREATE TABLE changes (
        id TEXT PRIMARY KEY,
        stamp TEXT NOT NULL,
        entity TEXT NOT NULL,
        item_key TEXT NOT NULL,
        field TEXT NOT NULL,
        value_json TEXT,
        deleted INTEGER NOT NULL DEFAULT 0,
        pushed INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX changes_by_item ON changes (entity, item_key);
    CREATE INDEX changes_not_pushed ON changes (pushed) WHERE pushed = 0;
    """,
    """
    -- A legacy workbook row's own category and group, kept so the user's category changes
    -- (fin.logic.categorize.overlay) can be put on top of them and undone exactly.
    ALTER TABLE transactions ADD COLUMN category_orig TEXT;
    ALTER TABLE transactions ADD COLUMN bucket_orig TEXT;
    """,
)


def connect(path: Path | str) -> sqlite3.Connection:
    """Open the database, creating parent folders, with foreign keys enforced."""
    if str(path) != ":memory:":
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def schema_version(conn: sqlite3.Connection) -> int:
    """Return the schema version currently applied to the database."""
    return int(conn.execute("PRAGMA user_version").fetchone()[0])


def migrate(conn: sqlite3.Connection) -> int:
    """Apply pending migrations in order and return the resulting version."""
    current = schema_version(conn)
    if current > len(MIGRATIONS):
        raise RuntimeError(
            f"database schema version {current} is newer than this code ({len(MIGRATIONS)})"
        )
    for version, script in enumerate(MIGRATIONS[current:], start=current + 1):
        try:
            conn.executescript(f"BEGIN;\n{script}\nPRAGMA user_version = {version};\nCOMMIT;")
        except sqlite3.Error:
            conn.rollback()
            if schema_version(conn) >= version:
                continue  # another connection (a parallel request) applied it meanwhile
            raise
    return schema_version(conn)
