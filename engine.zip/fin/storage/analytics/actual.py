"""Monthly summary of the actual ledger: bank and card transactions together.

Relies on the categorization step: each transaction carries a flow kind, and
card bills that are detailed in a card ledger are internal transfers, so the
same money is never counted twice.
"""

import sqlite3
from collections.abc import Callable, Mapping

from fin.logic import (
    EXPENSE,
    FAMILY_SUPPORT,
    INCOME,
    INVESTMENT,
    LAYER_CARD_PAYMENT,
    LAYER_ESTIMATE,
    LAYER_NONE,
    TRANSFER_IN,
)
from fin.storage.analytics.monthly import BucketLine, MonthSummary, PeriodSummary
from fin.storage.categorize_apply import LEGACY_SOURCE

ACTUAL = "actual"
_COUNTED_KINDS = (EXPENSE, INCOME, TRANSFER_IN, INVESTMENT, FAMILY_SUPPORT)


def actual_summaries(
    conn: sqlite3.Connection,
    start: str | None = None,
    end: str | None = None,
    ceilings_for: Callable[[str], Mapping[str, int]] | None = None,
) -> PeriodSummary:
    """Summarize income, spending by bucket, receipts and investments per month.

    Bounds are inclusive 'YYYY-MM' strings. Spending is the net of expense
    transactions, so refunds reduce it. For a card bill that is only partly
    detailed in a card ledger, just the undetailed remainder is spending.
    Budgets come from the legacy workbook where the month has them; otherwise
    from `ceilings_for(month)`, the saved budget's ceilings, when it is given.
    """
    low, high = start or "0000-00", end or "9999-99"
    scope = "source != ? AND budget_month BETWEEN ? AND ?"
    params = (LEGACY_SOURCE, low, high)
    spent: dict[str, dict[str, int]] = {}
    for month, bucket, total in conn.execute(
        "SELECT budget_month, COALESCE(bucket, ''),"
        " -SUM(my_share_agorot - COALESCE(detail_covered_agorot, 0)) FROM transactions"
        f" WHERE {scope} AND flow_kind = ? GROUP BY budget_month, bucket",
        (*params, EXPENSE),
    ):
        spent.setdefault(month, {})[bucket] = total

    def kind_sum(alias: str) -> str:
        return f" SUM(CASE WHEN flow_kind = ? THEN my_share_agorot ELSE 0 END) AS {alias},"

    placeholders = ", ".join("?" for _ in _COUNTED_KINDS)
    per_month = {
        row["budget_month"]: row
        for row in conn.execute(
            "SELECT budget_month,"
            + kind_sum("income")
            + kind_sum("transfers_in")
            + kind_sum("investments")
            + kind_sum("family_support")
            + f" SUM(flow_kind IN ({placeholders})) AS counted,"
            " SUM(category_rule = ?) AS uncategorized,"
            " SUM(category_rule = ?) AS unmatched,"
            " SUM(category_rule LIKE ?) AS estimated"
            f" FROM transactions WHERE {scope} GROUP BY budget_month",
            (
                INCOME,
                TRANSFER_IN,
                INVESTMENT,
                FAMILY_SUPPORT,
                *_COUNTED_KINDS,
                LAYER_NONE,
                f"{LAYER_CARD_PAYMENT}:unmatched",
                f"{LAYER_ESTIMATE}:%",
                *params,
            ),
        )
    }
    budgets: dict[str, dict[str, int]] = {}
    for month, bucket, total in conn.execute(
        "SELECT budget_month, bucket, SUM(budget_agorot) FROM budgets"
        " WHERE budget_month BETWEEN ? AND ? GROUP BY budget_month, bucket",
        (low, high),
    ):
        budgets.setdefault(month, {})[bucket] = total
    months = []
    for month in sorted(m for m, row in per_month.items() if row["counted"]):
        row = per_month[month]
        month_spent = spent.get(month, {})
        month_budgets = budgets.get(month) or (ceilings_for(month) if ceilings_for else {})
        names = sorted(set(month_spent) | set(month_budgets))
        months.append(
            MonthSummary(
                month=month,
                buckets=tuple(
                    BucketLine(name, month_spent.get(name, 0), month_budgets.get(name))
                    for name in names
                ),
                transactions=row["counted"],
                quarantined=0,
                net_income_agorot=row["income"],
                transfers_in_agorot=row["transfers_in"],
                investments_agorot=row["investments"],
                family_support_agorot=row["family_support"],
                uncategorized=row["uncategorized"] or 0,
                unmatched_card_payments=row["unmatched"] or 0,
                estimated=row["estimated"] or 0,
            )
        )
    return PeriodSummary(tuple(months), ACTUAL)


def latest_actual_date(conn: sqlite3.Connection) -> str | None:
    """Return the newest bank or card transaction date, or None without data."""
    row = conn.execute(
        "SELECT MAX(tx_date) FROM transactions WHERE source != ?", (LEGACY_SOURCE,)
    ).fetchone()
    return row[0]


def latest_actual_month(conn: sqlite3.Connection) -> str | None:
    """Return the month of the newest bank or card transaction date, or None without data.

    Uses the transaction date, not the budget month: installments are filed under
    future billing months, which says nothing about how far the data reaches.
    """
    row = conn.execute(
        "SELECT MAX(tx_date) FROM transactions WHERE source != ?", (LEGACY_SOURCE,)
    ).fetchone()
    return row[0][:7] if row[0] else None


def latest_bank_balance(conn: sqlite3.Connection) -> tuple[str, int] | None:
    """Return (date, balance) after the newest bank movement, or None without one.

    Several movements can share the newest date, and statements are not stored
    in time order. The last one is the row whose balance is not the starting
    point of another row of that day.
    """
    rows = conn.execute(
        "SELECT tx_date, my_share_agorot, balance_after_agorot FROM transactions"
        " WHERE balance_after_agorot IS NOT NULL AND tx_date = (SELECT MAX(tx_date)"
        " FROM transactions WHERE balance_after_agorot IS NOT NULL) ORDER BY id"
    ).fetchall()
    if not rows:
        return None
    balances = [row["balance_after_agorot"] for row in rows]
    starts = [row["balance_after_agorot"] - row["my_share_agorot"] for row in rows]
    final = [
        balance
        for index, balance in enumerate(balances)
        if balance not in starts[:index] + starts[index + 1 :]
    ]
    return rows[0]["tx_date"], (final or balances)[-1]
