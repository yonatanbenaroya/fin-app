"""Row-level reads of the actual ledger, for the screens.

The actual ledger is bank and card transactions together; the legacy workbook
is left out, and so are card bills whose detail is in a card ledger (they are
internal transfers). For a partly detailed card bill only the undetailed
remainder is shown, matching the monthly report.
"""

import sqlite3
from dataclasses import dataclass

from fin.logic import EXPENSE, INTERNAL_TRANSFER, Charge
from fin.storage.categorize_apply import LEGACY_SOURCE

_AMOUNT = "(my_share_agorot - COALESCE(detail_covered_agorot, 0))"


@dataclass(frozen=True)
class LedgerEntry:
    tx_id: int
    tx_date: str
    budget_month: str
    description: str
    amount_agorot: int
    category: str | None
    bucket: str | None
    source: str
    flow_kind: str | None
    tx_hash: str = ""
    count_date: str = ""  # the day it counts on (an installment's purchase day moved)


def ledger_entries(
    conn: sqlite3.Connection, first_month: str, last_month: str
) -> tuple[LedgerEntry, ...]:
    """Transactions in the inclusive range of budget months, newest first."""
    rows = conn.execute(
        f"SELECT id, tx_date, budget_month, description, {_AMOUNT} AS amount, category, bucket,"
        " source, flow_kind, tx_hash, COALESCE(count_date, tx_date) FROM transactions"
        " WHERE source != ? AND budget_month BETWEEN ? AND ?"
        " AND COALESCE(flow_kind, '') != ? AND " + _AMOUNT + " != 0"
        " AND tx_hash NOT LIKE 'manual-offset:%'"
        " ORDER BY COALESCE(count_date, tx_date) DESC, id DESC",
        (LEGACY_SOURCE, first_month, last_month, INTERNAL_TRANSFER),
    ).fetchall()
    return tuple(LedgerEntry(*row) for row in rows)


def ledger_entries_between(
    conn: sqlite3.Connection, first_day: str, last_day: str
) -> tuple[LedgerEntry, ...]:
    """Transactions that count on a day in an inclusive range ("YYYY-MM-DD"), newest first.

    The counting day (an installment's purchase day moved to its month, spec v0.39), so a
    month's filter and the month's totals always agree."""
    rows = conn.execute(
        f"SELECT id, tx_date, budget_month, description, {_AMOUNT} AS amount, category, bucket,"
        " source, flow_kind, tx_hash, COALESCE(count_date, tx_date) FROM transactions"
        " WHERE source != ? AND COALESCE(count_date, tx_date) BETWEEN ? AND ?"
        " AND COALESCE(flow_kind, '') != ? AND " + _AMOUNT + " != 0"
        " AND tx_hash NOT LIKE 'manual-offset:%'"
        " ORDER BY COALESCE(count_date, tx_date) DESC, id DESC",
        (LEGACY_SOURCE, first_day, last_day, INTERNAL_TRANSFER),
    ).fetchall()
    return tuple(LedgerEntry(*row) for row in rows)


def category_spend(conn: sqlite3.Connection, month: str) -> tuple[tuple[str, str, int], ...]:
    """Net spending per (bucket, category) in one budget month, largest first."""
    rows = conn.execute(
        f"SELECT COALESCE(bucket, ''), COALESCE(category, ''), -SUM({_AMOUNT}) AS spent"
        " FROM transactions WHERE source != ? AND budget_month = ? AND flow_kind = ?"
        " GROUP BY bucket, category ORDER BY spent DESC, bucket, category",
        (LEGACY_SOURCE, month, EXPENSE),
    ).fetchall()
    return tuple((bucket, category, spent) for bucket, category, spent in rows)


def upcoming_card_charges(
    conn: sqlite3.Connection, after_month: str
) -> tuple[tuple[str, str, str, int], ...]:
    """Card installments already known that are billed after `after_month`.

    When the money leaves, so by the billing month, not the month the payment counts
    in (spec v0.39). Returns (billing month, description, bucket, amount) per month
    and merchant, soonest first; amounts are positive.
    """
    rows = conn.execute(
        f"SELECT substr(billing_date, 1, 7) AS paid, description, COALESCE(bucket, ''),"
        f" -SUM({_AMOUNT}) FROM transactions WHERE source != ? AND billing_date IS NOT NULL"
        " AND COALESCE(installment_total, 0) > 1 AND substr(billing_date, 1, 7) > ?"
        " AND flow_kind = ? GROUP BY paid, description, bucket ORDER BY paid, description",
        (LEGACY_SOURCE, after_month, EXPENSE),
    ).fetchall()
    return tuple(
        (month, description, bucket, amount) for month, description, bucket, amount in rows
    )


def month_charges(conn: sqlite3.Connection, month: str) -> tuple[Charge, ...]:
    """The expense rows of one budget month, for the fixed payments still due; a payment
    of a card installment deal is marked."""
    rows = conn.execute(
        f"SELECT description, COALESCE(bucket, ''), COALESCE(category, ''), -{_AMOUNT},"
        " COALESCE(installment_total, 0) > 1"
        " FROM transactions WHERE source != ? AND budget_month = ? AND flow_kind = ?"
        " ORDER BY count_date, id",
        (LEGACY_SOURCE, month, EXPENSE),
    ).fetchall()
    return tuple(
        Charge(text, bucket, amount, bool(installment), category)
        for text, bucket, category, amount, installment in rows
    )
