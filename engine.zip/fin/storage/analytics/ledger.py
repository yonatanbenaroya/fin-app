"""Row-level reads of the actual ledger, for the screens.

The actual ledger is bank and card transactions together; the legacy workbook
is left out, and so are card bills whose detail is in a card ledger (they are
internal transfers). For a partly detailed card bill only the undetailed
remainder is shown, matching the monthly report.
"""

import sqlite3
from dataclasses import dataclass

from fin.logic import EXPENSE, INTERNAL_TRANSFER
from fin.storage.categorize_apply import LEGACY_SOURCE

_AMOUNT = "(my_share_agorot - COALESCE(detail_covered_agorot, 0))"


@dataclass(frozen=True)
class LedgerEntry:
    tx_id: int
    tx_date: str
    budget_month: str
    description: str
    amount_agorot: int
    category: str | None
    bucket: str | None
    source: str
    flow_kind: str | None


def ledger_entries(
    conn: sqlite3.Connection, first_month: str, last_month: str
) -> tuple[LedgerEntry, ...]:
    """Transactions in the inclusive range of budget months, newest first."""
    rows = conn.execute(
        f"SELECT id, tx_date, budget_month, description, {_AMOUNT} AS amount, category, bucket,"
        " source, flow_kind FROM transactions"
        " WHERE source != ? AND budget_month BETWEEN ? AND ?"
        " AND COALESCE(flow_kind, '') != ? AND " + _AMOUNT + " != 0"
        " ORDER BY tx_date DESC, id DESC",
        (LEGACY_SOURCE, first_month, last_month, INTERNAL_TRANSFER),
    ).fetchall()
    return tuple(LedgerEntry(*row) for row in rows)


def category_spend(conn: sqlite3.Connection, month: str) -> tuple[tuple[str, str, int], ...]:
    """Net spending per (bucket, category) in one budget month, largest first."""
    rows = conn.execute(
        f"SELECT COALESCE(bucket, ''), COALESCE(category, ''), -SUM({_AMOUNT}) AS spent"
        " FROM transactions WHERE source != ? AND budget_month = ? AND flow_kind = ?"
        " GROUP BY bucket, category ORDER BY spent DESC, bucket, category",
        (LEGACY_SOURCE, month, EXPENSE),
    ).fetchall()
    return tuple((bucket, category, spent) for bucket, category, spent in rows)


def upcoming_card_charges(
    conn: sqlite3.Connection, after_month: str
) -> tuple[tuple[str, str, str, int], ...]:
    """Card charges already known for months after `after_month` (installments).

    Returns (budget month, description, bucket, amount) per month and merchant,
    soonest first; amounts are positive.
    """
    rows = conn.execute(
        f"SELECT budget_month, description, COALESCE(bucket, ''), -SUM({_AMOUNT})"
        " FROM transactions WHERE source != ? AND billing_date IS NOT NULL"
        " AND budget_month > ? AND flow_kind = ?"
        " GROUP BY budget_month, description, bucket ORDER BY budget_month, description",
        (LEGACY_SOURCE, after_month, EXPENSE),
    ).fetchall()
    return tuple(
        (month, description, bucket, amount) for month, description, bucket, amount in rows
    )
