"""Deterministic analytics: net worth, cash flow, burn rate."""
