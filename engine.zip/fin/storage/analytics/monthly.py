"""Monthly spending summaries per budget month. Deterministic, integer agorot only.

"Spent" is the user's own share of each expense, reported as a positive
number. A month is the budget period a transaction was filed under, which is
not always the calendar month of its date.
"""

import sqlite3

from fin.logic import BucketLine, IncomeReference, MonthSummary, PeriodSummary, mean_agorot


def recent_income(conn: sqlite3.Connection, months: int = 6) -> IncomeReference | None:
    """Summarize the most recent income months on record, or None when there are none."""
    rows = conn.execute(
        "SELECT month, SUM(net_agorot) FROM income GROUP BY month ORDER BY month DESC LIMIT ?",
        (months,),
    ).fetchall()
    if not rows:
        return None
    total = sum(net for _, net in rows)
    return IncomeReference(rows[-1][0], rows[0][0], len(rows), mean_agorot(total, len(rows)))


def monthly_summaries(
    conn: sqlite3.Connection,
    start: str | None = None,
    end: str | None = None,
    source: str | None = None,
) -> PeriodSummary:
    """Summarize every budget month with transactions, optionally within [start, end].

    Bounds are inclusive 'YYYY-MM' strings. Pass a source to read one ledger only:
    the same expense can exist in several sources, so mixing them double counts.
    """
    low, high = start or "0000-00", end or "9999-99"
    src = source or "%"
    spent: dict[str, dict[str, int]] = {}
    counts: dict[str, int] = {}
    for month, bucket, total, count in conn.execute(
        "SELECT budget_month, COALESCE(bucket, ''), -SUM(my_share_agorot), COUNT(*)"
        " FROM transactions WHERE my_share_agorot < 0 AND budget_month BETWEEN ? AND ?"
        " AND source LIKE ? GROUP BY budget_month, bucket",
        (low, high, src),
    ):
        spent.setdefault(month, {})[bucket] = total
        counts[month] = counts.get(month, 0) + count
    budgets: dict[str, dict[str, int]] = {}
    for month, bucket, total in conn.execute(
        "SELECT budget_month, bucket, SUM(budget_agorot) FROM budgets"
        " WHERE budget_month BETWEEN ? AND ? AND source LIKE ? GROUP BY budget_month, bucket",
        (low, high, src),
    ):
        budgets.setdefault(month, {})[bucket] = total
    income = dict(
        conn.execute("SELECT month, SUM(net_agorot) FROM income GROUP BY month").fetchall()
    )
    quarantined = dict(
        conn.execute(
            "SELECT budget_month, COUNT(*) FROM quarantine"
            " WHERE reason LIKE 'tx:%' AND budget_month IS NOT NULL AND source LIKE ?"
            " GROUP BY budget_month",
            (src,),
        ).fetchall()
    )
    months = []
    for month in sorted(spent):
        month_budgets = budgets.get(month, {})
        names = sorted(set(spent[month]) | set(month_budgets))
        lines = tuple(
            BucketLine(name, spent[month].get(name, 0), month_budgets.get(name)) for name in names
        )
        months.append(
            MonthSummary(
                month=month,
                buckets=lines,
                transactions=counts[month],
                quarantined=quarantined.get(month, 0),
                net_income_agorot=income.get(month),
            )
        )
    return PeriodSummary(tuple(months), source)
