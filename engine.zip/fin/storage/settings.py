"""YAML configuration loading. Personal values live in config, never in code."""

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from fin.logic import ConfigError

CONFIG_ENV_VAR = "FIN_CONFIG"
DEFAULT_CONFIG_PATH = Path("config/settings.yaml")
EXAMPLE_CONFIG_PATH = Path("config/settings.example.yaml")
DEFAULT_LEGACY_EXCEL_PATH = Path("Context/spendings.xlsx")
PRIVATE_RULES_FILE_NAME = "rules.private.yaml"
BASELINE_FILE_NAME = "baseline.private.yaml"
GOALS_FILE_NAME = "goals.private.yaml"
SCENARIOS_FILE_NAME = "scenarios.private.yaml"
BUDGET_FILE_NAME = "budget.private.yaml"


@dataclass(frozen=True)
class Settings:
    db_path: Path
    inbox_dir: Path
    categorize_model: str
    review_model: str
    legacy_excel_path: Path = DEFAULT_LEGACY_EXCEL_PATH
    private_rules_path: Path = Path("config/rules.private.yaml")
    baseline_path: Path = Path("config/baseline.private.yaml")
    goals_path: Path = Path("config/goals.private.yaml")
    scenarios_path: Path = Path("config/scenarios.private.yaml")
    budget_path: Path = Path("config/budget.private.yaml")
    # The sync relay (Supabase): its address and its public client key. Both are
    # meant to sit in a client app; the stored files are protected by access rules
    # and by end-to-end encryption. None until sync is set up.
    sync_url: str | None = None
    sync_anon_key: str | None = None


def resolve_config_path(path: Path | None = None) -> Path:
    """Pick the config file: explicit path, then $FIN_CONFIG, then the defaults."""
    if path is not None:
        return path
    env_path = os.environ.get(CONFIG_ENV_VAR)
    if env_path:
        return Path(env_path)
    if DEFAULT_CONFIG_PATH.exists():
        return DEFAULT_CONFIG_PATH
    return EXAMPLE_CONFIG_PATH


def load_config(path: Path | None = None) -> Settings:
    """Load and validate settings from a YAML file."""
    config_path = resolve_config_path(path)
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ConfigError(f"config file not found: {config_path}") from exc
    except yaml.YAMLError as exc:
        raise ConfigError(f"invalid YAML in {config_path}") from exc
    if not isinstance(raw, dict):
        raise ConfigError(f"config root must be a mapping: {config_path}")
    return Settings(
        db_path=Path(_require(raw, "paths", "db")),
        inbox_dir=Path(_require(raw, "paths", "inbox")),
        categorize_model=_require(raw, "models", "categorize"),
        review_model=_require(raw, "models", "review"),
        legacy_excel_path=Path(raw["paths"].get("legacy_excel") or DEFAULT_LEGACY_EXCEL_PATH),
        # Personal rules sit next to the settings file unless a path is given.
        private_rules_path=Path(
            raw["paths"].get("private_rules") or config_path.parent / PRIVATE_RULES_FILE_NAME
        ),
        baseline_path=Path(raw["paths"].get("baseline") or config_path.parent / BASELINE_FILE_NAME),
        goals_path=Path(raw["paths"].get("goals") or config_path.parent / GOALS_FILE_NAME),
        scenarios_path=Path(
            raw["paths"].get("scenarios") or config_path.parent / SCENARIOS_FILE_NAME
        ),
        budget_path=Path(raw["paths"].get("budget") or config_path.parent / BUDGET_FILE_NAME),
        **_sync(raw),
    )


def _sync(raw: dict[str, Any]) -> dict[str, str]:
    """The optional `sync:` section: an https address (http only for this machine) and a key."""
    section = raw.get("sync")
    if section is None:
        return {}
    if not isinstance(section, dict):
        raise ConfigError("sync must be a mapping with url and anon_key")
    url, key = section.get("url"), section.get("anon_key")
    if not isinstance(url, str) or not isinstance(key, str) or not url or not key:
        raise ConfigError("missing config value: sync.url or sync.anon_key")
    local = url.startswith(("http://127.0.0.1:", "http://localhost:"))
    if not (url.startswith("https://") or local):
        raise ConfigError("sync.url must start with https://")
    return {"sync_url": url.rstrip("/"), "sync_anon_key": key}


def _require(raw: dict[str, Any], section: str, key: str) -> str:
    values = raw.get(section)
    if not isinstance(values, dict) or not isinstance(values.get(key), str) or not values[key]:
        raise ConfigError(f"missing config value: {section}.{key}")
    return values[key]
