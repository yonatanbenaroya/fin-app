"""The private settings, read from wherever they live now: the YAML files or the change log.

Until `fin config import` runs, the settings are the YAML files, as before.
After it, they are items in the change log (fin.storage.settings_store) and the
files are only a way to export and re-import. Either way the same validators in
fin.logic read the same documents, so every number stays the same.
"""

import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from fin.logic import (
    AGOROT_PER_SHEKEL,
    BaselineConfig,
    BudgetConfig,
    ConfigError,
    GoalsConfig,
    Rule,
    Scenario,
    Taxonomy,
    parse_baseline_config,
    parse_budget_config,
    parse_goals_config,
    parse_private_rules,
    parse_scenarios,
)
from fin.storage.config_files import DEFAULT_SCENARIOS_PATH
from fin.storage.settings import Settings
from fin.storage.settings_store import MISSING, export_documents, settings_in_db

# Document name -> its file name next to the settings.
FILE_NAMES = {
    "rules": "rules.private.yaml",
    "baseline": "baseline.private.yaml",
    "goals": "goals.private.yaml",
    "scenarios": "scenarios.private.yaml",
    "budget": "budget.private.yaml",
}


def document_paths(settings: Settings) -> dict[str, Path]:
    return {
        "rules": settings.private_rules_path,
        "baseline": settings.baseline_path,
        "goals": settings.goals_path,
        "scenarios": settings.scenarios_path,
        "budget": settings.budget_path,
    }


def read_yaml(path: Path) -> Any:
    """The parsed file, or MISSING when it does not exist."""
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return MISSING
    except yaml.YAMLError as exc:
        raise ConfigError(f"invalid YAML in {path}") from exc


def read_files(settings: Settings) -> dict[str, Any]:
    return {name: read_yaml(path) for name, path in document_paths(settings).items()}


@dataclass(frozen=True)
class Configs:
    """The private settings documents and where they came from (for error messages)."""

    documents: dict[str, Any]
    labels: dict[str, str]

    def private_rules(self, taxonomy: Taxonomy) -> tuple[Rule, ...]:
        raw = self.documents["rules"]
        if raw is MISSING:
            return ()
        if not isinstance(raw, dict):
            raise ConfigError(f"config root must be a mapping: {self.labels['rules']}")
        return parse_private_rules(raw, taxonomy, self.labels["rules"])

    def baseline(self) -> BaselineConfig:
        raw = self.documents["baseline"]
        return (
            BaselineConfig()
            if raw is MISSING
            else parse_baseline_config(raw, self.labels["baseline"])
        )

    def goals(self) -> GoalsConfig:
        raw = self.documents["goals"]
        return GoalsConfig() if raw is MISSING else parse_goals_config(raw, self.labels["goals"])

    def budget(self) -> BudgetConfig | None:
        raw = self.documents["budget"]
        return None if raw is MISSING else parse_budget_config(raw, self.labels["budget"])

    def scenarios(self) -> tuple[Scenario, ...]:
        documents = [(read_yaml(DEFAULT_SCENARIOS_PATH), str(DEFAULT_SCENARIOS_PATH))]
        documents.append((self.documents["scenarios"], self.labels["scenarios"]))
        return parse_scenarios([(raw, label) for raw, label in documents if raw is not MISSING])


def load_configs(conn: sqlite3.Connection, settings: Settings) -> Configs:
    """The private settings from the change log when they live there, otherwise from the files."""
    if settings_in_db(conn):
        documents = export_documents(conn)
        return Configs(documents, {name: f"settings ({name})" for name in documents})
    paths = document_paths(settings)
    return Configs(read_files(settings), {name: str(path) for name, path in paths.items()})


def budget_document(config: BudgetConfig) -> dict[str, Any]:
    """A budget as the document `fin budget --save` writes: amounts in shekels."""
    return {
        "start_month": config.start_month,
        "target_surplus": _shekels(config.target_surplus_agorot),
        "ceilings": {bucket: _shekels(amount) for bucket, amount in config.ceilings.items()},
    }


def _shekels(agorot: int) -> int | float:
    whole, rest = divmod(agorot, AGOROT_PER_SHEKEL)
    return whole if rest == 0 else agorot / AGOROT_PER_SHEKEL
