"""This device's side of the account's shared log: what to send, and taking in what came.

An entry of the log holds this device's new settings changes and the facts it
imported since its last push (new import runs with their rows; income and
budget rows when they changed). Facts merge by identity and changes fold by
clock, so entries can arrive in any order and more than once. The sync box
encrypts entries; this module only deals in plain data and never sees a key.
"""

import hashlib
import json
import sqlite3
import time
from dataclasses import dataclass, field
from typing import Any

from fin.logic import ZERO_STAMP, Change, clock_receive, decode_stamp
from fin.storage.edits import MANUAL_RUN
from fin.storage.merge import (
    TABLES,
    MergeSummary,
    RunKey,
    export_snapshot,
    merge_snapshot,
    run_keys,
)
from fin.storage.settings_store import (
    device_id,
    get_meta,
    read_changes,
    set_meta,
    store_changes,
)

FORMAT = 1


def change_to_dict(change: Change) -> dict[str, Any]:
    return {
        "id": change.id,
        "stamp": change.stamp.encode(),
        "entity": change.entity,
        "key": change.key,
        "field": change.field,
        "value": change.value,
        "deleted": change.deleted,
    }


def change_from_dict(raw: dict[str, Any]) -> Change:
    return Change(
        str(raw["id"]),
        decode_stamp(str(raw["stamp"])),
        str(raw["entity"]),
        str(raw["key"]),
        str(raw.get("field", "")),
        raw.get("value"),
        bool(raw.get("deleted", False)),
    )


def _pushed_runs(conn: sqlite3.Connection) -> set[RunKey]:
    return {tuple(key) for key in json.loads(get_meta(conn, "pushed_runs") or "[]")}  # type: ignore[misc]


def _other_digest(conn: sqlite3.Connection) -> str:
    snapshot = export_snapshot(conn, skip_runs=frozenset(run_keys(conn).values()))
    rows = [snapshot[table]["rows"] for table in ("income", "budgets")]
    return hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest()


@dataclass(frozen=True)
class Outgoing:
    entry: dict[str, Any] | None  # None: nothing new to send
    change_ids: tuple[str, ...] = ()
    runs: tuple[RunKey, ...] = ()
    other_digest: str = ""


def outgoing(conn: sqlite3.Connection) -> Outgoing:
    """This device's new changes and facts, as one log entry (or None)."""
    pending = conn.execute("SELECT id FROM changes WHERE pushed = 0").fetchall()
    ids = {row[0] for row in pending}
    changes = [change_to_dict(c) for c in read_changes(conn) if c.id in ids]
    sent = _pushed_runs(conn) | {MANUAL_RUN}  # manual rows travel as changes, never as facts
    new_runs = tuple(sorted(set(run_keys(conn).values()) - sent))
    digest = _other_digest(conn)
    other_changed = digest != (get_meta(conn, "pushed_other") or _empty_digest())
    facts = None
    if new_runs or other_changed:
        tables = ("income", "budgets") if other_changed else ()
        facts = export_snapshot(conn, skip_runs=sent, with_tables=tables)
    if not changes and facts is None:
        return Outgoing(None)
    entry = {"format": FORMAT, "device": device_id(conn), "changes": changes, "facts": facts}
    return Outgoing(entry, tuple(sorted(ids)), new_runs, digest)


def _empty_digest() -> str:
    return hashlib.sha256(json.dumps([[], []]).encode()).hexdigest()


def mark_pushed(conn: sqlite3.Connection, sent: Outgoing) -> None:
    """Remember that an entry reached the relay."""
    with conn:
        conn.executemany(
            "UPDATE changes SET pushed = 1 WHERE id = ?", [(i,) for i in sent.change_ids]
        )
        runs = _pushed_runs(conn) | set(sent.runs)
        set_meta(conn, "pushed_runs", json.dumps(sorted(runs)))
        if sent.other_digest:
            set_meta(conn, "pushed_other", sent.other_digest)


@dataclass
class Applied:
    changes: int = 0
    merged: MergeSummary = field(default_factory=MergeSummary)

    def add(self, other: MergeSummary) -> None:
        self.merged = MergeSummary(
            **{t: getattr(self.merged, t) + getattr(other, t) for t in TABLES}
        )


def apply_entries(
    conn: sqlite3.Connection, entries: list[dict[str, Any]], now_ms: int | None = None
) -> Applied:
    """Take in entries from the log (any device's, this one's too). Idempotent, so an
    interrupted run is simply repeated."""
    applied = Applied()
    last = get_meta(conn, "clock_last")
    clock = decode_stamp(last) if last else ZERO_STAMP
    me = device_id(conn)
    now = now_ms if now_ms is not None else int(time.time() * 1000)
    for entry in entries:
        if entry.get("format") != FORMAT:
            raise ValueError("a log entry from a newer version of the app; update first")
        changes = [change_from_dict(raw) for raw in entry.get("changes") or []]
        with conn:
            applied.changes += store_changes(conn, changes, pushed=True)
        for change in changes:
            clock = clock_receive(clock, change.stamp, now, me)
        facts = entry.get("facts")
        if facts:
            applied.add(merge_snapshot(conn, facts))
            part = facts["import_runs"]
            names = part["columns"]
            keys = {
                (row[names.index("source")], row[names.index("file_sha256")],
                 row[names.index("started_at")])
                for row in part["rows"]
            }  # fmt: skip
            with conn:  # these runs are in the log already: never send them back
                runs = _pushed_runs(conn) | keys
                set_meta(conn, "pushed_runs", json.dumps(sorted(runs)))
    with conn:
        if clock != ZERO_STAMP:
            set_meta(conn, "clock_last", clock.encode())
        set_meta(conn, "settings_home", "db")
    return applied


def position(conn: sqlite3.Connection) -> int:
    """The last log sequence number this device has taken in."""
    return int(get_meta(conn, "log_seq") or 0)


def set_position(conn: sqlite3.Connection, seq: int) -> None:
    with conn:
        set_meta(conn, "log_seq", str(seq))


def full_state(conn: sqlite3.Connection) -> dict[str, Any]:
    """Everything, as one entry: for a snapshot that a new device starts from."""
    return {
        "format": FORMAT,
        "device": device_id(conn),
        "changes": [change_to_dict(c) for c in read_changes(conn)],
        "facts": export_snapshot(conn),
    }
