"""Copying one device's ledger into another's, without duplicates.

Every stored row is a fact with a natural identity: a transaction has its
tx_hash, an import run its (source, file hash, start time), a quarantined row
its full content, income and budgets their unique keys. A snapshot is all of
those rows; merging adds the ones this database does not have yet. Row ids
differ between devices, so import-run ids are translated on the way in.
Categories are derived, so the caller categorizes again afterwards.
"""

import sqlite3
from dataclasses import dataclass
from typing import Any

from fin.storage.db import schema_version

TABLES = ("import_runs", "transactions", "quarantine", "income", "budgets")


class SnapshotError(ValueError):
    """The snapshot cannot be merged into this database."""


@dataclass(frozen=True)
class MergeSummary:
    import_runs: int = 0
    transactions: int = 0
    quarantine: int = 0
    income: int = 0
    budgets: int = 0


def _columns(conn: sqlite3.Connection, table: str) -> list[str]:
    return [row[1] for row in conn.execute(f"PRAGMA table_info({table})") if row[1] != "id"]


RunKey = tuple[str, str, str]  # (source, file_sha256, started_at): an import run on any device


def run_keys(conn: sqlite3.Connection) -> dict[int, RunKey]:
    rows = conn.execute("SELECT id, source, file_sha256, started_at FROM import_runs")
    return {row[0]: (row[1], row[2], row[3]) for row in rows}


def export_snapshot(
    conn: sqlite3.Connection,
    skip_runs: set[RunKey] | frozenset[RunKey] = frozenset(),
    with_tables: tuple[str, ...] = ("income", "budgets"),
) -> dict[str, Any]:
    """Stored rows by table, with import-run ids kept as references.

    `skip_runs` leaves out import runs (and their rows) the other side already
    has; tables not in `with_tables` (income, budgets) are sent empty.
    """
    snapshot: dict[str, Any] = {"schema": schema_version(conn)}
    keep = {run_id for run_id, key in run_keys(conn).items() if key not in skip_runs}
    for table in TABLES:
        columns = _columns(conn, table)
        keep_id = table == "import_runs"
        names = (["id"] if keep_id else []) + columns
        rows = [list(row) for row in conn.execute(f"SELECT {', '.join(names)} FROM {table}")]
        if table == "import_runs":
            rows = [row for row in rows if row[0] in keep]
        elif "import_run_id" in names:
            at = names.index("import_run_id")
            rows = [row for row in rows if row[at] in keep]
        elif table not in with_tables:
            rows = []
        snapshot[table] = {"columns": names, "rows": rows}
    return snapshot


def _rows(snapshot: dict[str, Any], table: str) -> list[dict[str, Any]]:
    part = snapshot.get(table)
    if not isinstance(part, dict) or not isinstance(part.get("rows"), list):
        raise SnapshotError(f"the snapshot has no {table}")
    columns = part.get("columns")
    if not isinstance(columns, list):
        raise SnapshotError(f"the snapshot has no columns for {table}")
    return [dict(zip(columns, row, strict=True)) for row in part["rows"]]


def _insert(conn: sqlite3.Connection, table: str, row: dict[str, Any], ignore: bool) -> int:
    columns = [c for c in _columns(conn, table) if c in row]
    verb = "INSERT OR IGNORE" if ignore else "INSERT"
    cursor = conn.execute(
        f"{verb} INTO {table} ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})",
        [row[c] for c in columns],
    )
    return cursor.rowcount


def merge_snapshot(conn: sqlite3.Connection, snapshot: dict[str, Any]) -> MergeSummary:
    """Add the snapshot's rows that this database lacks, in one database transaction."""
    if snapshot.get("schema") != schema_version(conn):
        raise SnapshotError(
            "the file comes from a different version of the app; update both devices first"
        )
    counts = dict.fromkeys(TABLES, 0)
    with conn:
        run_ids: dict[int, int] = {}
        for run in _rows(snapshot, "import_runs"):
            remote_id = run.pop("id")
            found = conn.execute(
                "SELECT id FROM import_runs"
                " WHERE source = ? AND file_sha256 = ? AND started_at = ?",
                (run["source"], run["file_sha256"], run["started_at"]),
            ).fetchone()
            if found:
                run_ids[remote_id] = found[0]
            else:
                _insert(conn, "import_runs", run, ignore=False)
                run_ids[remote_id] = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                counts["import_runs"] += 1

        def local_run(row: dict[str, Any]) -> dict[str, Any]:
            if row["import_run_id"] not in run_ids:
                raise SnapshotError("a row points at an import run the file does not have")
            return {**row, "import_run_id": run_ids[row["import_run_id"]]}

        for tx in _rows(snapshot, "transactions"):
            counts["transactions"] += _insert(conn, "transactions", local_run(tx), ignore=True)
        for row in _rows(snapshot, "quarantine"):
            exists = conn.execute(
                "SELECT 1 FROM quarantine WHERE source = ? AND source_ref = ? AND reason = ?"
                " AND raw_json = ?",
                (row["source"], row["source_ref"], row["reason"], row["raw_json"]),
            ).fetchone()
            if not exists:
                counts["quarantine"] += _insert(conn, "quarantine", local_run(row), ignore=False)
        for table in ("income", "budgets"):
            for row in _rows(snapshot, table):
                counts[table] += _insert(conn, table, row, ignore=True)
    return MergeSummary(**counts)
