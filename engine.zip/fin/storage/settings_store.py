"""The settings as items in the change log, and their round trip to the YAML documents.

Each private YAML document (rules, budget, goals, baseline, scenarios) is split
into items, so two devices can edit different parts without conflict:
- every entry of a known list (a rule, a goal, a scenario, ...) is an item with
  an id, one field per key of the entry, and an `order` field;
- every entry of a known mapping (a budget ceiling, a declared amount) is an
  item keyed by its name, with `value` and `order`;
- every other top-level value is a `setting` item, "document.name";
- a `document` item records that the document exists at all (a missing budget
  and an empty one are not the same).
Rebuilding a document from the state gives the same data the YAML file held, so
the existing validators in fin.logic read it unchanged. YAML numbers with a
fraction are kept exactly as written ({"$float": "12.5"}): change values carry
no floats.
"""

import hashlib
import json
import secrets
import sqlite3
import time
import uuid
from collections.abc import Iterable
from typing import Any

from fin.logic import (
    ITEM,
    ZERO_STAMP,
    Change,
    ConfigError,
    State,
    clock_tick,
    decode_stamp,
    fold_changes,
    in_order,
    order_between,
)

# Document name -> (lists: key -> entity, mappings: key -> entity).
DOCUMENTS: dict[str, tuple[dict[str, str], dict[str, str]]] = {
    "rules": ({"rules": "rule"}, {}),
    "budget": ({}, {"ceilings": "budget_ceiling"}),
    "goals": ({"goals": "goal", "commitments": "commitment", "events": "event"}, {}),
    "baseline": ({"one_off": "one_off"}, {"fixed": "declared"}),
    "scenarios": ({"scenarios": "scenario"}, {}),
}
ORDER = "order"
VALUE = "value"
MISSING = object()  # a document that does not exist
_FLOAT = "$float"

Items = dict[tuple[str, str], dict[str, Any]]


# ---- values


def encode(value: Any) -> Any:
    """A YAML value as plain change data: floats keep their exact written form."""
    if isinstance(value, float):
        return {_FLOAT: repr(value)}
    if isinstance(value, list):
        return [encode(item) for item in value]
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    if value is None or isinstance(value, bool | int | str):
        return value
    return str(value)  # dates and the like, as YAML would print them


def decode(value: Any) -> Any:
    if isinstance(value, list):
        return [decode(item) for item in value]
    if isinstance(value, dict):
        if set(value) == {_FLOAT}:
            return float(value[_FLOAT])
        return {k: decode(v) for k, v in value.items()}
    return value


# ---- documents <-> items


def _entity_of(document: str) -> set[str]:
    lists, maps = DOCUMENTS[document]
    return set(lists.values()) | set(maps.values())


def _item_id(document: str, key: str, entry: Any, seen: dict[str, int]) -> str:
    digest = hashlib.sha256(
        json.dumps([document, key, encode(entry)], sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()[:12]
    seen[digest] = seen.get(digest, 0) + 1
    return digest if seen[digest] == 1 else f"{digest}.{seen[digest]}"


def _orders(count: int) -> list[str]:
    keys: list[str] = []
    for _ in range(count):
        keys.append(order_between(keys[-1] if keys else None, None))
    return keys


def items_of(document: str, raw: Any) -> Items:
    """The items a document is made of. MISSING gives none; anything else marks it present."""
    if raw is MISSING:
        return {}
    items: Items = {("document", document): {"present": True}}
    if raw is None:
        return items
    if not isinstance(raw, dict):
        raise ConfigError(f"{document}: the document must be a mapping")
    lists, maps = DOCUMENTS[document]
    for key, value in raw.items():
        key = str(key)
        # Empty or odd-shaped lists and mappings stay whole, as a setting, so the
        # validators see exactly what the file held.
        if (
            key in lists
            and value
            and isinstance(value, list)
            and all(isinstance(e, dict) for e in value)
        ):
            seen: dict[str, int] = {}
            for entry, order in zip(value, _orders(len(value)), strict=True):
                item_id = _item_id(document, key, entry, seen)
                fields = {str(k): encode(v) for k, v in entry.items() if v is not None}
                items[(lists[key], item_id)] = {**fields, ORDER: order}
        elif key in maps and value and isinstance(value, dict):
            for (name, amount), order in zip(value.items(), _orders(len(value)), strict=True):
                items[(maps[key], str(name))] = {VALUE: encode(amount), ORDER: order}
        else:
            items[("setting", f"{document}.{key}")] = {VALUE: encode(value)}
    return items


def document_from(state: State, document: str) -> Any:
    """The document rebuilt from the state, or MISSING when it does not exist."""
    if document not in state.get("document", {}):
        return MISSING
    lists, maps = DOCUMENTS[document]
    raw: dict[str, Any] = {}
    prefix = f"{document}."
    for key, fields in state.get("setting", {}).items():
        if key.startswith(prefix) and VALUE in fields:
            raw[key.removeprefix(prefix)] = decode(fields[VALUE])
    for key, entity in lists.items():
        found = state.get(entity, {})
        if found:
            orders = {item_id: str(fields.get(ORDER, "")) for item_id, fields in found.items()}
            raw[key] = [
                {k: decode(v) for k, v in found[item_id].items() if k != ORDER and v is not None}
                for item_id in in_order(orders)
            ]
    for key, entity in maps.items():
        found = state.get(entity, {})
        if found:
            orders = {name: str(fields.get(ORDER, "")) for name, fields in found.items()}
            raw[key] = {
                name: decode(found[name].get(VALUE))
                for name in in_order(orders)
                if found[name].get(VALUE) is not None
            }
    return raw or None


# ---- the local log


def get_meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return None if row is None else row[0]


def set_meta(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO meta (key, value) VALUES (?, ?)"
        " ON CONFLICT (key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def device_id(conn: sqlite3.Connection) -> str:
    """This database's device id, made once: 'd' and 8 hex digits."""
    found = get_meta(conn, "device_id")
    if found is None:
        found = "d" + secrets.token_hex(4)
        set_meta(conn, "device_id", found)
    return found


def read_changes(conn: sqlite3.Connection) -> list[Change]:
    rows = conn.execute(
        "SELECT id, stamp, entity, item_key, field, value_json, deleted FROM changes"
    ).fetchall()
    return [
        Change(
            row[0],
            decode_stamp(row[1]),
            row[2],
            row[3],
            row[4],
            None if row[5] is None else json.loads(row[5]),
            bool(row[6]),
        )
        for row in rows
    ]


def state(conn: sqlite3.Connection) -> State:
    return fold_changes(read_changes(conn))


def settings_in_db(conn: sqlite3.Connection) -> bool:
    """True once the settings live in the change log rather than in the YAML files."""
    return get_meta(conn, "settings_home") == "db"


def store_changes(conn: sqlite3.Connection, changes: Iterable[Change], pushed: bool) -> int:
    """Add changes (this device's or received ones); a change already stored is skipped."""
    added = 0
    for change in changes:
        cursor = conn.execute(
            "INSERT OR IGNORE INTO changes"
            " (id, stamp, entity, item_key, field, value_json, deleted, pushed)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                change.id,
                change.stamp.encode(),
                change.entity,
                change.key,
                change.field,
                None if change.value is None else json.dumps(change.value, ensure_ascii=False),
                int(change.deleted),
                int(pushed),
            ),
        )
        added += cursor.rowcount
    return added


class Editor:
    """Makes this device's changes, each with a new clock stamp."""

    def __init__(self, conn: sqlite3.Connection, now_ms: int | None = None) -> None:
        self.conn = conn
        self.device = device_id(conn)
        last = get_meta(conn, "clock_last")
        self.last = decode_stamp(last) if last else ZERO_STAMP
        self.now_ms = now_ms
        self.made: list[Change] = []

    def _stamp(self):  # noqa: ANN202 - Stamp
        now = self.now_ms if self.now_ms is not None else int(time.time() * 1000)
        self.last = clock_tick(self.last, now, self.device)
        return self.last

    def set(self, entity: str, key: str, name: str, value: Any) -> None:
        self.made.append(Change(uuid.uuid4().hex, self._stamp(), entity, key, name, value))

    def delete(self, entity: str, key: str) -> None:
        self.made.append(Change(uuid.uuid4().hex, self._stamp(), entity, key, ITEM, deleted=True))

    def save(self) -> int:
        if not self.made:
            return 0
        store_changes(self.conn, self.made, pushed=False)
        set_meta(self.conn, "clock_last", self.last.encode())
        count, self.made = len(self.made), []
        return count


def import_documents(
    conn: sqlite3.Connection, documents: dict[str, Any], now_ms: int | None = None
) -> int:
    """Make the state hold these documents: only the differences become changes.

    Afterwards the settings are read from the change log. Returns the number of
    changes made; importing the same documents again makes none.
    """
    current = state(conn)
    editor = Editor(conn, now_ms)
    for document, raw in documents.items():
        if document not in DOCUMENTS:
            raise ConfigError(f"unknown settings document {document!r}")
        wanted = items_of(document, raw)
        have: Items = {
            (entity, key): fields
            for entity, found in current.items()
            for key, fields in found.items()
            if _belongs(document, entity, key)
        }
        for (entity, key), fields in wanted.items():
            old = have.get((entity, key), {})
            for name, value in fields.items():
                if old.get(name) != value:
                    editor.set(entity, key, name, value)
            for name in old.keys() - fields.keys():
                if old[name] is not None:
                    editor.set(entity, key, name, None)
        for entity, key in have.keys() - wanted.keys():
            editor.delete(entity, key)
    with conn:
        made = editor.save()
        set_meta(conn, "settings_home", "db")
    return made


def _belongs(document: str, entity: str, key: str) -> bool:
    if entity == "document":
        return key == document
    if entity == "setting":
        return key.startswith(f"{document}.")
    return entity in _entity_of(document)


def export_documents(conn: sqlite3.Connection) -> dict[str, Any]:
    """Every document rebuilt from the change log (MISSING for those that do not exist)."""
    current = state(conn)
    return {document: document_from(current, document) for document in DOCUMENTS}
