"""What the screens ask of storage, one call per need.

Each function opens the database, does its work and closes it again, so a
screen never holds a connection or writes SQL. Raises ConfigError for a bad
configuration, with the same messages the commands always printed.
"""

import sqlite3
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

import yaml

import fin.storage.account_log as account_log
from fin.logic import (
    LAYER_NONE,
    MANUAL_SOURCE,
    Baseline,
    BaselineConfig,
    BudgetConfig,
    ConfigError,
    GoalsConfig,
    IncomeReference,
    MonthSummary,
    PeriodSummary,
    Scenario,
    baseline_window,
    build_baseline,
    effective_ceilings,
    fold_changes,
)
from fin.storage.account_log import Applied, Outgoing
from fin.storage.analytics.actual import (
    ACTUAL,
    actual_summaries,
    latest_actual_date,
    latest_actual_month,
    latest_bank_balance,
)
from fin.storage.analytics.ledger import (
    LedgerEntry,
    category_spend,
    ledger_entries,
    ledger_entries_between,
    upcoming_card_charges,
)
from fin.storage.analytics.monthly import monthly_summaries, recent_income
from fin.storage.categorize_apply import LEGACY_SOURCE, CategorizeSummary, categorize_all
from fin.storage.config_files import load_taxonomy, save_budget_config
from fin.storage.configs import (
    FILE_NAMES,
    Configs,
    budget_document,
    document_paths,
    load_configs,
    read_files,
)
from fin.storage.db import connect, migrate
from fin.storage.edits import (
    EditError,
    apply_overrides,
    find_transaction,
    merchant_counts,
    notes,
    plan_edit,
    write_manual,
)
from fin.storage.imports import FileImport, SourceStatus, import_status, import_upload
from fin.storage.ingest.adapter import ControlTotalError
from fin.storage.ingest.legacy_config import load_legacy_config
from fin.storage.ingest.legacy_excel import parse_workbook
from fin.storage.ingest.pipeline import import_file
from fin.storage.ingest.registry import build_adapters, find_adapter
from fin.storage.ingest.store import ImportSummary, file_sha256, store_legacy_import
from fin.storage.merge import MergeSummary, export_snapshot, merge_snapshot
from fin.storage.settings import Settings
from fin.storage.settings_store import (
    DOCUMENTS,
    MISSING,
    Editor,
    document_from,
    export_documents,
    import_documents,
    read_changes,
    settings_in_db,
    state,
)


def _open(settings: Settings) -> sqlite3.Connection:
    conn = connect(settings.db_path)
    migrate(conn)
    return conn


def _categorize(conn: sqlite3.Connection, settings: Settings) -> CategorizeSummary:
    """Apply the generic and personal rules to all bank and card transactions."""
    taxonomy = load_taxonomy()
    private_rules = load_configs(conn, settings).private_rules(taxonomy)
    current = state(conn) if settings_in_db(conn) else {}
    write_manual(conn, current, taxonomy)
    summary = categorize_all(conn, taxonomy, private_rules)
    apply_overrides(conn, current, taxonomy)
    return summary


def categorize(settings: Settings) -> tuple[CategorizeSummary, list[tuple[str, str, int]]]:
    """Categorize everything; also return the uncovered merchants, most frequent first."""
    conn = _open(settings)
    try:
        summary = _categorize(conn, settings)
        uncovered = conn.execute(
            "SELECT source, description, COUNT(*) FROM transactions WHERE category_rule = ?"
            " GROUP BY source, description ORDER BY COUNT(*) DESC, description",
            (LAYER_NONE,),
        ).fetchall()
    finally:
        conn.close()
    return summary, [tuple(row) for row in uncovered]


@dataclass
class InboxResult:
    # source -> [files, rows seen, inserted, duplicate, quarantined, skipped (not charged)]
    totals: dict[str, list[int]] = field(default_factory=dict)
    unrecognized: int = 0
    rejected: int = 0
    categorized: CategorizeSummary = field(default_factory=CategorizeSummary)


def import_inbox(settings: Settings) -> InboxResult:
    """Import every recognized bank or card export in the inbox, then categorize."""
    adapters = build_adapters()
    if not settings.inbox_dir.is_dir():
        raise ConfigError(f"inbox folder not found: {settings.inbox_dir}")
    files = sorted(
        path
        for path in settings.inbox_dir.iterdir()
        if path.is_file() and not path.name.startswith((".", "~$"))
    )
    result = InboxResult()
    conn = _open(settings)
    try:
        for path in files:
            adapter = find_adapter(path, adapters)
            if adapter is None:
                result.unrecognized += 1
                continue
            try:
                summary = import_file(conn, adapter, path)
            except ControlTotalError:
                result.rejected += 1
                continue
            counts = result.totals.setdefault(adapter.source, [0, 0, 0, 0, 0, 0])
            for index, value in enumerate(
                (
                    1,
                    summary.rows_seen,
                    summary.rows_inserted,
                    summary.rows_duplicate,
                    summary.rows_quarantined,
                    summary.skipped_no_charge,
                )
            ):
                counts[index] += value
        result.categorized = _categorize(conn, settings)
    finally:
        conn.close()
    return result


def import_legacy(settings: Settings, file_path: Path | None) -> ImportSummary:
    """Import the legacy budget workbook."""
    legacy_cfg = load_legacy_config()
    workbook_path = file_path or settings.legacy_excel_path
    if not workbook_path.is_file():
        raise FileNotFoundError(workbook_path)
    result = parse_workbook(workbook_path, legacy_cfg)
    conn = _open(settings)
    try:
        return store_legacy_import(conn, result, legacy_cfg.source, file_sha256(workbook_path))
    finally:
        conn.close()


def _ceilings_lookup(
    conn: sqlite3.Connection, settings: Settings
) -> Callable[[str], dict[str, int]] | None:
    """Per-month ceilings from the saved budget, or None when no budget is saved."""
    configs = load_configs(conn, settings)
    saved = configs.budget()
    if saved is None:
        return None
    fixed = configs.baseline().fixed
    commitments = configs.goals().commitments

    def lookup(month: str) -> dict[str, int]:
        if month < saved.start_month:
            return {}
        return effective_ceilings(saved.ceilings, fixed, commitments, month)

    return lookup


def report_data(
    settings: Settings, start: str | None, end: str | None, source: str
) -> tuple[PeriodSummary, IncomeReference | None]:
    """The monthly summaries of one ledger; the actual ledger is categorized first."""
    conn = _open(settings)
    try:
        if source == ACTUAL:
            _categorize(conn, settings)  # rule edits take effect immediately
            ceilings = _ceilings_lookup(conn, settings)
            return actual_summaries(conn, start, end, ceilings), None
        return monthly_summaries(conn, start, end, source), recent_income(conn)
    finally:
        conn.close()


def _current_baseline(
    conn: sqlite3.Connection, settings: Settings, config: BaselineConfig, months: int
) -> tuple[Baseline | None, tuple[MonthSummary, ...]]:
    """Categorize, then build the baseline and return it with its window months."""
    _categorize(conn, settings)  # rule edits take effect immediately
    last_month = latest_actual_month(conn)
    window = (
        baseline_window(actual_summaries(conn).months, last_month, months) if last_month else ()
    )
    return build_baseline(window, config), window


def load_baseline(settings: Settings, months: int) -> Baseline | None:
    """The current-state baseline over the latest `months` full months."""
    conn = _open(settings)
    try:
        config = load_configs(conn, settings).baseline()
        baseline, _ = _current_baseline(conn, settings, config, months)
    finally:
        conn.close()
    return baseline


@dataclass(frozen=True)
class Plan:
    """Everything the planning commands read: the baseline, the balance and the configs."""

    baseline: Baseline | None
    window: tuple[MonthSummary, ...]
    balance: tuple[str, int] | None
    data_month: str | None
    goals: GoalsConfig
    scenarios: tuple[Scenario, ...]
    settings: Settings
    baseline_config: BaselineConfig
    data_date: str | None = None
    # Spending so far in the newest data month.
    current_month: MonthSummary | None = None

    @property
    def ready(self) -> bool:
        return None not in (self.baseline, self.balance, self.data_month)


def load_plan(settings: Settings, months: int) -> Plan:
    """Load the configs and compute the baseline."""
    conn = _open(settings)
    try:
        configs = load_configs(conn, settings)
        baseline_config = configs.baseline()
        goals_config = configs.goals()
        scenarios = configs.scenarios()
        baseline, window = _current_baseline(conn, settings, baseline_config, months)
        data_month = latest_actual_month(conn)
        current = actual_summaries(conn, data_month, data_month).months if data_month else ()
        return Plan(
            baseline,
            window,
            latest_bank_balance(conn),
            data_month,
            goals_config,
            scenarios,
            settings,
            baseline_config,
            latest_actual_date(conn),
            current[0] if current else None,
        )
    finally:
        conn.close()


def ledger(settings: Settings, first_month: str, last_month: str) -> tuple[LedgerEntry, ...]:
    """Transactions of the actual ledger in a range of months, newest first."""
    conn = _open(settings)
    try:
        return ledger_entries(conn, first_month, last_month)
    finally:
        conn.close()


def ledger_between(settings: Settings, first_day: str, last_day: str) -> tuple[LedgerEntry, ...]:
    """Transactions of the actual ledger dated in a range of days, newest first."""
    conn = _open(settings)
    try:
        return ledger_entries_between(conn, first_day, last_day)
    finally:
        conn.close()


def spend_by_category(settings: Settings, month: str) -> tuple[tuple[str, str, int], ...]:
    """Net spending per (bucket, category) in one month."""
    conn = _open(settings)
    try:
        return category_spend(conn, month)
    finally:
        conn.close()


def upcoming_charges(settings: Settings, after_month: str) -> tuple[tuple[str, str, str, int], ...]:
    """Card charges already known for later months (installments)."""
    conn = _open(settings)
    try:
        return upcoming_card_charges(conn, after_month)
    finally:
        conn.close()


def import_one_file(settings: Settings, name: str, data: bytes) -> FileImport:
    """Import one uploaded export (see fin.storage.imports). Raises ValueError for a bad upload."""
    return import_upload(settings, name, data, _categorize)


def sources_status(settings: Settings) -> tuple[SourceStatus, ...]:
    """The three sources with their import history, for the accounts and imports sheet."""
    conn = _open(settings)
    try:
        sources = tuple(adapter.source for adapter in build_adapters())
        return import_status(conn, sources)
    finally:
        conn.close()


def ledger_snapshot(settings: Settings) -> dict:
    """Every stored row, for sending to another device (see fin.storage.merge)."""
    conn = _open(settings)
    try:
        return export_snapshot(conn)
    finally:
        conn.close()


def merge_ledger(settings: Settings, snapshot: dict) -> MergeSummary:
    """Add another device's rows that are missing here, then categorize everything again."""
    conn = _open(settings)
    try:
        summary = merge_snapshot(conn, snapshot)
        _categorize(conn, settings)
        return summary
    finally:
        conn.close()


# The private configs a device can receive, by file name.
PRIVATE_CONFIGS = tuple(FILE_NAMES.values())
_DOCUMENT_OF = {file_name: name for name, file_name in FILE_NAMES.items()}


def _config_paths(settings: Settings) -> dict[str, Path]:
    return {FILE_NAMES[name]: path for name, path in document_paths(settings).items()}


def private_configs(settings: Settings) -> dict[str, str]:
    """The private configs this device has, as YAML text, by standard file name."""
    conn = _open(settings)
    try:
        if settings_in_db(conn):
            return {
                FILE_NAMES[name]: yaml.safe_dump(raw, allow_unicode=True, sort_keys=False)
                for name, raw in export_documents(conn).items()
                if raw is not MISSING
            }
    finally:
        conn.close()
    return {
        name: path.read_text(encoding="utf-8")
        for name, path in _config_paths(settings).items()
        if path.is_file()
    }


def write_private_configs(settings: Settings, configs: dict[str, str]) -> list[str]:
    """Replace this device's private configs with the given ones. Raises ConfigError if unreadable.

    Every file is checked before any is written, so a bad file changes nothing.
    """
    paths = _config_paths(settings)
    unknown = sorted(set(configs) - set(paths))
    if unknown:
        raise ConfigError(f"unknown config file: {', '.join(unknown)}")
    parsed = {}
    for name, text in configs.items():
        try:
            parsed[name] = yaml.safe_load(text)
        except yaml.YAMLError as exc:
            raise ConfigError(f"invalid YAML in {name}") from exc
    conn = _open(settings)
    try:
        if settings_in_db(conn):
            import_documents(conn, {_DOCUMENT_OF[name]: raw for name, raw in parsed.items()})
            return sorted(configs)
    finally:
        conn.close()
    for name, text in configs.items():
        paths[name].parent.mkdir(parents=True, exist_ok=True)
        paths[name].write_text(text, encoding="utf-8")
    return sorted(configs)


def saved_budget(settings: Settings) -> BudgetConfig | None:
    """The saved monthly budget, or None when none was saved."""
    conn = _open(settings)
    try:
        return load_configs(conn, settings).budget()
    finally:
        conn.close()


def save_budget(settings: Settings, config: BudgetConfig) -> None:
    """Save the monthly budget where the settings live (the change log or the YAML file)."""
    conn = _open(settings)
    try:
        if settings_in_db(conn):
            import_documents(conn, {"budget": budget_document(config)})
            return
    finally:
        conn.close()
    save_budget_config(settings.budget_path, config)


def settings_documents(settings: Settings) -> dict[str, object]:
    """Every private settings document as it stands now (None where it does not exist)."""
    conn = _open(settings)
    try:
        if settings_in_db(conn):
            documents = export_documents(conn)
        else:
            documents = read_files(settings)
    finally:
        conn.close()
    return {name: None if raw is MISSING else raw for name, raw in documents.items()}


def import_settings(settings: Settings) -> int:
    """Take the private YAML files into the change log; from then on settings are read there.

    Only differences become changes, so running it again after editing a file
    records just the edits. A file that does not exist removes that document.
    """
    documents = read_files(settings)
    paths = document_paths(settings)
    check = Configs(documents, {name: str(path) for name, path in paths.items()})
    check.private_rules(load_taxonomy())  # every file must be valid before anything is written
    check.baseline()
    check.goals()
    check.budget()
    check.scenarios()
    conn = _open(settings)
    try:
        return import_documents(conn, documents)
    finally:
        conn.close()


# ---- the account's shared log (the sync box encrypts and moves the entries)


def log_outgoing(settings: Settings) -> Outgoing:
    """This device's new changes and facts as one log entry (entry None: nothing to send)."""
    conn = _open(settings)
    try:
        return account_log.outgoing(conn)
    finally:
        conn.close()


def log_mark_pushed(settings: Settings, sent: Outgoing) -> None:
    conn = _open(settings)
    try:
        account_log.mark_pushed(conn, sent)
    finally:
        conn.close()


def log_apply(settings: Settings, entries: list[dict], seq: int | None = None) -> Applied:
    """Take in log entries, then categorize again (rules may have changed).

    `seq` is the log position the entries reach; it is saved after they are in.
    """
    conn = _open(settings)
    try:
        applied = account_log.apply_entries(conn, entries)
        if entries:
            _categorize(conn, settings)
        if seq is not None:
            account_log.set_position(conn, seq)
        return applied
    finally:
        conn.close()


def log_position(settings: Settings) -> int:
    conn = _open(settings)
    try:
        return account_log.position(conn)
    finally:
        conn.close()


def log_full_state(settings: Settings) -> dict:
    """Everything this device holds, as one entry (for the account's snapshot)."""
    conn = _open(settings)
    try:
        return account_log.full_state(conn)
    finally:
        conn.close()


# ---- edits made in the app


def edit(settings: Settings, request: dict) -> dict:
    """Apply one edit from the app: a ceiling, a rule, a goal, a category, a manual transaction.

    The settings that would result are checked with the same validators as the
    YAML files before anything is saved; a bad edit raises EditError and changes
    nothing. Returns the id of what was edited and how many changes it made.
    """
    conn = _open(settings)
    try:
        if not settings_in_db(conn):
            raise EditError("the settings still live in the YAML files: set up the account first")
        taxonomy = load_taxonomy()
        editor = Editor(conn)
        result = plan_edit(editor, state(conn), request, taxonomy)
        candidate = fold_changes([*read_changes(conn), *editor.made])
        documents = {name: document_from(candidate, name) for name in DOCUMENTS}
        check = Configs(documents, {name: f"settings ({name})" for name in documents})
        try:
            check.private_rules(taxonomy)
            check.baseline()
            check.goals()
            check.budget()
            check.scenarios()
        except ConfigError as exc:
            raise EditError(str(exc)) from exc
        with conn:
            made = editor.save()
        _categorize(conn, settings)
        return {**result, "changes": made}
    finally:
        conn.close()


def transaction_details(settings: Settings, tx_hash: str) -> dict | None:
    """One transaction for its sheet: the row, the merchant counts and the categories.

    None when there is no such transaction (legacy workbook rows are not editable).
    """
    conn = _open(settings)
    try:
        row = find_transaction(conn, tx_hash)
        if row is None:
            return None
        merchant, exact = merchant_counts(conn, row)
        in_db = settings_in_db(conn)
        current = state(conn) if in_db else {}
    finally:
        conn.close()
    taxonomy = load_taxonomy()
    manual = row["source"] == MANUAL_SOURCE
    return {
        "tx_hash": row["tx_hash"],
        "name": row["description"],
        "amount": row["my_share_agorot"],
        "date": row["tx_date"],
        "source": row["source"],
        "category": row["category"],
        "bucket": row["bucket"],
        "kind": row["flow_kind"],
        "manual": manual,
        "manual_id": row["source_ref"] if manual else None,
        "overridden": tx_hash in current.get("category_override", {}),
        "note": notes(current).get(tx_hash, ""),
        "editable": in_db,
        "merchant_count": merchant,
        "merchant_amount_count": exact,
        "categories": [
            (name, spec.bucket, spec.kind) for name, spec in taxonomy.categories.items()
        ],
    }


def transaction_notes(settings: Settings) -> dict[str, str]:
    """Every note on a transaction, by tx_hash (none until the settings are in the change log)."""
    conn = _open(settings)
    try:
        return notes(state(conn)) if settings_in_db(conn) else {}
    finally:
        conn.close()


def actual_month(settings: Settings, month: str) -> MonthSummary | None:
    """One month of the actual ledger (bank and cards), or None when it has no data."""
    conn = _open(settings)
    try:
        months = actual_summaries(conn, month, month).months
    finally:
        conn.close()
    return months[0] if months else None


def actual_months(settings: Settings) -> tuple[str, ...]:
    """Every month with bank or card data, oldest first (the legacy workbook left out)."""
    conn = _open(settings)
    try:
        rows = conn.execute(
            "SELECT DISTINCT budget_month FROM transactions WHERE source != ?"
            " ORDER BY budget_month",
            (LEGACY_SOURCE,),
        ).fetchall()
    finally:
        conn.close()
    return tuple(row[0] for row in rows)
