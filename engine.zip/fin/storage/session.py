"""What the screens ask of storage, one call per need.

Each function opens the database, does its work and closes it again, so a
screen never holds a connection or writes SQL. Raises ConfigError for a bad
configuration, with the same messages the commands always printed.
"""

import sqlite3
from collections.abc import Callable
from dataclasses import dataclass, field, replace
from pathlib import Path

import yaml

import fin.storage.account_log as account_log
from fin.logic import (
    LAYER_NONE,
    MANUAL_SOURCE,
    BalancePoint,
    Baseline,
    BaselineConfig,
    BudgetConfig,
    Charge,
    ConfigError,
    GoalsConfig,
    Holding,
    IncomeReference,
    MonthSummary,
    MonthWorth,
    PeriodSummary,
    RenameRule,
    Scenario,
    Taxonomy,
    add_months,
    apply_overlay,
    baseline_window,
    build_baseline,
    effective_ceilings,
    fold_changes,
    is_installment,
    net_worth_series,
)
from fin.storage.account_log import Applied, Outgoing
from fin.storage.analytics.actual import (
    ACTUAL,
    actual_summaries,
    bank_balances_by_month,
    latest_actual_date,
    latest_actual_month,
    latest_bank_balance,
)
from fin.storage.analytics.ledger import (
    LedgerEntry,
    category_spend,
    ledger_entries,
    ledger_entries_between,
    month_charges,
    upcoming_card_charges,
)
from fin.storage.analytics.monthly import monthly_summaries, recent_income
from fin.storage.categorize_apply import (
    LEGACY_SOURCE,
    CategorizeSummary,
    apply_to_legacy,
    categorize_all,
)
from fin.storage.config_files import load_taxonomy, save_budget_config
from fin.storage.configs import (
    FILE_NAMES,
    Configs,
    budget_document,
    document_paths,
    load_configs,
    read_files,
)
from fin.storage.db import connect, migrate, recount_installments
from fin.storage.edits import (
    EditError,
    apply_overrides,
    category_labels,
    category_order,
    expense_groups,
    find_transaction,
    group_labels,
    hidden_charges,
    holdings,
    item_ids,
    manual_plan,
    merchant_counts,
    notes,
    own_titles,
    plan_edit,
    profile_name,
    rename_rules,
    source_maps,
    write_manual,
)
from fin.storage.imports import (
    FileImport,
    SourceStatus,
    check_upload,
    import_saved,
    import_status,
    import_upload,
)
from fin.storage.ingest.adapter import ControlTotalError
from fin.storage.ingest.legacy_config import load_legacy_config
from fin.storage.ingest.legacy_excel import parse_workbook
from fin.storage.ingest.mapped import MappedAdapter
from fin.storage.ingest.pipeline import import_file
from fin.storage.ingest.registry import build_adapters, find_adapter
from fin.storage.ingest.store import ImportSummary, file_sha256, store_legacy_import
from fin.storage.merge import MergeSummary, export_snapshot, merge_snapshot
from fin.storage.settings import Settings
from fin.storage.settings_store import (
    DOCUMENTS,
    MISSING,
    Editor,
    document_from,
    export_documents,
    import_documents,
    read_changes,
    settings_in_db,
    state,
)


def _open(settings: Settings) -> sqlite3.Connection:
    conn = connect(settings.db_path)
    migrate(conn)
    return conn


def _mapped(current: dict) -> tuple[MappedAdapter, ...]:
    """The adapters of the sources the user mapped by hand (kept in the change log)."""
    return tuple(MappedAdapter(m) for m in source_maps(current))


def _effective(current: dict) -> Taxonomy:
    """The built-in taxonomy with the user's category changes on top (the editor)."""
    return apply_overlay(load_taxonomy(), current.get("category_label", {}))


def _categorize(conn: sqlite3.Connection, settings: Settings) -> CategorizeSummary:
    """Apply the generic and personal rules to all bank and card transactions."""
    recount_installments(conn)  # rows just imported or merged get their counting day
    current = state(conn) if settings_in_db(conn) else {}
    taxonomy = _effective(current)
    private_rules = load_configs(conn, settings).private_rules(taxonomy)
    write_manual(conn, current, taxonomy)
    maps = source_maps(current)
    # A mapped card's monthly payment in the bank is named by the user; without a billing
    # date column its rows count by transaction date, so that payment is fully detailed.
    labels = {m.bank_label: m.source for m in maps if m.kind == "card" and m.bank_label}
    if labels:
        taxonomy = replace(taxonomy, card_payment_labels={**taxonomy.card_payment_labels, **labels})
    by_date = frozenset(m.source for m in maps if m.kind == "card" and not m.billing)
    summary = categorize_all(conn, taxonomy, private_rules, by_date)
    apply_to_legacy(conn, taxonomy)
    apply_overrides(conn, current, taxonomy)
    return summary


def categorize(settings: Settings) -> tuple[CategorizeSummary, list[tuple[str, str, int]]]:
    """Categorize everything; also return the uncovered merchants, most frequent first."""
    conn = _open(settings)
    try:
        summary = _categorize(conn, settings)
        uncovered = conn.execute(
            "SELECT source, description, COUNT(*) FROM transactions WHERE category_rule = ?"
            " GROUP BY source, description ORDER BY COUNT(*) DESC, description",
            (LAYER_NONE,),
        ).fetchall()
    finally:
        conn.close()
    return summary, [tuple(row) for row in uncovered]


@dataclass
class InboxResult:
    # source -> [files, rows seen, inserted, duplicate, quarantined, skipped (not charged)]
    totals: dict[str, list[int]] = field(default_factory=dict)
    unrecognized: int = 0
    rejected: int = 0
    categorized: CategorizeSummary = field(default_factory=CategorizeSummary)


def import_inbox(settings: Settings) -> InboxResult:
    """Import every recognized bank or card export in the inbox, then categorize."""
    if not settings.inbox_dir.is_dir():
        raise ConfigError(f"inbox folder not found: {settings.inbox_dir}")
    files = sorted(
        path
        for path in settings.inbox_dir.iterdir()
        if path.is_file() and not path.name.startswith((".", "~$"))
    )
    result = InboxResult()
    conn = _open(settings)
    try:
        adapters = (*build_adapters(), *_mapped(state(conn) if settings_in_db(conn) else {}))
        for path in files:
            adapter = find_adapter(path, adapters)
            if adapter is None:
                result.unrecognized += 1
                continue
            try:
                summary = import_file(conn, adapter, path)
            except ControlTotalError:
                result.rejected += 1
                continue
            counts = result.totals.setdefault(adapter.source, [0, 0, 0, 0, 0, 0])
            for index, value in enumerate(
                (
                    1,
                    summary.rows_seen,
                    summary.rows_inserted,
                    summary.rows_duplicate,
                    summary.rows_quarantined,
                    summary.skipped_no_charge,
                )
            ):
                counts[index] += value
        result.categorized = _categorize(conn, settings)
    finally:
        conn.close()
    return result


def import_legacy(settings: Settings, file_path: Path | None) -> ImportSummary:
    """Import the legacy budget workbook."""
    legacy_cfg = load_legacy_config()
    workbook_path = file_path or settings.legacy_excel_path
    if not workbook_path.is_file():
        raise FileNotFoundError(workbook_path)
    result = parse_workbook(workbook_path, legacy_cfg)
    conn = _open(settings)
    try:
        return store_legacy_import(conn, result, legacy_cfg.source, file_sha256(workbook_path))
    finally:
        conn.close()


def _ceilings_lookup(
    conn: sqlite3.Connection, settings: Settings
) -> Callable[[str], dict[str, int]] | None:
    """Per-month ceilings from the saved budget, or None when no budget is saved."""
    configs = load_configs(conn, settings)
    saved = configs.budget()
    if saved is None:
        return None
    fixed = configs.baseline().fixed
    commitments = configs.goals().commitments

    def lookup(month: str) -> dict[str, int]:
        if month < saved.start_month:
            return {}
        return effective_ceilings(saved.ceilings, fixed, commitments, month)

    return lookup


def report_data(
    settings: Settings, start: str | None, end: str | None, source: str
) -> tuple[PeriodSummary, IncomeReference | None]:
    """The monthly summaries of one ledger; the actual ledger is categorized first."""
    conn = _open(settings)
    try:
        if source == ACTUAL:
            _categorize(conn, settings)  # rule edits take effect immediately
            ceilings = _ceilings_lookup(conn, settings)
            return actual_summaries(conn, start, end, ceilings), None
        return monthly_summaries(conn, start, end, source), recent_income(conn)
    finally:
        conn.close()


def _current_baseline(
    conn: sqlite3.Connection, settings: Settings, config: BaselineConfig, months: int
) -> tuple[Baseline | None, tuple[MonthSummary, ...]]:
    """Categorize, then build the baseline and return it with its window months."""
    _categorize(conn, settings)  # rule edits take effect immediately
    last_month = latest_actual_month(conn)
    window = (
        baseline_window(actual_summaries(conn).months, last_month, months) if last_month else ()
    )
    return build_baseline(window, config), window


def load_baseline(settings: Settings, months: int) -> Baseline | None:
    """The current-state baseline over the latest `months` full months."""
    conn = _open(settings)
    try:
        config = load_configs(conn, settings).baseline()
        baseline, _ = _current_baseline(conn, settings, config, months)
    finally:
        conn.close()
    return baseline


@dataclass(frozen=True)
class Plan:
    """Everything the planning commands read: the baseline, the balance and the configs."""

    baseline: Baseline | None
    window: tuple[MonthSummary, ...]
    balance: tuple[str, int] | None
    data_month: str | None
    goals: GoalsConfig
    scenarios: tuple[Scenario, ...]
    settings: Settings
    baseline_config: BaselineConfig
    data_date: str | None = None
    # Spending so far in the newest data month.
    current_month: MonthSummary | None = None

    @property
    def ready(self) -> bool:
        return None not in (self.baseline, self.balance, self.data_month)


def load_plan(settings: Settings, months: int) -> Plan:
    """Load the configs and compute the baseline."""
    conn = _open(settings)
    try:
        configs = load_configs(conn, settings)
        baseline_config = configs.baseline()
        goals_config = configs.goals()
        scenarios = configs.scenarios()
        baseline, window = _current_baseline(conn, settings, baseline_config, months)
        data_month = latest_actual_month(conn)
        current = actual_summaries(conn, data_month, data_month).months if data_month else ()
        return Plan(
            baseline,
            window,
            latest_bank_balance(conn),
            data_month,
            goals_config,
            scenarios,
            settings,
            baseline_config,
            latest_actual_date(conn),
            current[0] if current else None,
        )
    finally:
        conn.close()


def ledger(settings: Settings, first_month: str, last_month: str) -> tuple[LedgerEntry, ...]:
    """Transactions of the actual ledger in a range of months, newest first."""
    conn = _open(settings)
    try:
        return ledger_entries(conn, first_month, last_month)
    finally:
        conn.close()


def ledger_between(settings: Settings, first_day: str, last_day: str) -> tuple[LedgerEntry, ...]:
    """Transactions of the actual ledger dated in a range of days, newest first."""
    conn = _open(settings)
    try:
        return ledger_entries_between(conn, first_day, last_day)
    finally:
        conn.close()


def spend_by_category(settings: Settings, month: str) -> tuple[tuple[str, str, int], ...]:
    """Net spending per (bucket, category) in one month."""
    conn = _open(settings)
    try:
        return category_spend(conn, month)
    finally:
        conn.close()


def charges_in_month(settings: Settings, month: str) -> tuple[Charge, ...]:
    """The month's expense rows, with the card installments marked."""
    conn = _open(settings)
    try:
        return month_charges(conn, month)
    finally:
        conn.close()


def upcoming_charges(settings: Settings, after_month: str) -> tuple[tuple[str, str, str, int], ...]:
    """Card charges already known for later months (installments)."""
    conn = _open(settings)
    try:
        return upcoming_card_charges(conn, after_month)
    finally:
        conn.close()


def import_one_file(settings: Settings, name: str, data: bytes) -> FileImport:
    """Import one uploaded export (see fin.storage.imports). Raises ValueError for a bad upload."""
    conn = _open(settings)
    try:
        mapped = _mapped(state(conn) if settings_in_db(conn) else {})
    finally:
        conn.close()
    return import_upload(settings, name, data, _categorize, mapped)


def sources_status(settings: Settings) -> tuple[SourceStatus, ...]:
    """Every source with its import history, for the accounts and imports sheet: the known
    adapters, then the sources the user mapped by hand."""
    conn = _open(settings)
    try:
        mapped = _mapped(state(conn) if settings_in_db(conn) else {})
        sources = tuple(adapter.source for adapter in (*build_adapters(), *mapped))
        return import_status(conn, sources)
    finally:
        conn.close()


def ledger_snapshot(settings: Settings) -> dict:
    """Every stored row, for sending to another device (see fin.storage.merge)."""
    conn = _open(settings)
    try:
        return export_snapshot(conn)
    finally:
        conn.close()


def merge_ledger(settings: Settings, snapshot: dict) -> MergeSummary:
    """Add another device's rows that are missing here, then categorize everything again."""
    conn = _open(settings)
    try:
        summary = merge_snapshot(conn, snapshot)
        _categorize(conn, settings)
        return summary
    finally:
        conn.close()


# The private configs a device can receive, by file name.
PRIVATE_CONFIGS = tuple(FILE_NAMES.values())
_DOCUMENT_OF = {file_name: name for name, file_name in FILE_NAMES.items()}


def _config_paths(settings: Settings) -> dict[str, Path]:
    return {FILE_NAMES[name]: path for name, path in document_paths(settings).items()}


def private_configs(settings: Settings) -> dict[str, str]:
    """The private configs this device has, as YAML text, by standard file name."""
    conn = _open(settings)
    try:
        if settings_in_db(conn):
            return {
                FILE_NAMES[name]: yaml.safe_dump(raw, allow_unicode=True, sort_keys=False)
                for name, raw in export_documents(conn).items()
                if raw is not MISSING
            }
    finally:
        conn.close()
    return {
        name: path.read_text(encoding="utf-8")
        for name, path in _config_paths(settings).items()
        if path.is_file()
    }


def write_private_configs(settings: Settings, configs: dict[str, str]) -> list[str]:
    """Replace this device's private configs with the given ones. Raises ConfigError if unreadable.

    Every file is checked before any is written, so a bad file changes nothing.
    """
    paths = _config_paths(settings)
    unknown = sorted(set(configs) - set(paths))
    if unknown:
        raise ConfigError(f"unknown config file: {', '.join(unknown)}")
    parsed = {}
    for name, text in configs.items():
        try:
            parsed[name] = yaml.safe_load(text)
        except yaml.YAMLError as exc:
            raise ConfigError(f"invalid YAML in {name}") from exc
    conn = _open(settings)
    try:
        if settings_in_db(conn):
            import_documents(conn, {_DOCUMENT_OF[name]: raw for name, raw in parsed.items()})
            return sorted(configs)
    finally:
        conn.close()
    for name, text in configs.items():
        paths[name].parent.mkdir(parents=True, exist_ok=True)
        paths[name].write_text(text, encoding="utf-8")
    return sorted(configs)


def saved_budget(settings: Settings) -> BudgetConfig | None:
    """The saved monthly budget, or None when none was saved."""
    conn = _open(settings)
    try:
        return load_configs(conn, settings).budget()
    finally:
        conn.close()


def save_budget(settings: Settings, config: BudgetConfig) -> None:
    """Save the monthly budget where the settings live (the change log or the YAML file)."""
    conn = _open(settings)
    try:
        if settings_in_db(conn):
            import_documents(conn, {"budget": budget_document(config)})
            return
    finally:
        conn.close()
    save_budget_config(settings.budget_path, config)


def settings_documents(settings: Settings) -> dict[str, object]:
    """Every private settings document as it stands now (None where it does not exist)."""
    conn = _open(settings)
    try:
        if settings_in_db(conn):
            documents = export_documents(conn)
        else:
            documents = read_files(settings)
    finally:
        conn.close()
    return {name: None if raw is MISSING else raw for name, raw in documents.items()}


def import_settings(settings: Settings) -> int:
    """Take the private YAML files into the change log; from then on settings are read there.

    Only differences become changes, so running it again after editing a file
    records just the edits. A file that does not exist removes that document.
    """
    documents = read_files(settings)
    paths = document_paths(settings)
    check = Configs(documents, {name: str(path) for name, path in paths.items()})
    check.private_rules(load_taxonomy())  # every file must be valid before anything is written
    check.baseline()
    check.goals()
    check.budget()
    check.scenarios()
    conn = _open(settings)
    try:
        return import_documents(conn, documents)
    finally:
        conn.close()


# ---- the account's shared log (the sync box encrypts and moves the entries)


def log_outgoing(settings: Settings) -> Outgoing:
    """This device's new changes and facts as one log entry (entry None: nothing to send)."""
    conn = _open(settings)
    try:
        return account_log.outgoing(conn)
    finally:
        conn.close()


def log_mark_pushed(settings: Settings, sent: Outgoing) -> None:
    conn = _open(settings)
    try:
        account_log.mark_pushed(conn, sent)
    finally:
        conn.close()


def log_apply(settings: Settings, entries: list[dict], seq: int | None = None) -> Applied:
    """Take in log entries, then categorize again (rules may have changed).

    `seq` is the log position the entries reach; it is saved after they are in.
    """
    conn = _open(settings)
    try:
        applied = account_log.apply_entries(conn, entries)
        if entries:
            _categorize(conn, settings)
        if seq is not None:
            account_log.set_position(conn, seq)
        return applied
    finally:
        conn.close()


def log_position(settings: Settings) -> int:
    conn = _open(settings)
    try:
        return account_log.position(conn)
    finally:
        conn.close()


def log_full_state(settings: Settings) -> dict:
    """Everything this device holds, as one entry (for the account's snapshot)."""
    conn = _open(settings)
    try:
        return account_log.full_state(conn)
    finally:
        conn.close()


# ---- edits made in the app


def edit(settings: Settings, request: dict) -> dict:
    """Apply one edit from the app: a ceiling, a rule, a goal, a category, a manual transaction.

    The settings that would result are checked with the same validators as the
    YAML files before anything is saved; a bad edit raises EditError and changes
    nothing. Returns the id of what was edited and how many changes it made.
    """
    conn = _open(settings)
    try:
        if not settings_in_db(conn):
            raise EditError("the settings still live in the YAML files: set up the account first")
        current = state(conn)
        taxonomy = _effective(current)
        editor = Editor(conn)
        result = plan_edit(editor, current, request, taxonomy,
                           lambda name: _category_used(conn, current, taxonomy, name))  # fmt: skip
        candidate = fold_changes([*read_changes(conn), *editor.made])
        taxonomy = _effective(candidate)  # the rules are checked against the result
        documents = {name: document_from(candidate, name) for name in DOCUMENTS}
        check = Configs(documents, {name: f"settings ({name})" for name in documents})
        try:
            check.private_rules(taxonomy)
            check.baseline()
            check.goals()
            check.budget()
            check.scenarios()
        except ConfigError as exc:
            raise EditError(str(exc)) from exc
        with conn:
            made = editor.save()
        _categorize(conn, settings)
        file = result.pop("file", None)
        if file:  # a source mapped by hand: import the file it was mapped from
            result["import"] = _import_mapped(conn, settings, result["id"], file)
        return {**result, "changes": made}
    finally:
        conn.close()


def _import_mapped(conn: sqlite3.Connection, settings: Settings, map_id: str, file: object) -> dict:
    """Import the inbox file a source was just mapped from. Counts only."""
    try:
        name = check_upload(file, 1) if isinstance(file, str) else ""
    except ValueError:
        name = ""
    path = settings.inbox_dir / name
    if not name or not path.is_file():
        raise EditError("the file to import is no longer in the inbox")
    adapter = next(a for a in _mapped(state(conn)) if a.source == f"map_{map_id}")
    if not adapter.detect(path):
        raise EditError("the file does not match the columns of this source")
    done = import_saved(settings, path, adapter, _categorize)
    return {"status": done.status, "source": done.source, "rows_seen": done.rows_seen,
            "rows_inserted": done.rows_inserted, "rows_duplicate": done.rows_duplicate}  # fmt: skip


def transaction_details(settings: Settings, tx_hash: str) -> dict | None:
    """One transaction for its sheet: the row, the merchant counts and the categories.

    None when there is no such transaction (legacy workbook rows are not editable).
    """
    conn = _open(settings)
    try:
        row = find_transaction(conn, tx_hash)
        if row is None:
            return None
        merchant, exact = merchant_counts(conn, row)
        in_db = settings_in_db(conn)
        current = state(conn) if in_db else {}
    finally:
        conn.close()
    taxonomy = _effective(current)
    manual = row["source"] == MANUAL_SOURCE
    return {
        "tx_hash": row["tx_hash"],
        "name": row["description"],
        "amount": row["my_share_agorot"],
        "date": row["tx_date"],
        "source": row["source"],
        "category": row["category"],
        "bucket": row["bucket"],
        "kind": row["flow_kind"],
        "manual": manual,
        "manual_id": row["source_ref"] if manual else None,
        "overridden": tx_hash in current.get("category_override", {}),
        "note": notes(current).get(tx_hash, ""),
        # A payment of an installment deal: when it was bought and when it is charged; it
        # counts in the purchase month plus k-1 (spec v0.39).
        "installment": {
            "number": row["installment_number"],
            "of": row["installment_total"],
            "bought": row["tx_date"],
            "charged": row["billing_date"],
        }
        if is_installment(row["installment_number"], row["installment_total"])
        else None,
        "editable": in_db,
        "merchant_count": merchant,
        "merchant_amount_count": exact,
        "categories": _ordered_categories(current, taxonomy),
    }


def transaction_notes(settings: Settings) -> dict[str, str]:
    """Every note on a transaction, by tx_hash (none until the settings are in the change log)."""
    conn = _open(settings)
    try:
        return notes(state(conn)) if settings_in_db(conn) else {}
    finally:
        conn.close()


def actual_month(settings: Settings, month: str) -> MonthSummary | None:
    """One month of the actual ledger (bank and cards), or None when it has no data."""
    conn = _open(settings)
    try:
        months = actual_summaries(conn, month, month).months
    finally:
        conn.close()
    return months[0] if months else None


def actual_months(settings: Settings) -> tuple[str, ...]:
    """Every month with bank or card data, oldest first (the legacy workbook left out)."""
    conn = _open(settings)
    try:
        rows = conn.execute(
            "SELECT DISTINCT budget_month FROM transactions WHERE source != ?"
            " ORDER BY budget_month",
            (LEGACY_SOURCE,),
        ).fetchall()
    finally:
        conn.close()
    return tuple(row[0] for row in rows)


def profile(settings: Settings) -> dict:
    """The user's profile from the account: the name (None until set), the user's own category
    names, and whether they can be edited here (the settings live in the change log once the
    account is set up)."""
    conn = _open(settings)
    try:
        in_db = settings_in_db(conn)
        current = state(conn) if in_db else {}
        return {
            "name": profile_name(current),
            "editable": in_db,
            "labels": category_labels(current),  # the user's own category names
            "group_labels": group_labels(current),  # and spending group names
            "sources": {m.source: m.name for m in source_maps(current)},  # mapped by hand
        }
    finally:
        conn.close()


def transaction_titles(settings: Settings) -> tuple[dict[str, str], list[RenameRule]]:
    """Titles the user gave: each transaction's own, and the merchant rename rules in order."""
    conn = _open(settings)
    try:
        if not settings_in_db(conn):
            return {}, []
        current = state(conn)
        return own_titles(current), rename_rules(current)
    finally:
        conn.close()


def plan_items(settings: Settings) -> dict:
    """What "Coming up" needs from the account: the ids of commitments, events and goals
    in their order (empty while the settings are still YAML files: then nothing is
    editable), and the card charges the user hid."""
    conn = _open(settings)
    try:
        if not settings_in_db(conn):
            return {"commitment": [], "event": [], "goal": [], "hidden": set(), "editable": False}
        current = state(conn)
        return {
            **{entity: item_ids(current, entity) for entity in ("commitment", "event", "goal")},
            "hidden": hidden_charges(current),
            "editable": True,
        }
    finally:
        conn.close()


def pending_manual(settings: Settings) -> frozenset[str]:
    """Manual items paid by card or bank that no imported row has replaced yet."""
    conn = _open(settings)
    try:
        if not settings_in_db(conn):
            return frozenset()
        current = state(conn)
        return manual_plan(conn, current, _effective(current)).pending
    finally:
        conn.close()


def _ordered_categories(current: dict, taxonomy: Taxonomy) -> list[tuple[str, str | None, str]]:
    """The categories a picker offers: hidden and deleted ones are left out."""
    specs = taxonomy.categories
    return [
        (n, specs[n].bucket, specs[n].kind)
        for n in category_order(current, taxonomy)
        if n not in taxonomy.hidden
    ]


def category_list(settings: Settings) -> list[tuple[str, str | None, str]]:
    """Every category: (name, bucket, kind), in the user's order inside each group."""
    conn = _open(settings)
    try:
        current = state(conn) if settings_in_db(conn) else {}
    finally:
        conn.close()
    return _ordered_categories(current, _effective(current))


@dataclass(frozen=True)
class NetWorth:
    series: list[MonthWorth]  # the 12 months up to the asked one, oldest first
    bank: tuple[str, int] | None  # the newest bank balance from the files: (date, agorot)
    holdings: list[tuple[Holding, list[BalancePoint]]]  # typed in, the user's order
    editable: bool  # the settings live in the change log (savings are kept there)


SERIES_MONTHS = 12


def bank_month_end(settings: Settings, month: str) -> int | None:
    """The bank balance at the end of a month, from the files (None without one)."""
    conn = _open(settings)
    try:
        return bank_balances_by_month(conn).get(month)
    finally:
        conn.close()


def net_worth(settings: Settings, month: str) -> NetWorth:
    """Net worth for the Savings tab and Home: the bank from the files plus the savings the
    user typed in (fin.logic.net_worth), month by month up to `month`."""
    conn = _open(settings)
    try:
        in_db = settings_in_db(conn)
        found = holdings(state(conn)) if in_db else []
        bank = bank_balances_by_month(conn)
        latest = latest_bank_balance(conn)
    finally:
        conn.close()
    months = [add_months(month, -n) for n in range(SERIES_MONTHS - 1, -1, -1)]
    return NetWorth(net_worth_series(months, bank, found), latest, found, in_db)


def _category_used(conn: sqlite3.Connection, current: dict, taxonomy: Taxonomy, name: str) -> bool:
    """Whether deleting a category needs a replacement: it has transactions (any source,
    by hand too), a rule (built-in, the user's own, or a card company's mapping), or a
    category the user set on a transaction."""
    row = conn.execute(
        "SELECT 1 FROM transactions WHERE category = ? OR category_orig = ? LIMIT 1", (name, name)
    ).fetchone()
    if row is not None:
        return True
    if any(rule.category == name for rule in taxonomy.rules):
        return True
    if any(name in mapping.values() for mapping in taxonomy.issuer_categories.values()):
        return True
    if any(fields.get("category") == name for fields in current.get("rule", {}).values()):
        return True
    for entity in ("category_override", "manual_tx"):
        if any(fields.get("category") == name for fields in current.get(entity, {}).values()):
            return True
    return any(f.get("merged_into") == name for f in current.get("category_label", {}).values())


@dataclass(frozen=True)
class CategoryEditor:
    editable: bool
    categories: list[tuple[str, str | None, str]]  # live ones, in the user's order
    groups: list[str]  # the spending groups, deleted ones left out, empty ones kept
    ceilings: dict[str, int]  # group -> monthly budget in agorot
    used: frozenset[str]  # categories whose delete needs a replacement
    fixed: frozenset[str]  # the app's own categories: never deleted
    deleted: list[tuple[str, str | None]]  # (category, the one it went into, or None)


def category_editor(settings: Settings) -> CategoryEditor:
    """Everything Settings > Categories shows (design.md §6, editor part two)."""
    conn = _open(settings)
    try:
        in_db = settings_in_db(conn)
        current = state(conn) if in_db else {}
        taxonomy = _effective(current)
        listed = _ordered_categories(current, taxonomy)
        used = frozenset(n for n, _, _ in listed if _category_used(conn, current, taxonomy, n))
        budget = load_configs(conn, settings).budget()
    finally:
        conn.close()
    ceilings = dict(budget.ceilings) if budget is not None else {}
    deleted = [
        (name, fields.get("merged_into"))
        for name, fields in current.get("category_label", {}).items()
        if fields.get("hidden") or fields.get("merged_into")
    ]
    return CategoryEditor(
        in_db, listed, expense_groups(current, taxonomy), ceilings, used,
        taxonomy.special | {"מזומן"}, deleted,
    )  # fmt: skip
