"""Apply the categorization rules to the stored bank and card transactions."""

import sqlite3
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass, field

from fin.logic import (
    LAYER_CARD_PAYMENT,
    LAYER_NONE,
    SPECIFIC_LAYERS,
    BankPayment,
    CardCharge,
    LedgerRow,
    LegacyRow,
    Rule,
    Taxonomy,
    classify,
    learn_merchants,
    match_card_payments,
    match_legacy,
    resolve,
)

# The legacy workbook was categorized by hand; its rows are never touched.
LEGACY_SOURCE = "legacy_excel"


@dataclass
class CategorizeSummary:
    total: int = 0
    # (source, layer) -> number of transactions decided by that layer
    by_layer: Counter[tuple[str, str]] = field(default_factory=Counter)
    card_payments_matched: int = 0
    card_payments_unmatched: int = 0

    @property
    def uncategorized(self) -> int:
        return sum(n for (_, layer), n in self.by_layer.items() if layer == LAYER_NONE)


def categorize_all(
    conn: sqlite3.Connection,
    taxonomy: Taxonomy,
    private_rules: Sequence[Rule] = (),
    by_date_sources: frozenset[str] = frozenset(),
) -> CategorizeSummary:
    """Re-classify every non-legacy transaction in one database transaction.

    `by_date_sources` are cards whose rows count by transaction date (mapped by hand,
    no billing date): their payment in the bank is always explained by those rows.
    The result depends only on the stored rows and the rules, so running it
    again changes nothing.
    """
    rows = conn.execute(
        "SELECT id, source, description, source_category, my_share_agorot, tx_date,"
        " billing_date, card_last4 FROM transactions WHERE source != ? ORDER BY id",
        (LEGACY_SOURCE,),
    ).fetchall()
    payments = [
        BankPayment(row["id"], row["tx_date"], row["my_share_agorot"], issuer)
        for row in rows
        if row["billing_date"] is None
        for is_payment, issuer in [_card_issuer(row["description"], taxonomy)]
        if is_payment
    ]
    charges = [
        CardCharge(row["source"], row["billing_date"], row["card_last4"], row["my_share_agorot"])
        for row in rows
        if row["billing_date"] is not None
    ]
    covered = match_card_payments(payments, charges)
    for payment in payments:
        if payment.issuer in by_date_sources:
            covered[payment.tx_id] = payment.amount_agorot
    payment_ids = {payment.tx_id for payment in payments}

    # A card bill with any detail in a card ledger is explained there, not by the workbook.
    matchable = [
        LedgerRow(
            row["id"], row["tx_date"], row["my_share_agorot"], row["source"], row["description"]
        )
        for row in rows
        if not covered.get(row["id"])
    ]
    legacy_rows = [
        LegacyRow(row["id"], row["tx_date"], row["total_amount_agorot"], row["bucket"], row[4])
        for row in conn.execute(
            "SELECT id, tx_date, total_amount_agorot, bucket, category FROM transactions"
            " WHERE source = ?",
            (LEGACY_SOURCE,),
        )
    ]
    legacy_matches = match_legacy(matchable, legacy_rows, taxonomy.legacy_match_window_days)
    learned = learn_merchants(matchable, legacy_matches)

    summary = CategorizeSummary(total=len(rows))
    updates = []
    for row in rows:
        detail = covered.get(row["id"], 0) if row["id"] in payment_ids else None
        if detail and detail == row["my_share_agorot"]:
            result = resolve(
                taxonomy, taxonomy.matched_card_payment, f"{LAYER_CARD_PAYMENT}:matched"
            )
            summary.card_payments_matched += 1
        else:
            match = legacy_matches.get(row["id"])
            result = classify(
                row["description"],
                row["source"],
                row["source_category"],
                row["my_share_agorot"],
                taxonomy,
                private_rules,
                legacy=(match.category, match.bucket) if match else None,
                learned=None if detail else learned.get((row["source"], row["description"])),
            )
            if detail is not None and (detail or result.layer not in SPECIFIC_LAYERS):
                # A card bill that nothing specific explains: spending without detail.
                result = resolve(
                    taxonomy, taxonomy.unmatched_card_payment, f"{LAYER_CARD_PAYMENT}:unmatched"
                )
                summary.card_payments_unmatched += 1
        summary.by_layer[(row["source"], result.layer)] += 1
        updates.append(
            (result.category, result.bucket, result.kind, result.rule, detail, row["id"])
        )
    with conn:
        conn.executemany(
            "UPDATE transactions SET category = ?, bucket = ?, flow_kind = ?, category_rule = ?,"
            " detail_covered_agorot = ? WHERE id = ?",
            updates,
        )
    return summary


def _card_issuer(description: str, taxonomy: Taxonomy) -> tuple[bool, str | None]:
    """Return (is a card bill payment, the card ledger source that details it)."""
    for label, source in taxonomy.card_payment_labels.items():
        if description.startswith(label):
            return True, source
    return False, None
