"""Local-first personal finance system."""

__version__ = "0.1.0"
