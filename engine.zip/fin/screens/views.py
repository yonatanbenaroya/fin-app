"""One function per screen of the web app: the numbers that screen shows, ready to draw.

Every function returns plain JSON-ready data: amounts in integer agorot,
percentages, statuses and months already worked out. The browser formats
and draws; it does no arithmetic on money. Names of buckets, categories,
and goals are passed as stable keys or as the engine's own names,
and the browser translates them.
"""

import calendar
import json
from typing import Any

from fin.logic import (
    ALREADY,
    DEFAULT_WINDOW_MONTHS,
    Outlook,
    Pace,
    add_months,
    build_outlook,
    effective_ceilings,
    goal_progress,
    month_pace,
    months_between,
)
from fin.storage import (
    Plan,
    Settings,
    edit,
    import_one_file,
    ledger,
    load_plan,
    saved_budget,
    sources_status,
    spend_by_category,
    upcoming_charges,
)
from fin.sync import MAC, receive_plain

# The budget buckets as the design names them. Buckets come from config/categories.yaml.
BUCKET_KEYS = {
    "אוכל": "food",
    "פנאי": "leisure",
    "רכב ותחבורה": "transport",
    "קבועות": "recurring",
    'בלת"מ': "unplanned",
    "שכר דירה": "rent",
}
RENT = "rent"
OTHER = "other"
UPCOMING_LIMIT = 5


def bucket_key(bucket: str | None) -> str:
    return BUCKET_KEYS.get(bucket or "", OTHER)


def _month_shape(data_date: str) -> tuple[int, int]:
    """(day of the data, days in that month)."""
    year, month, day = (int(part) for part in data_date.split("-"))
    return day, calendar.monthrange(year, month)[1]


def _pace(p: Pace | None) -> dict[str, Any] | None:
    if p is None:
        return None
    return {
        "spent": p.spent_agorot,
        "ceiling": p.ceiling_agorot,
        "left": p.remaining_agorot,
        "days_left": p.days_left,
        "daily": p.daily_allowance_agorot,
        "spent_pct": p.spent_percent,
        "even_pct": p.even_percent,
        "status": p.status,
        "ratio_permille": p.ratio_permille,
        "level": p.level,
        "day": p.day,
        "days_in_month": p.days_in_month,
    }


def _budget_pace(plan: Plan, settings: Settings) -> tuple[dict[str, Any] | None, Pace | None]:
    """The month's budget against spending so far, or (None, None) without a saved budget.

    Rent and other declared buckets are not part of the pace; a commitment
    charged to a bucket is allowed on top of that bucket's ceiling.
    """
    saved = saved_budget(settings)
    if saved is None or plan.data_month is None or plan.data_date is None:
        return None, None
    month = plan.data_month
    ceilings = effective_ceilings(saved.ceilings, {}, plan.goals.commitments, month)
    current = plan.current_month
    spent = {line.bucket: line.spent_agorot for line in current.buckets} if current else {}
    day, days = _month_shape(plan.data_date)
    total, buckets = month_pace(ceilings, spent, day, days)
    info = {
        "month": month,
        "preview": month < saved.start_month,
        "start_month": saved.start_month,
        "total": _pace(total),
        "buckets": {bucket: _pace(p) for bucket, p in buckets.items()},
    }
    return info, total


def _outlook(plan: Plan) -> Outlook:
    assert plan.baseline is not None and plan.balance is not None and plan.data_month is not None
    return build_outlook(
        plan.baseline,
        plan.goals,
        plan.balance[1],
        plan.data_month,
        [month.month for month in plan.window],
    )


def _goals(plan: Plan, outlook: Outlook) -> list[dict[str, Any]]:
    assert plan.balance is not None
    progress = goal_progress(outlook.statuses, plan.balance[1])
    return [
        {
            "name": status.name,
            "threshold": status.threshold_agorot,
            "reached": status.reached,
            "already": status.reached == ALREADY,
            "target_month": status.target_month,
            "dated": status.dated,
            "required_monthly": status.required_monthly_agorot,
            "minimum_required_monthly": status.minimum_required_monthly_agorot,
            "progress_pct": pct,
        }
        for status, pct in zip(outlook.statuses, progress, strict=True)
    ]


def _not_ready(plan: Plan) -> dict[str, Any]:
    return {"ready": False, "data_date": plan.data_date}


def home(settings: Settings) -> dict[str, Any]:
    """Home: money left this month, the overdraft, the goals and what is coming up."""
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if not plan.ready:
        return _not_ready(plan)
    assert plan.data_month is not None and plan.balance is not None
    budget, _ = _budget_pace(plan, settings)
    outlook = _outlook(plan)
    next_month = add_months(plan.data_month, 1)
    coming = [
        {"kind": "fixed", "name": bucket, "bucket": bucket_key(bucket), "month": next_month,
         "amount": amount}
        for bucket, amount in plan.baseline_config.fixed.items()
    ]  # fmt: skip
    for item in plan.goals.commitments:
        if item.first_month <= next_month <= item.last_month:
            coming.append(
                {
                    "kind": "commitment",
                    "name": item.name,
                    "bucket": bucket_key(item.bucket),
                    "month": next_month,
                    "amount": item.amount_agorot,
                    "number": months_between(item.first_month, next_month) + 1,
                    "of": months_between(item.first_month, item.last_month) + 1,
                }
            )
    card = [c for c in upcoming_charges(settings, plan.data_month) if c[0] == next_month]
    coming.extend(
        {"kind": "card", "name": name, "bucket": bucket_key(bucket), "month": month,
         "amount": amount}
        for month, name, bucket, amount in card
    )  # fmt: skip
    coming.sort(key=lambda item: -item["amount"])
    return {
        "ready": True,
        "data_date": plan.data_date,
        "month": plan.data_month,
        "budget": budget,
        "balance": plan.balance[1],
        "balance_date": plan.balance[0],
        "overdraft_limit": plan.goals.overdraft_limit_agorot,
        "goals": _goals(plan, outlook),
        "coming": coming[:UPCOMING_LIMIT],
    }


def activity(settings: Settings, months: int = 2) -> dict[str, Any]:
    """Activity: the latest months of transactions, grouped by day, newest first."""
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if plan.data_month is None:
        return _not_ready(plan)
    first = add_months(plan.data_month, 1 - max(1, months))
    days: list[dict[str, Any]] = []
    for entry in ledger(settings, first, plan.data_month):
        if not days or days[-1]["date"] != entry.tx_date:
            days.append({"date": entry.tx_date, "spent": 0, "items": []})
        day = days[-1]
        if entry.amount_agorot < 0:
            day["spent"] -= entry.amount_agorot
        day["items"].append(
            {
                "id": entry.tx_id,
                "name": entry.description,
                "amount": entry.amount_agorot,
                "category": entry.category,
                "bucket": bucket_key(entry.bucket),
                "source": entry.source,
                "kind": entry.flow_kind,
            }
        )
    return {"ready": True, "data_date": plan.data_date, "first_month": first, "days": days}


def categories(settings: Settings) -> dict[str, Any]:
    """Categories: the month's spending per bucket, against the budget, with its categories."""
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if plan.data_month is None:
        return _not_ready(plan)
    budget, _ = _budget_pace(plan, settings)
    paces = budget["buckets"] if budget else {}
    groups: dict[str, dict[str, Any]] = {}
    for bucket, category, spent in spend_by_category(settings, plan.data_month):
        group = groups.setdefault(
            bucket, {"name": bucket, "key": bucket_key(bucket), "spent": 0, "categories": []}
        )
        group["spent"] += spent
        group["categories"].append({"name": category, "spent": spent})
    for bucket in paces:
        groups.setdefault(
            bucket, {"name": bucket, "key": bucket_key(bucket), "spent": 0, "categories": []}
        )
    rent = [g for g in groups.values() if g["key"] == RENT]
    rest = sorted((g for g in groups.values() if g["key"] != RENT), key=lambda g: -g["spent"])
    total = sum(max(0, g["spent"]) for g in rest)
    for group in rest:
        group["pace"] = paces.get(group["name"])
        group["share_pct"] = max(0, group["spent"]) * 100 // total if total else 0
    ahead = next((g["name"] for g in rest if g["pace"] and g["pace"]["status"] != "on_track"), None)
    return {
        "ready": True,
        "data_date": plan.data_date,
        "month": plan.data_month,
        "budget": budget,
        "spent": total,
        "groups": rest,
        "rent": rent[0] if rent else None,
        "open": ahead,
    }


def goals(settings: Settings) -> dict[str, Any]:
    """Goals: progress, the date each goal is reached, and what is still missing.

    The "what if" and "can I afford it" sections of the old design are left out
    until the future-items concept (design.md §9) replaces them.
    """
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if not plan.ready:
        return _not_ready(plan)
    base = _outlook(plan)
    return {
        "ready": True,
        "data_date": plan.data_date,
        "first_month": base.first_month,
        "last_month": base.projection[-1].month,
        "monthly_flow": base.base_flow_agorot,
        "balance": plan.balance[1] if plan.balance else None,
        "goals": _goals(plan, base),
    }


def accounts(settings: Settings) -> dict[str, Any]:
    """Accounts and imports: each source with its import history. Counts and dates only."""
    return {
        "sources": [
            {
                "source": status.source,
                "files": status.files,
                "last_import": status.last_import,
                "newest_transaction": status.newest_transaction,
            }
            for status in sources_status(settings)
        ]
    }


def upload(settings: Settings, name: str, data: bytes) -> dict[str, Any]:
    """Import one file sent from the import sheet. Raises ValueError for a bad upload."""
    result = import_one_file(settings, name, data)
    return {
        "name": result.name,
        "status": result.status,
        "source": result.source,
        "saved": result.saved,
        "rows_seen": result.rows_seen,
        "rows_inserted": result.rows_inserted,
        "rows_duplicate": result.rows_duplicate,
        "rows_quarantined": result.rows_quarantined,
    }


def receive(settings: Settings, plain: bytes) -> dict[str, Any]:
    """Merge a decrypted pack from the phone into the Mac. Counts only."""
    result = receive_plain(settings, plain, MAC)
    merged = result.merged
    return {
        "sender": result.sender,
        "exported_at": result.exported_at,
        "transactions": merged.transactions,
        "import_runs": merged.import_runs,
        "quarantine": merged.quarantine,
        "configs": list(result.configs),
    }


MAX_EDIT_BYTES = 64 * 1024


def apply_edit(settings: Settings, body: bytes) -> dict[str, Any]:
    """One edit from the app (JSON). Raises ValueError for a malformed or refused edit."""
    if len(body) > MAX_EDIT_BYTES:
        raise ValueError("the edit is too large")
    try:
        request = json.loads(body)
    except ValueError as exc:
        raise ValueError("the edit is not JSON") from exc
    if not isinstance(request, dict):
        raise ValueError("the edit must be a JSON object")
    return edit(settings, request)
