"""One function per screen of the web app: the numbers that screen shows, ready to draw.

Every function returns plain JSON-ready data: amounts in integer agorot,
percentages, statuses and months already worked out. The browser formats
and draws; it does no arithmetic on money. Names of buckets, categories,
and goals are passed as stable keys or as the engine's own names,
and the browser translates them.
"""

import json
from datetime import date
from typing import Any

from fin.logic import (
    ALREADY,
    DEFAULT_WINDOW_MONTHS,
    RATE_SCALE,
    UNASSIGNED,
    Charge,
    Due,
    Outlook,
    Pace,
    PaceDay,
    add_months,
    build_outlook,
    date_range,
    days_in,
    display_title,
    effective_ceilings,
    goal_progress,
    group,
    guess_columns,
    month_pace,
    months_between,
    pace_day,
    point_for,
    same_payment,
    still_due,
    value_agorot,
    with_unassigned,
)
from fin.storage import (
    Plan,
    Settings,
    actual_month,
    actual_months,
    category_list,
    charge_key,
    charges_in_month,
    edit,
    import_one_file,
    ledger,
    ledger_between,
    load_plan,
    net_worth,
    pending_manual,
    plan_items,
    profile,
    saved_budget,
    sources_status,
    spend_by_category,
    transaction_details,
    transaction_notes,
    transaction_titles,
    upcoming_charges,
)
from fin.storage import (
    category_editor as category_editor_data,
)
from fin.sync import MAC, receive_plain

# The budget buckets as the design names them. Buckets come from config/categories.yaml.
BUCKET_KEYS = {
    "אוכל": "food",
    "פנאי": "leisure",
    "רכב ותחבורה": "transport",
    "קבועות": "recurring",
    'בלת"מ': "unplanned",
    "שכר דירה": "rent",
}
RENT = "rent"
OTHER = "other"
UPCOMING_LIMIT = 5


def bucket_key(bucket: str | None) -> str:
    return BUCKET_KEYS.get(bucket or "", OTHER)


def _when(plan: Plan, today: date | None) -> PaceDay | None:
    """Where the month stands: today on this device, against the latest data."""
    if plan.data_date is None:
        return None
    return pace_day(date.fromisoformat(plan.data_date), today or date.today())


def _pace(p: Pace | None) -> dict[str, Any] | None:
    if p is None:
        return None
    return {
        "spent": p.spent_agorot,
        "ceiling": p.ceiling_agorot,
        "due": p.due_agorot,
        "left": p.remaining_agorot,
        "days_left": p.days_left,
        "daily": p.daily_allowance_agorot,
        "spent_pct": p.spent_percent,
        "even_pct": p.even_percent,
        "status": p.status,
        "ratio_permille": p.ratio_permille,
        "level": p.level,
        "day": p.day,
        "days_in_month": p.days_in_month,
    }


def _month_fixed(
    plan: Plan, settings: Settings, when: PaceDay, ceilings: dict[str, int]
) -> tuple[dict[str, int], Due, list[Charge]]:
    """This month's spending so far per bucket and its fixed payments (design.md §6 "What
    left means"): card installments not charged yet are taken out of the spending and
    counted as still due, with the commitments no charge matches yet."""
    charges = list(charges_in_month(settings, when.month, plan.data_date or ""))
    current = plan.current_month if when.has_data else None
    if current is not None:
        spent = {line.bucket: line.spent_agorot for line in current.buckets}
    else:  # a month the data does not reach: only installments billed in it are in the files
        spent = {}
        for charge in charges:
            spent[charge.bucket] = spent.get(charge.bucket, 0) + charge.amount_agorot
    commitments = with_unassigned(plan.goals.commitments)
    due = still_due(commitments, when.month, charges, ceilings.keys())
    for bucket, amount in due.scheduled.items():
        spent[bucket] = spent.get(bucket, 0) - amount
    for bucket, amount in due.outside.items():
        spent[bucket] = spent.get(bucket, 0) + amount
    moved = [c for c in charges if c.scheduled and c.bucket in due.scheduled]
    return spent, due, moved


def _budget_pace(
    plan: Plan, settings: Settings, when: PaceDay | None
) -> tuple[dict[str, Any] | None, Pace | None]:
    """This month's budget against spending so far, or (None, None) without a saved budget.

    Days left and the daily allowance count from today (`when`); spending is as
    of the latest data, and nothing is spent yet in a month the data does not
    reach. Rent and other declared buckets are not part of the pace; a
    commitment charged to a bucket is allowed on top of that bucket's ceiling.
    Left is after the fixed payments still due this month (design.md §6).
    """
    saved = saved_budget(settings)
    if saved is None or when is None:
        return None, None
    month = when.month
    ceilings = effective_ceilings(
        saved.ceilings, {}, with_unassigned(plan.goals.commitments), month
    )
    spent, due, _ = _month_fixed(plan, settings, when, ceilings)
    total, buckets = month_pace(
        ceilings, spent, when.day, when.days_in_month, due.due, due.fixed_spent
    )
    info = {
        "month": month,
        "preview": month < saved.start_month,
        "start_month": saved.start_month,
        "total": _pace(total),
        # The hidden group of commitments without a group counts in the total only.
        "buckets": {bucket: _pace(p) for bucket, p in buckets.items() if bucket != UNASSIGNED},
        # The payments held back from "left", for the sheet under the hero number.
        "due_rows": [
            {
                "kind": item.kind,
                "name": item.name,
                "bucket": OTHER if item.bucket == UNASSIGNED else bucket_key(item.bucket),
                "amount": item.amount_agorot,
            }
            for item in due.items
        ],  # fmt: skip
    }
    return info, total


def _final_pace(plan: Plan, settings: Settings, month: str) -> dict[str, Any] | None:
    """A past month's final result against the budget: spent, ceilings, final pace.

    Measured against today's saved budget even before its first month (user
    decision, 2026-11-17); None without a saved budget.
    """
    saved = saved_budget(settings)
    if saved is None:
        return None
    ceilings = effective_ceilings(saved.ceilings, {}, plan.goals.commitments, month)
    summary = actual_month(settings, month)
    spent = {line.bucket: line.spent_agorot for line in summary.buckets} if summary else {}
    days = days_in(int(month[:4]), int(month[5:]))
    total, buckets = month_pace(ceilings, spent, days, days)  # the whole month has gone by
    return {
        "month": month,
        "final": True,
        "preview": False,
        "start_month": saved.start_month,
        "total": _pace(total),
        "buckets": {bucket: _pace(p) for bucket, p in buckets.items()},
    }


def _month_kind(month: str, current: str) -> str:
    return "current" if month == current else "past" if month < current else "forecast"


def _worth_bits(settings: Settings, month: str) -> dict[str, Any]:
    """Home's net worth row: the total and its change this month (it opens Savings)."""
    series = net_worth(settings, month).series
    return {"net_worth": series[-1].total, "net_change": series[-1].total - series[-2].total}


CHART_HEIGHT = 1000  # the chart's points come as 0..1000: the browser only draws them
GROUP_ORDER = ("long_term", "accessible", "future")
REPORT_MONTHS = (1, 4, 7, 10)  # pension and study fund reports come after each quarter


def _rate_text(rate: int) -> str:
    whole, part = divmod(rate, RATE_SCALE)
    return f"{whole}.{part:04d}".rstrip("0").rstrip(".") if part else str(whole)


def _next_report(month: str) -> str:
    year, number = int(month[:4]), int(month[5:7])
    later = [m for m in REPORT_MONTHS if m > number]
    return f"{year:04d}-{later[0]:02d}" if later else f"{year + 1:04d}-01"


def savings(settings: Settings, today: date | None = None) -> dict[str, Any]:
    """The Savings tab (design.md §5, board C14): net worth with its change and 12-month
    trend, then the holdings by availability. Every number is computed here."""
    month = (today or date.today()).isoformat()[:7]
    worth = net_worth(settings, month)
    now, before = worth.series[-1], worth.series[-2]
    totals = [m.total for m in worth.series]
    low, high = min(totals), max(totals)
    span = high - low
    chart = [
        {"month": m.month, "y": CHART_HEIGHT // 2 if span == 0
         else (m.total - low) * CHART_HEIGHT // span}
        for m in worth.series
    ]  # fmt: skip
    groups: dict[str, list[dict[str, Any]]] = {key: [] for key in GROUP_ORDER}
    if worth.bank is not None:
        groups["accessible"].append({
            "kind": "bank", "from_files": True, "balance": worth.bank[1], "as_of": worth.bank[0],
        })  # fmt: skip
    for holding, points in worth.holdings:
        latest = point_for(points, "9999-12")
        row: dict[str, Any] = {
            "id": holding.id, "kind": holding.kind, "name": holding.name, "from_files": False,
            "balance": value_agorot(latest) if latest else 0,
            "as_of": latest.as_of if latest else None, "deposit": holding.deposit_agorot,
            "available": holding.available, "available_from": holding.available_from,
            "vest": holding.vest,
            "fields": {
                "amount_text": amount_text(latest.amount) if latest else "",
                "deposit_text": amount_text(holding.deposit_agorot)
                if holding.deposit_agorot is not None else "",
            },
        }  # fmt: skip
        if holding.in_dollars and latest is not None and latest.rate is not None:
            row["usd_cents"] = latest.amount
            row["fields"]["rate_text"] = _rate_text(latest.rate)
        groups[group(holding, month)].append(row)
    counted = now.accessible + now.long_term
    return {
        "ready": True,  # savings need no bank or card file
        "editable": worth.editable,
        "month": month,
        "total": now.total,
        "change": now.total - before.total,
        "accessible": now.accessible,
        "long_term": now.long_term,
        "future": now.future,
        # The share of the counted total that is long-term, for the split bar (0..100).
        "long_term_pct": 0
        if counted <= 0 or now.long_term <= 0
        else min(100, round(now.long_term * 100 / counted)),
        "chart": chart,
        "chart_from": worth.series[0].month,
        "chart_to": month,
        "groups": [{"key": key, "rows": rows} for key, rows in groups.items() if rows],
        "next_update": _next_report(month),
    }


def amount_text(agorot: int) -> str:
    """An amount as an edit field shows it: shekels, with agorot only when there are any."""
    whole, cents = divmod(abs(agorot), 100)
    return str(whole) if cents == 0 else f"{whole}.{cents:02d}"


def _payments(plan: Plan, settings: Settings, month: str) -> list[dict[str, Any]]:
    """The payments known for one month: declared fixed amounts, commitments, dated events
    and card charges, largest first (design.md §6 "Coming up").

    One real payment is one row: a commitment and a card charge in the same month are the
    same payment when the amount is the same or the commitment's name is in the bank's
    text; the row then shows the card's name with the commitment's installment count.
    Card charges the user hid are left out. Rows from the user's own entries carry their
    id, for editing.
    """
    items = plan_items(settings)
    commitment_ids, event_ids = items["commitment"], items["event"]
    found = [
        {"kind": "fixed", "name": bucket, "bucket": bucket_key(bucket), "month": month,
         "amount": amount}
        for bucket, amount in plan.baseline_config.fixed.items()
    ]  # fmt: skip
    after = add_months(month, -1)
    cards = [
        {"kind": "card", "name": name, "bucket": bucket_key(bucket), "month": when,
         "amount": amount, "key": charge_key(when, name, amount)}
        for when, name, bucket, amount in upcoming_charges(settings, after)
        if when == month and charge_key(when, name, amount) not in items["hidden"]
    ]  # fmt: skip
    for index, item in enumerate(plan.goals.commitments):
        if not item.first_month <= month <= item.last_month:
            continue
        row = {
            "kind": "commitment",
            "name": item.name,
            "bucket": bucket_key(item.bucket),
            "month": month,
            "amount": item.amount_agorot,
            "number": months_between(item.first_month, month) + 1,
            "of": months_between(item.first_month, item.last_month) + 1,
            "id": commitment_ids[index] if index < len(commitment_ids) else None,
            "from": item.first_month,
            "until": item.last_month,
            "amount_text": amount_text(item.amount_agorot),
        }
        twin = next(
            (c for c in cards
             if same_payment(item.name, item.amount_agorot, c["name"], c["amount"])),
            None,
        )  # fmt: skip
        if twin is not None:  # one payment: the card's name, the commitment's count
            cards.remove(twin)
            row.update(name=twin["name"], card=True)
        found.append(row)
    for index, event in enumerate(plan.goals.events):
        if event.month == month and event.amount_agorot:
            found.append(
                {
                    "kind": "event",
                    "name": event.label,
                    "bucket": OTHER,
                    "month": month,
                    "amount": abs(event.amount_agorot),
                    "income": event.amount_agorot > 0,
                    "id": event_ids[index] if index < len(event_ids) else None,
                    "amount_text": amount_text(abs(event.amount_agorot)),
                }
            )
    found.extend(cards)
    found.sort(key=lambda row: -row["amount"])
    return found


def _forecast(plan: Plan, settings: Settings, outlook: Outlook, month: str) -> dict[str, Any]:
    """A future month as a forecast: no pace (design.md §6 "Month picker"). The budget's
    ceilings, the payments already known, and the free money the projection expects."""
    projected = next(p for p in outlook.projection if p.month == month)
    saved = saved_budget(settings)
    ceilings = (
        effective_ceilings(saved.ceilings, {}, plan.goals.commitments, month) if saved else {}
    )
    payments = [p for p in _payments(plan, settings, month) if not p.get("income")]
    return {
        "month": month,
        "forecast": True,
        "budget": sum(ceilings.values()) if saved else None,
        "buckets": ceilings,
        "payments": sum(p["amount"] for p in payments),
        "free": projected.flow_agorot,
        "balance_end": projected.balance_agorot,
    }


def _outlook(plan: Plan) -> Outlook:
    assert plan.baseline is not None and plan.balance is not None and plan.data_month is not None
    return build_outlook(
        plan.baseline,
        plan.goals,
        plan.balance[1],
        plan.data_month,
        [month.month for month in plan.window],
    )


def _goals(plan: Plan, outlook: Outlook, ids: list[str] | None = None) -> list[dict[str, Any]]:
    """Each goal in priority order: its progress and, for editing, its id and own fields."""
    assert plan.balance is not None
    progress = goal_progress(outlook.statuses, plan.balance[1])
    ids = ids or []
    return [
        {
            "id": ids[index] if index < len(ids) else None,
            **_goal_fields(goal),
            "name": status.name,
            "threshold": status.threshold_agorot,
            "reached": status.reached,
            "already": status.reached == ALREADY,
            "target_month": status.target_month,
            "dated": status.dated,
            "required_monthly": status.required_monthly_agorot,
            "minimum_required_monthly": status.minimum_required_monthly_agorot,
            "progress_pct": pct,
        }
        for index, (goal, status, pct) in enumerate(
            zip(plan.goals.goals, outlook.statuses, progress, strict=True)
        )
    ]


def _goal_fields(goal: Any) -> dict[str, Any]:
    """What the goal sheet edits: its kind (an amount, months of spending, or back to zero)."""
    kind = "amount" if goal.amount_agorot else "months" if goal.months_of_spend else "zero"
    return {
        "kind": kind,
        "amount_text": amount_text(goal.amount_agorot) if goal.amount_agorot else "",
        "minimum_text": amount_text(goal.minimum_agorot) if goal.minimum_agorot else "",
        "months_of_spend": goal.months_of_spend or None,
        "by": goal.by,
    }


def _not_ready(plan: Plan) -> dict[str, Any]:
    return {"ready": False, "data_date": plan.data_date}


def home(settings: Settings, today: date | None = None, month: str | None = None) -> dict[str, Any]:
    """Home: money left this month, the overdraft, the goals and what is coming up.

    `today` is the device's date (date.today() when not given): the month's
    days left count from it, while amounts are as of the latest data. `month`
    picks another month for the budget card (design.md §6 "Month picker"): a
    past month shows its final result. Every month with bank or card data is
    listed, and the current month.
    """
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if not plan.ready:
        return _not_ready(plan)
    assert plan.data_month is not None and plan.balance is not None
    when = _when(plan, today)
    assert when is not None
    current = when.month
    outlook = _outlook(plan)
    past = {m for m in actual_months(settings) if m < current}
    future = [p.month for p in outlook.projection if p.month > current]
    months = sorted({*past, current, *future})  # calendar order, earliest first (§6)
    if month in (None, current):
        budget, _ = _budget_pace(plan, settings, when)
    elif month in past:
        budget = _final_pace(plan, settings, month)
    elif month in future:
        budget = _forecast(plan, settings, outlook, month)
    else:
        raise ValueError("no such month")
    next_month = add_months(plan.data_month, 1)
    # A forecast month lists its own known payments; otherwise what comes next.
    coming = _payments(plan, settings, month if month in future else next_month)
    return {
        "ready": True,
        "data_date": plan.data_date,
        "data_stale": bool(when and when.stale),
        "month": plan.data_month,
        "current_month": current,
        **_profile_bits(settings),
        "selected": month or current,
        "months": [{"month": m, "kind": _month_kind(m, current)} for m in months],
        "budget": budget,
        "balance": plan.balance[1],
        "balance_date": plan.balance[0],
        "overdraft_limit": plan.goals.overdraft_limit_agorot,
        "goals": _goals(plan, outlook),
        "coming": coming[:UPCOMING_LIMIT],
        **_worth_bits(settings, current),
    }


MAX_QUERY = 100


def activity(
    settings: Settings,
    months: int = 2,
    period: dict[str, str] | None = None,
    query: str = "",
    today: date | None = None,
) -> dict[str, Any]:
    """Activity: transactions grouped by day, newest first.

    Without a period: the latest `months` of data. With one (design.md §6 "Date
    filters": a preset, a month, or a custom from-to), the days in that range,
    counted from `today`. `query` keeps the rows whose merchant, note or category
    contains it (ignoring case). With a period or a query the answer also holds
    the range's totals, worked out here and never in the browser.
    """
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if plan.data_month is None:
        return _not_ready(plan)
    first = add_months(plan.data_month, 1 - max(1, months))
    span = None
    if period:
        first_day, last_day = date_range(
            period.get("preset", ""),
            today or date.today(),
            period.get("month"),
            _day(period.get("from")),
            _day(period.get("to")),
        )
        span = (first_day.isoformat(), last_day.isoformat())
        entries = ledger_between(settings, *span)
    else:
        entries = ledger(settings, first, plan.data_month)
    notes = transaction_notes(settings)
    own, renames = transaction_titles(settings)
    pending = pending_manual(settings)
    wanted = query.strip().casefold()[:MAX_QUERY]
    days: list[dict[str, Any]] = []
    out = into = count = 0
    for entry in entries:
        note = notes.get(entry.tx_hash, "")
        title = display_title(
            entry.description, entry.amount_agorot, own.get(entry.tx_hash), renames
        )
        searched = (title, entry.description, note, entry.category)  # the bank's text too
        if wanted and not any(wanted in (text or "").casefold() for text in searched):
            continue
        count += 1
        if entry.amount_agorot < 0:
            out -= entry.amount_agorot
        else:
            into += entry.amount_agorot
        if not days or days[-1]["date"] != entry.tx_date:
            days.append({"date": entry.tx_date, "spent": 0, "items": []})
        day = days[-1]
        if entry.amount_agorot < 0:
            day["spent"] -= entry.amount_agorot
        day["items"].append(
            {
                "id": entry.tx_id,
                "name": title,
                "original": entry.description if title != entry.description else None,
                "amount": entry.amount_agorot,
                "category": entry.category,
                "bucket": bucket_key(entry.bucket),
                "source": entry.source,
                "kind": entry.flow_kind,
                "tx": entry.tx_hash,
                "note": note,
                "pending": entry.tx_hash in pending,  # paid by card or bank, file not in yet
            }
        )
    answer: dict[str, Any] = {
        "ready": True,
        "data_date": plan.data_date,
        "first_month": first,
        "days": days,
    }
    if span or wanted:
        answer["range"] = {
            "from": span[0] if span else None,
            "to": span[1] if span else None,
            "out": out,
            "in": into,
            "count": count,
        }
    return answer


def _day(text: str | None) -> date | None:
    if not text:
        return None
    try:
        return date.fromisoformat(text)
    except ValueError as exc:
        raise ValueError("dates are YYYY-MM-DD") from exc


def _profile_bits(settings: Settings) -> dict[str, Any]:
    found = profile(settings)
    # The greeting's name, and whether the user's own entries can be edited here.
    return {"name": found["name"], "editable": found["editable"]}


def user_profile(settings: Settings) -> dict[str, Any]:
    """Settings > Profile: the name for the greeting, kept in the encrypted account."""
    return profile(settings)


EXPENSE_KIND = "expense"


def category_groups(
    categories: list[tuple[str, str | None, str]], expense_first: bool
) -> list[dict[str, Any]]:
    """The category picker: expense categories by bucket, then the other kinds (income,
    transfers, investments); for money that came in, the other kinds come first."""
    groups: dict[str, dict[str, Any]] = {}
    for name, bucket, kind in categories:
        key = f"bucket:{bucket}" if kind == EXPENSE_KIND else f"kind:{kind}"
        group = groups.setdefault(
            key,
            {"key": bucket_key(bucket) if kind == EXPENSE_KIND else kind,
             "bucket": bucket if kind == EXPENSE_KIND else None,
             "kind": kind, "categories": []},
        )  # fmt: skip
        group["categories"].append(name)
    return sorted(groups.values(), key=lambda g: (g["kind"] == EXPENSE_KIND) != expense_first)


ADD_SOURCES = ("cash", "other")  # always offered, after the user's cards and bank


def category_editor(settings: Settings) -> dict[str, Any]:
    """Settings > Categories (design.md §6, editor parts one and two): the spending groups
    with their budget and categories (empty groups too), then the other kinds, and the
    deleted categories. The names in each language come with the profile."""
    found = category_editor_data(settings)
    rent = "שכר דירה"
    groups: list[dict[str, Any]] = [
        {"key": bucket_key(bucket), "bucket": bucket, "kind": EXPENSE_KIND,
         "budget": found.ceilings.get(bucket), "rent": bucket == rent,
         "budget_text": amount_text(found.ceilings[bucket]) if bucket in found.ceilings else "",
         "deletable": bucket != rent and len(found.groups) > 1, "categories": []}
        for bucket in found.groups
    ]  # fmt: skip
    by_bucket = {g["bucket"]: g for g in groups}
    others: dict[str, dict[str, Any]] = {}
    for name, bucket, kind in found.categories:
        row = {"name": name, "used": name in found.used, "deletable": name not in found.fixed}
        if kind == EXPENSE_KIND and bucket in by_bucket:
            by_bucket[bucket]["categories"].append(row)
        elif kind != EXPENSE_KIND:
            others.setdefault(kind, {"key": kind, "bucket": None, "kind": kind,
                                     "categories": []})["categories"].append(row)  # fmt: skip
    return {
        "editable": found.editable,
        "groups": [*groups, *others.values()],
        "spend_groups": list(found.groups),
        "deleted": [{"name": n, "into": into} for n, into in found.deleted],
    }


def add_options(settings: Settings) -> dict[str, Any]:
    """The "+" sheet (design.md §11.2): the category picker and the sources to choose from:
    the cards and bank this device knows, then cash and other."""
    known = [s.source for s in sources_status(settings)]
    return {
        "editable": profile(settings)["editable"],
        "groups": category_groups(category_list(settings), True),
        "sources": [*known, *ADD_SOURCES],
    }


def transaction(settings: Settings, tx_hash: str) -> dict[str, Any]:
    """The transaction sheet: the row, what a merchant rule would cover, and the categories.

    Categories come grouped for the picker: expense categories by bucket, then the
    other kinds (income, transfers, investments); for money that came in, the other
    kinds come first. Raises ValueError for an unknown transaction.
    """
    found = transaction_details(settings, tx_hash)
    if found is None:
        raise ValueError("no such transaction")
    own, renames = transaction_titles(settings)
    original = found["name"]  # the bank's text, which rules and search keep using
    found["name"] = display_title(original, found["amount"], own.get(tx_hash), renames)
    found["original"] = original
    found["renamed"] = found["name"] != original
    ordered = category_groups(found.pop("categories"), found["amount"] < 0)
    return {
        **found,
        "bucket": bucket_key(found["bucket"]),
        "groups": ordered,
        "amount_text": amount_text(found["amount"]),  # for a manual transaction's edit field
    }


def categories(settings: Settings, today: date | None = None) -> dict[str, Any]:
    """Categories: this month's spending per bucket, against the budget, with its categories.

    The month is today's (see `home`); in a month the data does not reach yet
    nothing is spent so far.
    """
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if plan.data_month is None:
        return _not_ready(plan)
    when = _when(plan, today)
    assert when is not None
    budget, _ = _budget_pace(plan, settings, when)
    paces = budget["buckets"] if budget else {}
    groups: dict[str, dict[str, Any]] = {}
    spending = spend_by_category(settings, when.month) if when.has_data else ()
    if budget is not None and spending:  # installments not charged yet are still due
        saved = saved_budget(settings)
        assert saved is not None
        commitments = with_unassigned(plan.goals.commitments)
        ceilings = effective_ceilings(saved.ceilings, {}, commitments, when.month)
        later: dict[tuple[str, str], int] = {}
        for charge in _month_fixed(plan, settings, when, ceilings)[2]:
            key = (charge.bucket, charge.category)
            later[key] = later.get(key, 0) + charge.amount_agorot
        spending = tuple(
            (bucket, category, spent - later.get((bucket, category), 0))
            for bucket, category, spent in spending
        )
    for bucket, category, spent in spending:
        group = groups.setdefault(
            bucket, {"name": bucket, "key": bucket_key(bucket), "spent": 0, "categories": []}
        )
        group["spent"] += spent
        group["categories"].append({"name": category, "spent": spent})
    for bucket in paces:
        groups.setdefault(
            bucket, {"name": bucket, "key": bucket_key(bucket), "spent": 0, "categories": []}
        )
    rent = [g for g in groups.values() if g["key"] == RENT]
    rest = sorted((g for g in groups.values() if g["key"] != RENT), key=lambda g: -g["spent"])
    total = sum(max(0, g["spent"]) for g in rest)
    for group in rest:
        group["pace"] = paces.get(group["name"])
        group["share_pct"] = max(0, group["spent"]) * 100 // total if total else 0
    ahead = next((g["name"] for g in rest if g["pace"] and g["pace"]["status"] != "on_track"), None)
    return {
        "ready": True,
        "data_date": plan.data_date,
        "month": when.month,
        "data_stale": when.stale,
        "budget": budget,
        "spent": total,
        "groups": rest,
        "rent": rent[0] if rent else None,
        "open": ahead,
    }


def goals(settings: Settings) -> dict[str, Any]:
    """Goals: progress, the date each goal is reached, and what is still missing.

    The "what if" and "can I afford it" sections of the old design are left out
    until the future-items concept (design.md §9) replaces them.
    """
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if not plan.ready:
        return _not_ready(plan)
    base = _outlook(plan)
    items = plan_items(settings)
    return {
        "ready": True,
        "data_date": plan.data_date,
        "first_month": base.first_month,
        "last_month": base.projection[-1].month,
        "monthly_flow": base.base_flow_agorot,
        "balance": plan.balance[1] if plan.balance else None,
        "goals": _goals(plan, base, items["goal"]),
        "editable": items["editable"],
    }


def accounts(settings: Settings) -> dict[str, Any]:
    """Accounts and imports: each source with its import history. Counts and dates only."""
    return {
        "sources": [
            {
                "source": status.source,
                "files": status.files,
                "last_import": status.last_import,
                "newest_transaction": status.newest_transaction,
            }
            for status in sources_status(settings)
        ]
    }


def upload(settings: Settings, name: str, data: bytes) -> dict[str, Any]:
    """Import one file sent from the import sheet. Raises ValueError for a bad upload."""
    result = import_one_file(settings, name, data)
    return {
        "name": result.name,
        "status": result.status,
        "source": result.source,
        "saved": result.saved,
        "rows_seen": result.rows_seen,
        "rows_inserted": result.rows_inserted,
        "rows_duplicate": result.rows_duplicate,
        "rows_quarantined": result.rows_quarantined,
        **({"preview": _with_guesses(result.preview)} if result.preview else {}),
    }


def _with_guesses(preview: dict[str, Any]) -> dict[str, Any]:
    """The mapping step (design.md §12 item 9): each table with a first guess per column."""
    return {
        "tables": [
            {**table, "guess": guess_columns(table["headers"], table["rows"])}
            for table in preview["tables"]
        ]
    }


def receive(settings: Settings, plain: bytes) -> dict[str, Any]:
    """Merge a decrypted pack from the phone into the Mac. Counts only."""
    result = receive_plain(settings, plain, MAC)
    merged = result.merged
    return {
        "sender": result.sender,
        "exported_at": result.exported_at,
        "transactions": merged.transactions,
        "import_runs": merged.import_runs,
        "quarantine": merged.quarantine,
        "configs": list(result.configs),
    }


MAX_EDIT_BYTES = 64 * 1024


def apply_edit(settings: Settings, body: bytes) -> dict[str, Any]:
    """One edit from the app (JSON). Raises ValueError for a malformed or refused edit."""
    if len(body) > MAX_EDIT_BYTES:
        raise ValueError("the edit is too large")
    try:
        request = json.loads(body)
    except ValueError as exc:
        raise ValueError("the edit is not JSON") from exc
    if not isinstance(request, dict):
        raise ValueError("the edit must be a JSON object")
    return edit(settings, request)
