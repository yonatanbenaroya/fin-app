"""One function per screen of the web app: the numbers that screen shows, ready to draw.

Every function returns plain JSON-ready data: amounts in integer agorot,
percentages, statuses and months already worked out. The browser formats
and draws; it does no arithmetic on money. Names of buckets, categories,
and goals are passed as stable keys or as the engine's own names,
and the browser translates them.
"""

import json
from datetime import date
from typing import Any

from fin.logic import (
    ALREADY,
    DEFAULT_WINDOW_MONTHS,
    Outlook,
    Pace,
    PaceDay,
    add_months,
    build_outlook,
    date_range,
    days_in,
    effective_ceilings,
    goal_progress,
    month_pace,
    months_between,
    pace_day,
)
from fin.storage import (
    Plan,
    Settings,
    actual_month,
    actual_months,
    edit,
    import_one_file,
    ledger,
    ledger_between,
    load_plan,
    saved_budget,
    sources_status,
    spend_by_category,
    transaction_details,
    transaction_notes,
    upcoming_charges,
)
from fin.sync import MAC, receive_plain

# The budget buckets as the design names them. Buckets come from config/categories.yaml.
BUCKET_KEYS = {
    "אוכל": "food",
    "פנאי": "leisure",
    "רכב ותחבורה": "transport",
    "קבועות": "recurring",
    'בלת"מ': "unplanned",
    "שכר דירה": "rent",
}
RENT = "rent"
OTHER = "other"
UPCOMING_LIMIT = 5


def bucket_key(bucket: str | None) -> str:
    return BUCKET_KEYS.get(bucket or "", OTHER)


def _when(plan: Plan, today: date | None) -> PaceDay | None:
    """Where the month stands: today on this device, against the latest data."""
    if plan.data_date is None:
        return None
    return pace_day(date.fromisoformat(plan.data_date), today or date.today())


def _pace(p: Pace | None) -> dict[str, Any] | None:
    if p is None:
        return None
    return {
        "spent": p.spent_agorot,
        "ceiling": p.ceiling_agorot,
        "left": p.remaining_agorot,
        "days_left": p.days_left,
        "daily": p.daily_allowance_agorot,
        "spent_pct": p.spent_percent,
        "even_pct": p.even_percent,
        "status": p.status,
        "ratio_permille": p.ratio_permille,
        "level": p.level,
        "day": p.day,
        "days_in_month": p.days_in_month,
    }


def _budget_pace(
    plan: Plan, settings: Settings, when: PaceDay | None
) -> tuple[dict[str, Any] | None, Pace | None]:
    """This month's budget against spending so far, or (None, None) without a saved budget.

    Days left and the daily allowance count from today (`when`); spending is as
    of the latest data, and nothing is spent yet in a month the data does not
    reach. Rent and other declared buckets are not part of the pace; a
    commitment charged to a bucket is allowed on top of that bucket's ceiling.
    """
    saved = saved_budget(settings)
    if saved is None or when is None:
        return None, None
    month = when.month
    ceilings = effective_ceilings(saved.ceilings, {}, plan.goals.commitments, month)
    current = plan.current_month if when.has_data else None
    spent = {line.bucket: line.spent_agorot for line in current.buckets} if current else {}
    total, buckets = month_pace(ceilings, spent, when.day, when.days_in_month)
    info = {
        "month": month,
        "preview": month < saved.start_month,
        "start_month": saved.start_month,
        "total": _pace(total),
        "buckets": {bucket: _pace(p) for bucket, p in buckets.items()},
    }
    return info, total


def _final_pace(plan: Plan, settings: Settings, month: str) -> dict[str, Any] | None:
    """A past month's final result against the budget: spent, ceilings, final pace.

    Measured against today's saved budget even before its first month (user
    decision, 2026-11-17); None without a saved budget.
    """
    saved = saved_budget(settings)
    if saved is None:
        return None
    ceilings = effective_ceilings(saved.ceilings, {}, plan.goals.commitments, month)
    summary = actual_month(settings, month)
    spent = {line.bucket: line.spent_agorot for line in summary.buckets} if summary else {}
    days = days_in(int(month[:4]), int(month[5:]))
    total, buckets = month_pace(ceilings, spent, days, days)  # the whole month has gone by
    return {
        "month": month,
        "final": True,
        "preview": False,
        "start_month": saved.start_month,
        "total": _pace(total),
        "buckets": {bucket: _pace(p) for bucket, p in buckets.items()},
    }


def _month_kind(month: str, current: str) -> str:
    return "current" if month == current else "past" if month < current else "forecast"


def _payments(plan: Plan, settings: Settings, month: str) -> list[dict[str, Any]]:
    """The payments known for one month: declared fixed amounts, commitments, card charges.

    Largest first.
    """
    found = [
        {"kind": "fixed", "name": bucket, "bucket": bucket_key(bucket), "month": month,
         "amount": amount}
        for bucket, amount in plan.baseline_config.fixed.items()
    ]  # fmt: skip
    for item in plan.goals.commitments:
        if item.first_month <= month <= item.last_month:
            found.append(
                {
                    "kind": "commitment",
                    "name": item.name,
                    "bucket": bucket_key(item.bucket),
                    "month": month,
                    "amount": item.amount_agorot,
                    "number": months_between(item.first_month, month) + 1,
                    "of": months_between(item.first_month, item.last_month) + 1,
                }
            )
    after = add_months(month, -1)
    found.extend(
        {"kind": "card", "name": name, "bucket": bucket_key(bucket), "month": when,
         "amount": amount}
        for when, name, bucket, amount in upcoming_charges(settings, after)
        if when == month
    )  # fmt: skip
    found.sort(key=lambda item: -item["amount"])
    return found


def _forecast(plan: Plan, settings: Settings, outlook: Outlook, month: str) -> dict[str, Any]:
    """A future month as a forecast: no pace (design.md §6 "Month picker"). The budget's
    ceilings, the payments already known, and the free money the projection expects."""
    projected = next(p for p in outlook.projection if p.month == month)
    saved = saved_budget(settings)
    ceilings = (
        effective_ceilings(saved.ceilings, {}, plan.goals.commitments, month) if saved else {}
    )
    payments = _payments(plan, settings, month)
    return {
        "month": month,
        "forecast": True,
        "budget": sum(ceilings.values()) if saved else None,
        "buckets": ceilings,
        "payments": sum(p["amount"] for p in payments),
        "free": projected.flow_agorot,
        "balance_end": projected.balance_agorot,
    }


def _outlook(plan: Plan) -> Outlook:
    assert plan.baseline is not None and plan.balance is not None and plan.data_month is not None
    return build_outlook(
        plan.baseline,
        plan.goals,
        plan.balance[1],
        plan.data_month,
        [month.month for month in plan.window],
    )


def _goals(plan: Plan, outlook: Outlook) -> list[dict[str, Any]]:
    assert plan.balance is not None
    progress = goal_progress(outlook.statuses, plan.balance[1])
    return [
        {
            "name": status.name,
            "threshold": status.threshold_agorot,
            "reached": status.reached,
            "already": status.reached == ALREADY,
            "target_month": status.target_month,
            "dated": status.dated,
            "required_monthly": status.required_monthly_agorot,
            "minimum_required_monthly": status.minimum_required_monthly_agorot,
            "progress_pct": pct,
        }
        for status, pct in zip(outlook.statuses, progress, strict=True)
    ]


def _not_ready(plan: Plan) -> dict[str, Any]:
    return {"ready": False, "data_date": plan.data_date}


def home(settings: Settings, today: date | None = None, month: str | None = None) -> dict[str, Any]:
    """Home: money left this month, the overdraft, the goals and what is coming up.

    `today` is the device's date (date.today() when not given): the month's
    days left count from it, while amounts are as of the latest data. `month`
    picks another month for the budget card (design.md §6 "Month picker"): a
    past month shows its final result. Every month with bank or card data is
    listed, and the current month.
    """
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if not plan.ready:
        return _not_ready(plan)
    assert plan.data_month is not None and plan.balance is not None
    when = _when(plan, today)
    assert when is not None
    current = when.month
    outlook = _outlook(plan)
    past = {m for m in actual_months(settings) if m < current}
    future = [p.month for p in outlook.projection if p.month > current]
    months = sorted({*past, current, *future}, reverse=True)
    if month in (None, current):
        budget, _ = _budget_pace(plan, settings, when)
    elif month in past:
        budget = _final_pace(plan, settings, month)
    elif month in future:
        budget = _forecast(plan, settings, outlook, month)
    else:
        raise ValueError("no such month")
    next_month = add_months(plan.data_month, 1)
    # A forecast month lists its own known payments; otherwise what comes next.
    coming = _payments(plan, settings, month if month in future else next_month)
    return {
        "ready": True,
        "data_date": plan.data_date,
        "data_stale": bool(when and when.stale),
        "month": plan.data_month,
        "current_month": current,
        "selected": month or current,
        "months": [{"month": m, "kind": _month_kind(m, current)} for m in months],
        "budget": budget,
        "balance": plan.balance[1],
        "balance_date": plan.balance[0],
        "overdraft_limit": plan.goals.overdraft_limit_agorot,
        "goals": _goals(plan, outlook),
        "coming": coming[:UPCOMING_LIMIT],
    }


MAX_QUERY = 100


def activity(
    settings: Settings,
    months: int = 2,
    period: dict[str, str] | None = None,
    query: str = "",
    today: date | None = None,
) -> dict[str, Any]:
    """Activity: transactions grouped by day, newest first.

    Without a period: the latest `months` of data. With one (design.md §6 "Date
    filters": a preset, a month, or a custom from-to), the days in that range,
    counted from `today`. `query` keeps the rows whose merchant, note or category
    contains it (ignoring case). With a period or a query the answer also holds
    the range's totals, worked out here and never in the browser.
    """
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if plan.data_month is None:
        return _not_ready(plan)
    first = add_months(plan.data_month, 1 - max(1, months))
    span = None
    if period:
        first_day, last_day = date_range(
            period.get("preset", ""),
            today or date.today(),
            period.get("month"),
            _day(period.get("from")),
            _day(period.get("to")),
        )
        span = (first_day.isoformat(), last_day.isoformat())
        entries = ledger_between(settings, *span)
    else:
        entries = ledger(settings, first, plan.data_month)
    notes = transaction_notes(settings)
    wanted = query.strip().casefold()[:MAX_QUERY]
    days: list[dict[str, Any]] = []
    out = into = count = 0
    for entry in entries:
        note = notes.get(entry.tx_hash, "")
        if wanted and not any(
            wanted in (text or "").casefold() for text in (entry.description, note, entry.category)
        ):
            continue
        count += 1
        if entry.amount_agorot < 0:
            out -= entry.amount_agorot
        else:
            into += entry.amount_agorot
        if not days or days[-1]["date"] != entry.tx_date:
            days.append({"date": entry.tx_date, "spent": 0, "items": []})
        day = days[-1]
        if entry.amount_agorot < 0:
            day["spent"] -= entry.amount_agorot
        day["items"].append(
            {
                "id": entry.tx_id,
                "name": entry.description,
                "amount": entry.amount_agorot,
                "category": entry.category,
                "bucket": bucket_key(entry.bucket),
                "source": entry.source,
                "kind": entry.flow_kind,
                "tx": entry.tx_hash,
                "note": note,
            }
        )
    answer: dict[str, Any] = {
        "ready": True,
        "data_date": plan.data_date,
        "first_month": first,
        "days": days,
    }
    if span or wanted:
        answer["range"] = {
            "from": span[0] if span else None,
            "to": span[1] if span else None,
            "out": out,
            "in": into,
            "count": count,
        }
    return answer


def _day(text: str | None) -> date | None:
    if not text:
        return None
    try:
        return date.fromisoformat(text)
    except ValueError as exc:
        raise ValueError("dates are YYYY-MM-DD") from exc


EXPENSE_KIND = "expense"


def transaction(settings: Settings, tx_hash: str) -> dict[str, Any]:
    """The transaction sheet: the row, what a merchant rule would cover, and the categories.

    Categories come grouped for the picker: expense categories by bucket, then the
    other kinds (income, transfers, investments); for money that came in, the other
    kinds come first. Raises ValueError for an unknown transaction.
    """
    found = transaction_details(settings, tx_hash)
    if found is None:
        raise ValueError("no such transaction")
    groups: dict[str, dict[str, Any]] = {}
    for name, bucket, kind in found.pop("categories"):
        key = f"bucket:{bucket}" if kind == EXPENSE_KIND else f"kind:{kind}"
        group = groups.setdefault(
            key,
            {"key": bucket_key(bucket) if kind == EXPENSE_KIND else kind,
             "bucket": bucket if kind == EXPENSE_KIND else None,
             "kind": kind, "categories": []},
        )  # fmt: skip
        group["categories"].append(name)
    expense_first = found["amount"] < 0
    ordered = sorted(groups.values(), key=lambda g: (g["kind"] == EXPENSE_KIND) != expense_first)
    whole, cents = divmod(abs(found["amount"]), 100)
    amount_text = str(whole) if cents == 0 else f"{whole}.{cents:02d}"
    return {
        **found,
        "bucket": bucket_key(found["bucket"]),
        "groups": ordered,
        "amount_text": amount_text,  # for the edit field of a manual transaction
    }


def categories(settings: Settings, today: date | None = None) -> dict[str, Any]:
    """Categories: this month's spending per bucket, against the budget, with its categories.

    The month is today's (see `home`); in a month the data does not reach yet
    nothing is spent so far.
    """
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if plan.data_month is None:
        return _not_ready(plan)
    when = _when(plan, today)
    assert when is not None
    budget, _ = _budget_pace(plan, settings, when)
    paces = budget["buckets"] if budget else {}
    groups: dict[str, dict[str, Any]] = {}
    spending = spend_by_category(settings, when.month) if when.has_data else ()
    for bucket, category, spent in spending:
        group = groups.setdefault(
            bucket, {"name": bucket, "key": bucket_key(bucket), "spent": 0, "categories": []}
        )
        group["spent"] += spent
        group["categories"].append({"name": category, "spent": spent})
    for bucket in paces:
        groups.setdefault(
            bucket, {"name": bucket, "key": bucket_key(bucket), "spent": 0, "categories": []}
        )
    rent = [g for g in groups.values() if g["key"] == RENT]
    rest = sorted((g for g in groups.values() if g["key"] != RENT), key=lambda g: -g["spent"])
    total = sum(max(0, g["spent"]) for g in rest)
    for group in rest:
        group["pace"] = paces.get(group["name"])
        group["share_pct"] = max(0, group["spent"]) * 100 // total if total else 0
    ahead = next((g["name"] for g in rest if g["pace"] and g["pace"]["status"] != "on_track"), None)
    return {
        "ready": True,
        "data_date": plan.data_date,
        "month": when.month,
        "data_stale": when.stale,
        "budget": budget,
        "spent": total,
        "groups": rest,
        "rent": rent[0] if rent else None,
        "open": ahead,
    }


def goals(settings: Settings) -> dict[str, Any]:
    """Goals: progress, the date each goal is reached, and what is still missing.

    The "what if" and "can I afford it" sections of the old design are left out
    until the future-items concept (design.md §9) replaces them.
    """
    plan = load_plan(settings, DEFAULT_WINDOW_MONTHS)
    if not plan.ready:
        return _not_ready(plan)
    base = _outlook(plan)
    return {
        "ready": True,
        "data_date": plan.data_date,
        "first_month": base.first_month,
        "last_month": base.projection[-1].month,
        "monthly_flow": base.base_flow_agorot,
        "balance": plan.balance[1] if plan.balance else None,
        "goals": _goals(plan, base),
    }


def accounts(settings: Settings) -> dict[str, Any]:
    """Accounts and imports: each source with its import history. Counts and dates only."""
    return {
        "sources": [
            {
                "source": status.source,
                "files": status.files,
                "last_import": status.last_import,
                "newest_transaction": status.newest_transaction,
            }
            for status in sources_status(settings)
        ]
    }


def upload(settings: Settings, name: str, data: bytes) -> dict[str, Any]:
    """Import one file sent from the import sheet. Raises ValueError for a bad upload."""
    result = import_one_file(settings, name, data)
    return {
        "name": result.name,
        "status": result.status,
        "source": result.source,
        "saved": result.saved,
        "rows_seen": result.rows_seen,
        "rows_inserted": result.rows_inserted,
        "rows_duplicate": result.rows_duplicate,
        "rows_quarantined": result.rows_quarantined,
    }


def receive(settings: Settings, plain: bytes) -> dict[str, Any]:
    """Merge a decrypted pack from the phone into the Mac. Counts only."""
    result = receive_plain(settings, plain, MAC)
    merged = result.merged
    return {
        "sender": result.sender,
        "exported_at": result.exported_at,
        "transactions": merged.transactions,
        "import_runs": merged.import_runs,
        "quarantine": merged.quarantine,
        "configs": list(result.configs),
    }


MAX_EDIT_BYTES = 64 * 1024


def apply_edit(settings: Settings, body: bytes) -> dict[str, Any]:
    """One edit from the app (JSON). Raises ValueError for a malformed or refused edit."""
    if len(body) > MAX_EDIT_BYTES:
        raise ValueError("the edit is too large")
    try:
        request = json.loads(body)
    except ValueError as exc:
        raise ValueError("the edit is not JSON") from exc
    if not isinstance(request, dict):
        raise ValueError("the edit must be a JSON object")
    return edit(settings, request)
