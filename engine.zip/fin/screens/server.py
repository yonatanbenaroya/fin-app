"""The local web server: the static app in fin/web plus one JSON endpoint per screen.

Bound to 127.0.0.1, and it answers only requests addressed to localhost, so a
web page elsewhere cannot reach it through DNS tricks. Everything is GET except
four writes: POST /api/import, which takes a bank or card export from the import
sheet, POST /api/receive, which merges a pack from the phone (decrypted in
the browser), and POST /api/sync, which runs a sync round now, and POST /api/edit (JSON), one
edit of the settings, a category or a manual transaction. They also
require the app's own Origin and a custom header, so another site cannot send
a file to it. No request is logged, so no amount or
merchant ever reaches the terminal. The Content-Security-Policy lets the
browser load nothing from anywhere else. Nothing here can move money.
"""

import json
from collections.abc import Callable
from datetime import date
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlsplit

import fin.screens.views as views
from fin.logic import ConfigError
from fin.screens.syncer import Syncer
from fin.storage import Settings

WEB_DIR = Path(__file__).resolve().parents[1] / "web"
DEFAULT_PORT = 8765
IMPORT_PATH = "/api/import"
RECEIVE_PATH = "/api/receive"
SYNC_PATH = "/api/sync"
EDIT_PATH = "/api/edit"
IMPORT_HEADER = "X-Fin-Import"
MAX_IMPORT_BYTES = 20 * 1024 * 1024
LOCAL_HOSTS = frozenset({"localhost", "127.0.0.1"})
CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".webmanifest": "application/manifest+json",
    ".woff2": "font/woff2",
}
SECURITY_HEADERS = {
    "Content-Security-Policy": (
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';"
        " img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none';"
        " base-uri 'none'; frame-ancestors 'none'; form-action 'none'"
    ),
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
}


def _today(query: dict[str, list[str]]) -> date:
    """The browser's own date (`?today=YYYY-MM-DD`), else this Mac's."""
    given = query.get("today", [""])[0]
    if not given:
        return date.today()
    try:
        return date.fromisoformat(given)
    except ValueError as exc:
        raise ValueError("today must be YYYY-MM-DD") from exc


def _routes(settings: Settings) -> dict[str, Callable[[dict[str, list[str]]], Any]]:
    def activity(query: dict[str, list[str]]) -> Any:
        months = query.get("months", ["2"])[0]
        if not months.isdigit() or not 1 <= int(months) <= 24:
            raise ValueError("months must be between 1 and 24")
        one = {key: values[0] for key, values in query.items() if values}
        period = {k: one[k] for k in ("preset", "month", "from", "to") if k in one}
        return views.activity(
            settings, int(months), period or None, one.get("q", ""), _today(query)
        )

    return {
        "home": lambda query: views.home(
            settings, _today(query), query.get("month", [None])[0] or None
        ),
        "activity": activity,
        "categories": lambda query: views.categories(settings, _today(query)),
        "transaction": lambda query: views.transaction(settings, query.get("tx", [""])[0]),
        "goals": lambda _: views.goals(settings),
        "accounts": lambda _: views.accounts(settings),
    }


def make_handler(
    settings: Settings, web_dir: Path = WEB_DIR, syncer: Syncer | None = None
) -> type[BaseHTTPRequestHandler]:
    """Build the request handler for one configuration."""
    routes = _routes(settings)
    routes["sync"] = lambda _: syncer.status() if syncer else {"configured": False}
    root = web_dir.resolve()

    class Handler(BaseHTTPRequestHandler):
        server_version = "fin"
        sys_version = ""

        def log_message(self, format: str, *args: Any) -> None:  # noqa: A002 - base signature
            """Write nothing: request lines can carry amounts in their query."""

        def _local(self) -> bool:
            host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]")
            if host in LOCAL_HOSTS:
                return True
            self._send(HTTPStatus.FORBIDDEN, b"forbidden", "text/plain; charset=utf-8")
            return False

        def do_GET(self) -> None:  # noqa: N802 - name fixed by http.server
            if not self._local():
                return
            url = urlsplit(self.path)
            if url.path.startswith("/api/"):
                self._api(url.path.removeprefix("/api/"), parse_qs(url.query))
            else:
                self._static(url.path)

        def _not_allowed(self) -> None:
            self._send(HTTPStatus.METHOD_NOT_ALLOWED, b"read only", "text/plain; charset=utf-8")

        do_PUT = do_PATCH = do_DELETE = _not_allowed  # noqa: N815

        def do_POST(self) -> None:  # noqa: N802 - name fixed by http.server
            """The writes: import a file, merge a pack from the phone, or sync now."""
            if not self._local():
                return
            path = urlsplit(self.path).path
            if path not in (IMPORT_PATH, RECEIVE_PATH, SYNC_PATH, EDIT_PATH):
                self._not_allowed()
                return
            if self.headers.get("Origin") != f"http://{self.headers.get('Host')}":
                self._json(HTTPStatus.FORBIDDEN, {"error": "not from this app"})
                return
            if self.headers.get(IMPORT_HEADER) != "1":
                self._json(HTTPStatus.FORBIDDEN, {"error": "not from this app"})
                return
            wanted = "application/json" if path == EDIT_PATH else "application/octet-stream"
            if self.headers.get("Content-Type") != wanted:
                self._json(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, {"error": "send the file as is"})
                return
            length = self.headers.get("Content-Length", "")
            if not length.isdigit() or int(length) > MAX_IMPORT_BYTES:
                self.close_connection = True
                self._json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, {"error": "file too large"})
                return
            name = unquote(self.headers.get("X-File-Name", ""))
            data = self.rfile.read(int(length))
            try:
                if path == EDIT_PATH:
                    self._json(HTTPStatus.OK, views.apply_edit(settings, data))
                    if syncer:
                        syncer.nudge()
                elif path == SYNC_PATH:
                    status = syncer.run_now() if syncer else {"configured": False}
                    self._json(HTTPStatus.OK, status)
                elif path == RECEIVE_PATH:
                    self._json(HTTPStatus.OK, views.receive(settings, data))
                    if syncer:
                        syncer.nudge()
                else:
                    self._json(HTTPStatus.OK, views.upload(settings, name, data))
                    if syncer:
                        syncer.nudge()
            except ValueError as exc:
                self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            except ConfigError as exc:
                self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
            except Exception:  # noqa: BLE001 - never echo internals; nothing is logged
                self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "internal error"})

        def _api(self, name: str, query: dict[str, list[str]]) -> None:
            route = routes.get(name)
            if route is None:
                self._json(HTTPStatus.NOT_FOUND, {"error": "no such screen"})
                return
            try:
                self._json(HTTPStatus.OK, route(query))
            except ConfigError as exc:
                self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
            except ValueError as exc:
                self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            except Exception:  # noqa: BLE001 - never echo internals; nothing is logged
                self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "internal error"})

        def _static(self, path: str) -> None:
            target = (root / (path.lstrip("/") or "index.html")).resolve()
            content_type = CONTENT_TYPES.get(target.suffix)
            if not target.is_relative_to(root) or not target.is_file() or content_type is None:
                self._send(HTTPStatus.NOT_FOUND, b"not found", "text/plain; charset=utf-8")
                return
            self._send(HTTPStatus.OK, target.read_bytes(), content_type, cache="no-cache")

        def _json(self, status: HTTPStatus, data: Any) -> None:
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self._send(status, body, "application/json; charset=utf-8")

        def _send(
            self, status: HTTPStatus, body: bytes, content_type: str, cache: str = "no-store"
        ) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", cache)
            for name, value in SECURITY_HEADERS.items():
                self.send_header(name, value)
            self.end_headers()
            self.wfile.write(body)

    return Handler


def make_server(
    settings: Settings, port: int = DEFAULT_PORT, syncer: Syncer | None = None
) -> ThreadingHTTPServer:
    """A server on 127.0.0.1 only; port 0 picks a free port."""
    return ThreadingHTTPServer(("127.0.0.1", port), make_handler(settings, syncer=syncer))
