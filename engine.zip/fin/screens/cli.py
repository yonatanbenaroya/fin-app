"""Command line entry point: `fin <command>`."""

import argparse
import calendar
import getpass
import re
import sys
from collections.abc import Sequence
from pathlib import Path

import yaml

from fin import __version__
from fin.logic import (
    DEFAULT_TARGET_SURPLUS_AGOROT,
    DEFAULT_WINDOW_MONTHS,
    Budget,
    BudgetConfig,
    ConfigError,
    ResolvedScenario,
    add_months,
    budget_from_ceilings,
    build_outlook,
    effective_ceilings,
    propose_budget,
    resolve_scenario,
    track_month,
)
from fin.screens.build_web import build_web
from fin.screens.report.baseline_text import render_baseline
from fin.screens.report.budget_text import BudgetReport, render_budget
from fin.screens.report.goals_text import GoalsReport, render_goals
from fin.screens.report.monthly_text import render_monthly_report
from fin.screens.report.scenarios_text import render_scenarios
from fin.screens.server import DEFAULT_PORT, make_server
from fin.screens.syncer import Syncer
from fin.storage import (
    ACTUAL,
    Plan,
    categorize,
    import_inbox,
    import_legacy,
    import_settings,
    load_baseline,
    load_config,
    load_plan,
    report_data,
    save_budget,
    saved_budget,
    settings_documents,
)
from fin.sync import (
    MAC,
    Account,
    AccountError,
    Keychain,
    RelayError,
    build_plain,
    describe,
    receive_plain,
    resolve_passphrase,
    seal,
    store_in_keychain,
    unseal,
)

NOT_IMPLEMENTED_EXIT_CODE = 2
CONFIG_FILE_NAMES = {
    "rules": "rules.private.yaml",
    "baseline": "baseline.private.yaml",
    "goals": "goals.private.yaml",
    "scenarios": "scenarios.private.yaml",
    "budget": "budget.private.yaml",
}
ERROR_EXIT_CODE = 1
DEFAULT_REPORT_SOURCE = ACTUAL
_MONTH = re.compile(r"\d{4}-(0[1-9]|1[0-2])")


def _month(value: str) -> str:
    """Validate a YYYY-MM command line argument."""
    if not _MONTH.fullmatch(value):
        raise argparse.ArgumentTypeError(f"expected YYYY-MM, got {value!r}")
    return value


def _window(value: str) -> int:
    """Validate a positive number of months."""
    if not value.isdigit() or int(value) < 1:
        raise argparse.ArgumentTypeError(f"expected a positive number of months, got {value!r}")
    return int(value)


def build_parser() -> argparse.ArgumentParser:
    """Build the `fin` argument parser with all planned subcommands."""
    parser = argparse.ArgumentParser(
        prog="fin", description="Local-first personal finance system (read-only)."
    )
    parser.add_argument("--version", action="version", version=f"fin {__version__}")
    parser.add_argument("--config", type=Path, help="path to settings YAML")
    commands = parser.add_subparsers(dest="command", required=True)
    ingest = commands.add_parser("ingest", help="import new files from the inbox")
    sources = ingest.add_subparsers(dest="source")
    legacy = sources.add_parser("legacy", help="import the legacy budget workbook")
    legacy.add_argument("--file", type=Path, help="workbook path (default: from settings)")
    report = commands.add_parser("report", help="show the monthly report")
    report.add_argument("--from", dest="start", type=_month, help="first month, YYYY-MM")
    report.add_argument("--to", dest="end", type=_month, help="last month, YYYY-MM")
    report.add_argument(
        "--source",
        default=DEFAULT_REPORT_SOURCE,
        help="ledger: actual (bank + cards, default), legacy_excel, hapoalim, max or cal",
    )
    categorize = commands.add_parser("categorize", help="apply the categorization rules")
    categorize.add_argument(
        "--list-uncategorized",
        action="store_true",
        help="print the merchants that no rule covers, most frequent first",
    )
    baseline = commands.add_parser("baseline", help="show the current-state monthly baseline")
    baseline.add_argument(
        "--months",
        type=_window,
        default=DEFAULT_WINDOW_MONTHS,
        help=f"full months to average (default {DEFAULT_WINDOW_MONTHS})",
    )
    goals = commands.add_parser("goals", help="project the balance and show progress toward goals")
    goals.add_argument(
        "--months",
        type=_window,
        default=DEFAULT_WINDOW_MONTHS,
        help=f"full months the baseline averages (default {DEFAULT_WINDOW_MONTHS})",
    )
    goals.add_argument("--scenario", help="project a what-if scenario by name (see fin what-if)")
    what_if = commands.add_parser("what-if", help="compare what-if scenarios with the baseline")
    what_if.add_argument(
        "--months",
        type=_window,
        default=DEFAULT_WINDOW_MONTHS,
        help=f"full months the baseline averages (default {DEFAULT_WINDOW_MONTHS})",
    )
    budget = commands.add_parser("budget", help="show the monthly budget per bucket")
    budget.add_argument(
        "--months",
        type=_window,
        default=DEFAULT_WINDOW_MONTHS,
        help=f"full months the baseline averages (default {DEFAULT_WINDOW_MONTHS})",
    )
    budget.add_argument(
        "--save", action="store_true", help="save the proposed ceilings as the budget"
    )
    web = commands.add_parser("web", help="open the app in the browser (this Mac only)")
    web.add_argument(
        "--port", type=int, default=DEFAULT_PORT, help=f"port (default {DEFAULT_PORT})"
    )
    pack = commands.add_parser("pack", help="move the ledger to or from the phone (encrypted)")
    pack_commands = pack.add_subparsers(dest="pack_command", required=True)
    pack_export = pack_commands.add_parser("export", help="write an encrypted file for the phone")
    pack_export.add_argument("file", type=Path, help="the .finpack file to create")
    pack_import = pack_commands.add_parser("import", help="merge an encrypted file from the phone")
    pack_import.add_argument("file", type=Path, help="the .finpack file to read")
    pack_commands.add_parser("passphrase", help="store the transfer passphrase in the Keychain")
    config = commands.add_parser("config", help="the private settings: change log and YAML files")
    config_commands = config.add_subparsers(dest="config_command", required=True)
    config_commands.add_parser(
        "import", help="take the private YAML files into the change log (only the differences)"
    )
    config_export = config_commands.add_parser(
        "export", help="write the settings as YAML files into a new folder"
    )
    config_export.add_argument("folder", type=Path, help="a folder that does not exist yet")
    sync = commands.add_parser("sync", help="the encrypted account: sign in and sync")
    sync_commands = sync.add_subparsers(dest="sync_command", required=True)
    sync_commands.add_parser("create", help="set up the account once (moves the settings in)")
    sync_commands.add_parser("login", help="sign in on this Mac with the account password")
    sync_commands.add_parser("logout", help="forget the session and the key on this Mac")
    sync_commands.add_parser("now", help="run one sync round")
    sync_commands.add_parser("status", help="show when the last round ran")
    sync_commands.add_parser("password", help="set a new account password (no old one needed)")
    sync_commands.add_parser("recovery-code", help="replace the recovery code (shown once)")
    build = commands.add_parser("build-web", help="build the phone app (offline bundle)")
    build.add_argument("--out", type=Path, default=Path("dist/web"), help="output folder")
    afford = commands.add_parser("can-i-afford", help="check a purchase against the plan")
    afford.add_argument("amount", help="purchase amount in shekels")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the CLI and return a process exit code."""
    args = build_parser().parse_args(argv)
    if args.command == "ingest" and args.source == "legacy":
        return _ingest_legacy(args.config, args.file)
    if args.command == "report":
        return _report(args.config, args.start, args.end, args.source)
    if args.command == "ingest":
        return _ingest_inbox(args.config)
    if args.command == "baseline":
        return _baseline(args.config, args.months)
    if args.command == "goals":
        return _goals(args.config, args.months, args.scenario)
    if args.command == "budget":
        return _budget(args.config, args.months, args.save)
    if args.command == "pack":
        return _pack(args.config, args.pack_command, getattr(args, "file", None))
    if args.command == "config":
        return _config(args.config, args.config_command, getattr(args, "folder", None))
    if args.command == "sync":
        return _sync(args.config, args.sync_command)
    if args.command == "build-web":
        return _build_web(args.config, args.out)
    if args.command == "web":
        return _web(args.config, args.port)
    if args.command == "what-if":
        return _what_if(args.config, args.months)
    if args.command == "categorize":
        return _categorize_command(args.config, args.list_uncategorized)
    print(f"fin {args.command}: not implemented yet", file=sys.stderr)
    return NOT_IMPLEMENTED_EXIT_CODE


def _report(config_path: Path | None, start: str | None, end: str | None, source: str) -> int:
    """Print the monthly summary: aggregates only, never single transactions."""
    try:
        settings = load_config(config_path)
    except ConfigError as exc:
        print(f"fin report: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    if start and end and start > end:
        print("fin report: --from must not be after --to", file=sys.stderr)
        return ERROR_EXIT_CODE
    try:
        summary, income_reference = report_data(settings, start, end, source)
    except ConfigError as exc:
        print(f"fin report: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(render_monthly_report(summary, income_reference))
    return 0


def _baseline(config_path: Path | None, months: int) -> int:
    """Print the current-state baseline: aggregates only, never single transactions."""
    try:
        baseline = load_baseline(load_config(config_path), months)
    except ConfigError as exc:
        print(f"fin baseline: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(render_baseline(baseline))
    return 0


def _goals(config_path: Path | None, months: int, scenario_name: str | None) -> int:
    """Print the balance projection and goal progress: aggregates only."""
    try:
        plan = load_plan(load_config(config_path), months)
        if not plan.ready:
            print(render_goals(None))
            return 0
        resolved = None
        if scenario_name is not None:
            found = [s for s in plan.scenarios if s.name == scenario_name]
            if not found:
                names = ", ".join(repr(s.name) for s in plan.scenarios) or "none defined"
                raise ConfigError(f"unknown scenario {scenario_name!r} (available: {names})")
            resolved = resolve_scenario(found[0], plan.baseline)
        report = _goals_report(plan, resolved)
    except ConfigError as exc:
        print(f"fin goals: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(render_goals(report))
    return 0


def _budget(config_path: Path | None, months: int, save: bool) -> int:
    """Print the budget per bucket and the month so far: aggregates only."""
    try:
        plan = load_plan(load_config(config_path), months)
        if plan.baseline is None or plan.data_month is None:
            print(render_budget(None))
            return 0
        saved = saved_budget(plan.settings)
        if save and saved is not None:
            raise ConfigError("a budget is already saved; edit it, or delete it first")
        month = add_months(plan.data_month, 1)
        commitments = plan.goals.commitments
        if saved is None:
            budget = propose_budget(plan.baseline, commitments, month)
            if save:
                ceilings = {line.bucket: line.ceiling_agorot for line in budget.lines}
                saved = BudgetConfig(month, DEFAULT_TARGET_SURPLUS_AGOROT, ceilings)
                save_budget(plan.settings, saved)
        else:
            month = max(month, saved.start_month)
            budget = budget_from_ceilings(
                plan.baseline, commitments, month, saved.target_surplus_agorot, saved.ceilings
            )
        report = _budget_report(plan, budget, saved)
    except ConfigError as exc:
        print(f"fin budget: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(render_budget(report))
    return 0


def _budget_report(plan: Plan, budget: Budget, saved: BudgetConfig | None) -> BudgetReport:
    """Add the commitments that end and, once the budget has started, the month so far."""
    active = {name for name, _ in budget.commitments}
    endings = tuple(
        (c.name, c.last_month, add_months(c.last_month, 1))
        for c in plan.goals.commitments
        if c.name in active and c.first_month <= budget.month <= c.last_month
    )
    tracking: tuple = ()
    days_left = None
    current = plan.current_month
    if saved and current and plan.data_date and current.month >= saved.start_month:
        ceilings = effective_ceilings(
            saved.ceilings, plan.baseline_config.fixed, plan.goals.commitments, current.month
        )
        tracking = track_month(ceilings, current)
        year, month_number, day = (int(part) for part in plan.data_date.split("-"))
        days_left = calendar.monthrange(year, month_number)[1] - day
    return BudgetReport(
        budget=budget,
        saved=saved is not None,
        start_month=saved.start_month if saved else budget.month,
        endings=endings,
        tracking=tracking,
        tracking_month=current.month if tracking and current else None,
        data_date=plan.data_date,
        days_left=days_left,
    )


def _what_if(config_path: Path | None, months: int) -> int:
    """Print every scenario next to the current baseline: aggregates only."""
    try:
        plan = load_plan(load_config(config_path), months)
        if not plan.ready:
            print(render_scenarios(None, ()))
            return 0
        resolved = [resolve_scenario(scenario, plan.baseline) for scenario in plan.scenarios]
        base = _goals_report(plan)
        reports = [(scenario, _goals_report(plan, scenario)) for scenario in resolved]
    except ConfigError as exc:
        print(f"fin what-if: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(render_scenarios(base, reports))
    return 0


def _goals_report(plan: Plan, scenario: ResolvedScenario | None = None) -> GoalsReport:
    """Project from the month after the newest data month and evaluate the goals."""
    assert plan.baseline is not None and plan.balance is not None and plan.data_month is not None
    balance_date, start_balance = plan.balance
    outlook = build_outlook(
        plan.baseline,
        plan.goals,
        start_balance,
        plan.data_month,
        [month.month for month in plan.window],
        scenario.adjustments if scenario else (),
        scenario.events if scenario else (),
    )
    return GoalsReport(
        balance_date=balance_date,
        start_balance_agorot=start_balance,
        base_flow_agorot=outlook.base_flow_agorot,
        window_first_month=plan.baseline.first_month,
        window_last_month=plan.baseline.last_month,
        projection=outlook.projection,
        statuses=outlook.statuses,
        overdraft_limit_agorot=plan.goals.overdraft_limit_agorot,
        limit_breach_month=outlook.limit_breach_month,
        scenario=scenario.name if scenario else None,
    )


def _ingest_legacy(config_path: Path | None, file_path: Path | None) -> int:
    """Import the legacy workbook and print counts only, never row contents."""
    try:
        settings = load_config(config_path)
        summary = import_legacy(settings, file_path)
    except ConfigError as exc:
        print(f"fin ingest legacy: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    except FileNotFoundError as exc:
        print(f"fin ingest legacy: workbook not found: {exc.args[0]}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(f"transaction rows seen:    {summary.rows_seen}")
    print(f"  inserted:               {summary.rows_inserted}")
    print(f"  already imported:       {summary.rows_duplicate}")
    print(f"quarantined rows (all):   {summary.rows_quarantined}")
    print(f"income months:            {summary.incomes}")
    print(f"budget rows:              {summary.budgets}")
    print(f"skipped sheets:           {summary.skipped_sheets}")
    if summary.share_exceeds_total:
        print(f"warning: my share exceeds total in {summary.share_exceeds_total} rows")
    if summary.rows_stale:
        print(f"warning: {summary.rows_stale} stored rows no longer match the workbook")
    return 0


def _ingest_inbox(config_path: Path | None) -> int:
    """Import every recognized bank or card export in the inbox; print counts only."""
    try:
        result = import_inbox(load_config(config_path))
    except ConfigError as exc:
        print(f"fin ingest: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    for source, counts in sorted(result.totals.items()):
        files_count, seen, inserted, duplicate, quarantined, skipped = counts
        print(f"{source}: {files_count} file(s), control check passed")
        print(f"  rows seen:              {seen}")
        print(f"  inserted:               {inserted}")
        print(f"  already imported:       {duplicate}")
        print(f"  quarantined:            {quarantined}")
        print(f"  skipped (not charged):  {skipped}")
    categorized = result.categorized
    print(f"unrecognized files:       {result.unrecognized}")
    print(f"categorized:              {categorized.total - categorized.uncategorized}")
    print(f"not categorized:          {categorized.uncategorized}")
    if result.rejected:
        print(f"REJECTED files (failed control check, nothing imported): {result.rejected}")
        return ERROR_EXIT_CODE
    return 0


def _categorize_command(config_path: Path | None, list_uncategorized: bool) -> int:
    """Categorize and print coverage counts; optionally list uncovered merchants."""
    try:
        summary, uncovered = categorize(load_config(config_path))
    except ConfigError as exc:
        print(f"fin categorize: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(f"transactions:             {summary.total}")
    for (source, layer), count in sorted(summary.by_layer.items()):
        print(f"  {source:<10} {layer:<13} {count}")
    print(f"card bills matched:       {summary.card_payments_matched}")
    print(f"card bills without detail:{summary.card_payments_unmatched:>2}")
    print(f"not categorized:          {summary.uncategorized}")
    if list_uncategorized:
        for source, description, count in uncovered:
            print(f"  {count:3d}  {source:<9} {description}")
    return 0


def _pack(config_path: Path | None, command: str, file: Path | None) -> int:
    """Encrypted transfer files for the phone. Prints counts, never rows."""
    if command == "passphrase":
        if store_in_keychain():
            print("fin pack: passphrase stored in the Keychain")
            return 0
        print("fin pack: could not store the passphrase", file=sys.stderr)
        return ERROR_EXIT_CODE
    assert file is not None
    try:
        settings = load_config(config_path)
        if command == "export":
            if file.exists():
                raise ValueError(f"{file} already exists")
            passphrase = resolve_passphrase(confirm=True)
            file.write_bytes(seal(build_plain(settings, MAC), passphrase))
            print(f"fin pack: wrote {file}. Send it to the phone (AirDrop or iCloud Drive).")
            return 0
        passphrase = resolve_passphrase(confirm=False)
        received = receive_plain(settings, unseal(file.read_bytes(), passphrase), MAC)
    except (ConfigError, ValueError, OSError) as exc:
        print(f"fin pack: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    merged = received.merged
    print(f"fin pack: from the {received.sender}, exported {received.exported_at}")
    print(f"  new transactions:       {merged.transactions}")
    print(f"  new import runs:        {merged.import_runs}")
    print(f"  new quarantined rows:   {merged.quarantine}")
    return 0


def _config(config_path: Path | None, command: str, folder: Path | None) -> int:
    """Move the private settings into the change log, or write them out as YAML. Counts only."""
    try:
        settings = load_config(config_path)
        if command == "import":
            made = import_settings(settings)
            print(f"fin config: {made} changes recorded; settings are now read from the change log")
            return 0
        assert folder is not None
        if folder.exists():
            raise ValueError(f"{folder} already exists")
        documents = settings_documents(settings)
        folder.mkdir(parents=True)
        written = 0
        for name, raw in documents.items():
            if raw is not None:
                text = yaml.safe_dump(raw, allow_unicode=True, sort_keys=False)
                (folder / CONFIG_FILE_NAMES[name]).write_text(text, encoding="utf-8")
                written += 1
    except (ConfigError, ValueError, OSError) as exc:
        print(f"fin config: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(f"fin config: wrote {written} files to {folder}")
    return 0


def _new_password() -> str:
    first = getpass.getpass("New account password (16+ characters or 4+ words): ")
    if getpass.getpass("Again: ") != first:
        raise AccountError("the two passwords differ")
    return first


def _show_code(code: str) -> None:
    print("  Recovery code (shown once; keep it in a password manager or on paper):")
    print(f"    {code}")
    print("  Without the password, the code or a signed-in device, the data cannot be opened.")


def _sync(config_path: Path | None, command: str) -> int:
    """The encrypted account from the terminal. Prints counts and times, never rows."""
    try:
        settings = load_config(config_path)
        account = Account(settings, Keychain())
    except (ConfigError, RelayError) as exc:
        print(f"fin sync: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    if command == "logout":
        account.sign_out()
        print("fin sync: signed out on this Mac (the key is removed from the Keychain)")
        return 0
    if command == "status":
        state = account.state()
        print(f"fin sync: {'signed in' if account.signed_in() else 'not signed in'}")
        print(f"  last round: {state.get('last_sync') or 'never'}")
        print(f"  new transactions in it:     {state.get('last_transactions', 0)}")
        print(f"  settings changes in it:     {state.get('last_changes', 0)}")
        return 0
    try:
        if command == "create":
            email = input("Email: ").strip()
            first = getpass.getpass("Temporary password (from the relay's dashboard): ")
            code = account.create(email, first, _new_password())
            print("fin sync: account created; the settings now live in the encrypted account")
            _show_code(code)
        elif command == "login":
            email = input("Email: ").strip()
            account.sign_in(email, getpass.getpass("Account password: "))
            print("fin sync: signed in; the session and the data key are in the Keychain")
        elif command == "password":
            account.change_password(_new_password())
            print("fin sync: password changed; other devices stay signed in")
            return 0
        elif command == "recovery-code":
            _show_code(account.new_recovery_code())
            return 0
        result = account.sync()
    except (ValueError, RelayError, OSError) as exc:
        print(f"fin sync: {describe(exc)}: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(f"fin sync: done at {result.at}")
    print(f"  new transactions from other devices: {result.transactions}")
    print(f"  settings changes from other devices: {result.changes}")
    print(f"  sent this Mac's changes:             {'yes' if result.sent else 'no change'}")
    return 0


def _build_web(config_path: Path | None, out: Path) -> int:
    """Build the phone bundle and print what was built (file names, never data)."""
    try:
        settings = load_config(config_path)
        sync = (settings.sync_url, settings.sync_anon_key) if settings.sync_url else None
        summary = build_web(out, sync=sync)  # type: ignore[arg-type]
    except (FileNotFoundError, ValueError, ConfigError) as exc:
        print(f"fin build-web: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    megabytes = summary.size_bytes / 1_000_000
    print(f"fin build-web: {summary.files} files, {megabytes:.1f} MB, version {summary.version}")
    print(f"  in {summary.out}")
    print(f"  sync relay: {'included' if sync else 'none (no sync section in settings)'}")
    return 0


def _web(config_path: Path | None, port: int) -> int:
    """Serve the web app on this Mac until interrupted."""
    try:
        settings = load_config(config_path)
        syncer = Syncer(Account(settings, Keychain())) if settings.sync_url else None
        server = make_server(settings, port, syncer)
    except ConfigError as exc:
        print(f"fin web: {exc}", file=sys.stderr)
        return ERROR_EXIT_CODE
    except OSError as exc:
        print(f"fin web: cannot listen on port {port}: {exc.strerror}", file=sys.stderr)
        return ERROR_EXIT_CODE
    print(f"fin web: open http://localhost:{server.server_address[1]} (Ctrl+C to stop)")
    if syncer:
        syncer.start()
        print("fin web: syncing with the phone every 5 minutes")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
