"""The engine as the iPhone runs it: the same view functions, called inside Pyodide.

The browser keeps the database and the private configs in its own storage and
puts them into a folder in Pyodide's memory before calling in here. Everything
goes through `fin.screens.views`, exactly as the Mac's local server does, so
both devices show the same numbers. Answers are JSON text.
"""

import json
from datetime import date
from pathlib import Path
from typing import Any

import fin.screens.views as views
from fin.logic import ConfigError, password_problem
from fin.storage import (
    Outgoing,
    load_config,
    log_apply,
    log_mark_pushed,
    log_outgoing,
    log_position,
)
from fin.sync import PHONE, outgoing, receive_plain

SETTINGS_FILE = "settings.yaml"
DB_FILE = "fin.db"
INBOX_DIR = "inbox"
_SETTINGS = (
    "paths:\n  db: {db}\n  inbox: {inbox}\n  legacy_excel: {missing}\n"
    "models:\n  categorize: none\n  review: none\n"
)


def prepare(data_dir: str) -> None:
    """Write the settings file for a data folder, once. The private configs sit next to it."""
    folder = Path(data_dir)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / INBOX_DIR).mkdir(exist_ok=True)
    settings = folder / SETTINGS_FILE
    if not settings.exists():
        settings.write_text(
            _SETTINGS.format(
                db=folder / DB_FILE, inbox=folder / INBOX_DIR, missing=folder / "none.xlsx"
            ),
            encoding="utf-8",
        )


def _settings(data_dir: str):  # noqa: ANN202 - Settings, through the storage door
    return load_config(Path(data_dir) / SETTINGS_FILE)


def _answer(work: Any) -> str:
    try:
        return json.dumps({"ok": True, "data": work()}, ensure_ascii=False)
    except (ValueError, ConfigError) as exc:
        return json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False)


def call(data_dir: str, screen: str, months: int = 2, today: str = "", tx: str = "") -> str:
    """The data of one screen as JSON text. `today` is the phone's date (YYYY-MM-DD).

    The answer is {"ok": true, "data": ...} or {"ok": false, "error": ...}.
    """
    try:
        day = date.fromisoformat(today) if today else None
    except ValueError:
        return json.dumps({"ok": False, "error": "today must be YYYY-MM-DD"})
    screens = {
        "home": lambda s: views.home(s, day),
        "activity": lambda s: views.activity(s, months),
        "categories": lambda s: views.categories(s, day),
        "transaction": lambda s: views.transaction(s, tx),
        "goals": lambda s: views.goals(s),
        "accounts": lambda s: views.accounts(s),
    }
    if screen not in screens:
        return json.dumps({"ok": False, "error": "no such screen"})
    return _answer(lambda: screens[screen](_settings(data_dir)))


def import_file(data_dir: str, name: str, data: bytes) -> str:
    """Import one bank or card export into this device's copy. Counts only."""
    return _answer(lambda: views.upload(_settings(data_dir), name, bytes(data)))


def import_path(data_dir: str, name: str, path: str) -> str:
    """Import a file the browser has written into Pyodide's memory, then remove it."""
    source = Path(path)
    try:
        return import_file(data_dir, name, source.read_bytes())
    finally:
        source.unlink(missing_ok=True)


def _received(result: Any) -> dict[str, Any]:
    merged = result.merged
    return {
        "sender": result.sender,
        "exported_at": result.exported_at,
        "transactions": merged.transactions,
        "import_runs": merged.import_runs,
        "quarantine": merged.quarantine,
        "configs": list(result.configs),
    }


def export_plain(data_dir: str, out_path: str) -> str:
    """Write this phone's unencrypted pack for the browser to encrypt and send to the Mac."""

    def work() -> dict[str, Any]:
        out = outgoing(_settings(data_dir), PHONE)
        Path(out_path).write_bytes(out.plain)
        return {"bytes": len(out.plain), "digest": out.digest}

    return _answer(work)


def receive_path(data_dir: str, path: str) -> str:
    """Merge a pack the browser has decrypted into Pyodide's memory, then remove it."""
    source = Path(path)

    def work() -> dict[str, Any]:
        try:
            plain = source.read_bytes()
        finally:
            source.unlink(missing_ok=True)
        return _received(receive_plain(_settings(data_dir), plain, PHONE))

    return _answer(work)


# ---- the encrypted account's shared log (the browser seals, sends and fetches)


def log_out(data_dir: str) -> str:
    """This phone's new changes and facts as one plain entry, and what to mark once sent."""

    def work() -> dict[str, Any]:
        out = log_outgoing(_settings(data_dir))
        marks = {
            "change_ids": list(out.change_ids),
            "runs": [list(run) for run in out.runs],
            "other_digest": out.other_digest,
        }
        return {"entry": out.entry, "marks": marks, "position": log_position(_settings(data_dir))}

    return _answer(work)


def log_mark(data_dir: str, marks_json: str) -> str:
    """Remember that the entry from `log_out` reached the relay."""

    def work() -> dict[str, Any]:
        marks = json.loads(marks_json)
        sent = Outgoing(
            None,
            tuple(marks["change_ids"]),
            tuple(tuple(run) for run in marks["runs"]),
            marks["other_digest"],
        )
        log_mark_pushed(_settings(data_dir), sent)
        return {}

    return _answer(work)


def log_take(data_dir: str, path: str, seq: int) -> str:
    """Apply entries the browser has opened (a JSON list in Pyodide's memory), then remove it."""
    source = Path(path)

    def work() -> dict[str, Any]:
        try:
            entries = json.loads(source.read_text(encoding="utf-8"))
        finally:
            source.unlink(missing_ok=True)
        applied = log_apply(_settings(data_dir), entries, int(seq))
        return {"changes": applied.changes, "transactions": applied.merged.transactions}

    return _answer(work)


def log_where(data_dir: str) -> str:
    """The last log position this phone has taken in."""
    return _answer(lambda: {"position": log_position(_settings(data_dir))})


def password_check(password: str) -> str:
    """Why a new account password is too weak (a short code), or null when it is fine."""
    return _answer(lambda: {"problem": password_problem(password)})


def edit(data_dir: str, request_json: str) -> str:
    """One edit from the app, as on the Mac (views.apply_edit). Counts and ids only."""
    return _answer(lambda: views.apply_edit(_settings(data_dir), request_json.encode("utf-8")))
