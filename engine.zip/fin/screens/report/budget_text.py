"""Plain-text rendering of the monthly budget. Formatting only, no math."""

from dataclasses import dataclass

from fin.logic import Budget, TrackLine, format_ils

_WIDTH = 13


@dataclass(frozen=True)
class BudgetReport:
    budget: Budget
    # True when the ceilings come from the saved file, False for a fresh proposal.
    saved: bool
    start_month: str
    # Commitments active in the budget month: (name, last month, month after it).
    endings: tuple[tuple[str, str, str], ...] = ()
    # Spending so far in the newest data month; empty before the budget starts.
    tracking: tuple[TrackLine, ...] = ()
    tracking_month: str | None = None
    data_date: str | None = None
    days_left: int | None = None


def _cells(*values: str) -> str:
    return "".join(f"{value:>{_WIDTH}}" for value in values)


def _verdict(budget: Budget) -> str:
    target = format_ils(budget.target_surplus_agorot)
    if budget.meets_target:
        return f"meets the target of {target}"
    if budget.positive:
        return f"positive, but BELOW the target of {target}"
    return "NOT positive: the ceilings add up to more than the money available"


def render_budget(report: BudgetReport | None) -> str:
    """Render the budget, the month so far and the assumptions."""
    if report is None:
        return "No full month of bank and card data yet: nothing to build a budget from."
    b = report.budget
    state = f"saved, applies from {report.start_month}" if report.saved else "proposal, not saved"
    money = [("net income", b.income_agorot), ("received from people", b.received_agorot)]
    money += [(label, -amount) for label, amount in b.fixed]
    until = {name: last for name, last, _ in report.endings}
    money += [(f"{name} (until {until.get(name, '?')})", -amount) for name, amount in b.commitments]
    lines = [f"BUDGET for {b.month} ({state})"]
    lines += [f"  {format_ils(amount):>{_WIDTH}}  {label}" for label, amount in money]
    available = sum(amount for _, amount in money)
    lines.append(
        f"  {format_ils(available):>{_WIDTH}}  left for the measured buckets and the surplus"
    )
    lines.append("")
    lines.append("  " + _cells("baseline", "lean month", "ceiling", "cut") + "  bucket")
    for line in b.lines:
        lines.append(
            "  "
            + _cells(
                format_ils(line.baseline_agorot),
                format_ils(line.lean_agorot),
                format_ils(line.ceiling_agorot),
                format_ils(line.cut_agorot),
            )
            + f"  {line.bucket}"
        )
    lines.append(
        "  "
        + _cells(
            format_ils(sum(line.baseline_agorot for line in b.lines)),
            format_ils(sum(line.lean_agorot for line in b.lines)),
            format_ils(b.ceilings_agorot),
            format_ils(sum(line.cut_agorot for line in b.lines)),
        )
        + "  TOTAL"
    )
    lines.append("")
    lines.append(
        f"  Monthly cash flow with every bucket at its ceiling: {format_ils(b.cash_flow_agorot)}"
        f" ({_verdict(b)})."
    )
    for name, last, after in report.endings:
        amount = dict(b.commitments)[name]
        lines.append(
            f"  From {after} the {name} end (last payment {last}) and free"
            f" {format_ils(amount)} a month."
        )
    if not report.saved:
        lines.append("  To keep these ceilings, run: fin budget --save")
    lines.append("")
    if report.tracking and report.tracking_month:
        left = "" if report.days_left is None else f", {report.days_left} days left in the month"
        lines.append(
            f"THIS MONTH so far ({report.tracking_month}, data through {report.data_date}{left})"
        )
        lines.append("  " + _cells("spent", "ceiling", "remaining") + "  bucket")
        for item in report.tracking:
            over = "  OVER" if item.remaining_agorot < 0 else ""
            lines.append(
                "  "
                + _cells(
                    format_ils(item.spent_agorot),
                    format_ils(item.ceiling_agorot),
                    format_ils(item.remaining_agorot),
                )
                + f"  {item.bucket}{over}"
            )
        lines.append("")
    elif report.saved:
        lines.append(
            f"The budget starts in {report.start_month}; the data does not reach it yet,"
            " so there is nothing to track."
        )
        lines.append("")
    lines.append("ASSUMPTIONS")
    lines += [
        "  - Income and money received from people are the baseline means (see `fin baseline`);"
        " a month with lower pay leaves less than shown.",
        "  - A proposed ceiling is the same share of every bucket's baseline mean, rounded"
        " down to whole shekels. The lean month (the bucket's second-lowest month in the"
        " window) is shown for comparison only.",
        "  - Declared lines (rent, the reserve) and dated commitments are taken as given."
        " A commitment charged to a bucket is allowed on top of that bucket's ceiling when"
        " tracking the month.",
        "  - The reserve has no bucket of its own: an irregular expense shows up in a real"
        " bucket and may push it over its ceiling.",
        "  - Family support and investments are left out: the plan has to work without them.",
        "  - Decision support only, not licensed financial advice.",
    ]
    return "\n".join(lines)
