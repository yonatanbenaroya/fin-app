"""Plain-text rendering of the balance projection and goals. Formatting only, no math."""

from collections.abc import Sequence
from dataclasses import dataclass

from fin.logic import ALREADY, GoalStatus, ProjectedMonth, cash_flow_check, format_ils

_WIDTH = 14


@dataclass(frozen=True)
class GoalsReport:
    balance_date: str
    start_balance_agorot: int
    base_flow_agorot: int
    window_first_month: str
    window_last_month: str
    projection: tuple[ProjectedMonth, ...]
    statuses: tuple[GoalStatus, ...]
    overdraft_limit_agorot: int | None = None
    limit_breach_month: str | None = None
    # Set when the projection is a what-if scenario and not the plain baseline.
    scenario: str | None = None


def cash_flow_line(projection: Sequence[ProjectedMonth]) -> str:
    """One sentence on the rule that every month must end with a positive cash flow."""
    check = cash_flow_check(projection)
    if check.positive:
        return (
            f"positive in every month (lowest: {format_ils(check.worst_flow_agorot)}"
            f" in {check.worst_month})"
        )
    return (
        f"NOT positive in {check.failing_months} of {check.months} months (lowest:"
        f" {format_ils(check.worst_flow_agorot)} in {check.worst_month});"
        f" {format_ils(check.missing_agorot)} a month missing"
    )


def _need(amount_agorot: int, month: str) -> str:
    if amount_agorot == 0:
        return f"on track for {month}"
    return f"needs {format_ils(amount_agorot)} more cash flow every month to get there by {month}"


def _goal_lines(status: GoalStatus, last_month: str) -> list[str]:
    if status.reached == ALREADY:
        reached = "already covered"
    elif status.reached:
        reached = f"reached in {status.reached}"
    else:
        reached = f"not reached by {last_month}"
    lines = [f"  {status.name}: balance of {format_ils(status.threshold_agorot)}; {reached}"]
    if status.reached == ALREADY:
        return lines
    when = "target" if status.dated else "end of projection"
    lines.append(
        f"      {when} {status.target_month}: projected {format_ils(status.projected_agorot)};"
        f" {_need(status.required_monthly_agorot, status.target_month)}"
    )
    if status.minimum_threshold_agorot is not None:
        lines.append(
            f"      with the smaller amount (balance of"
            f" {format_ils(status.minimum_threshold_agorot)}):"
            f" {_need(status.minimum_required_monthly_agorot or 0, status.target_month)}"
        )
    return lines


def render_goals(report: GoalsReport | None) -> str:
    """Render the projection and the goals with the assumptions spelled out."""
    if report is None:
        return "No full month of bank data with a balance yet: nothing to project from."
    r = report
    last_month = r.projection[-1].month
    lines = [
        "GOALS: balance projection and progress"
        + (f' (what if: "{r.scenario}")' if r.scenario else ""),
        f"  bank balance after the last movement ({r.balance_date}):"
        f" {format_ils(r.start_balance_agorot)}",
        f"  baseline monthly cash flow, with money received: {format_ils(r.base_flow_agorot)}"
        f"  (window {r.window_first_month} to {r.window_last_month})",
        "",
        f"  {'month':>9}{'cash flow':>{_WIDTH}}{'balance':>{_WIDTH}}  notes",
    ]
    for month in r.projection:
        lines.append(
            f"  {month.month:>9}{format_ils(month.flow_agorot):>{_WIDTH}}"
            f"{format_ils(month.balance_agorot):>{_WIDTH}}  {'; '.join(month.notes)}".rstrip()
        )
    lines.append("")
    lines.append(f"  Monthly cash flow: {cash_flow_line(r.projection)}.")
    if r.overdraft_limit_agorot is not None:
        limit = format_ils(r.overdraft_limit_agorot)
        if r.limit_breach_month:
            lines.append(
                f"  The credit limit of {limit} is crossed in {r.limit_breach_month}."
                " Later months show where the trend leads, not what the bank would allow."
            )
        else:
            lines.append(f"  The credit limit of {limit} is not crossed by {last_month}.")
    lines.append("")
    if r.statuses:
        lines.append("GOALS in priority order (each one builds on the ones before it)")
        for status in r.statuses:
            lines.extend(_goal_lines(status, last_month))
    else:
        lines.append("No goals are defined yet (see config/goals.example.yaml).")
    lines.append("")
    lines.append("ASSUMPTIONS")
    if r.scenario:
        lines.append(
            f'  - This is the what-if scenario "{r.scenario}" (see `fin what-if`): what the'
            " projection would look like if its changes held. Not a forecast."
        )
    lines.extend(_assumptions(r.projection))
    return "\n".join(lines)


def _assumptions(projection: Sequence[ProjectedMonth]) -> list[str]:
    return [
        "  - Every month repeats the current baseline (see `fin baseline`), including the"
        " mean of money received from people (shared costs paid back).",
        "  - Family support and investments are left out: the plan has to work without them.",
        "  - Dated commitments are charged in their months; a part of them that is already"
        " inside the baseline window is not charged twice.",
        "  - Timeline events without an amount are shown as notes and change nothing.",
        f"  - The projection starts in {projection[0].month}, from the last known bank balance."
        " What is left of the month before it is not modeled.",
        "  - Interest on a growing overdraft is not added; interest at today's level is"
        " already part of the baseline.",
        "  - The plan has to keep the monthly cash flow positive: a month that ends at zero"
        " or below fails the rule, however small the gap.",
        '  - "More cash flow" means more income or less spending, every month from the first'
        " projected month.",
        "  - Decision support only, not licensed financial advice.",
    ]
