"""Plain-text rendering of the monthly summary. Formatting only, no math."""

from fin.logic import IncomeReference, MonthSummary, PeriodSummary, format_ils, mean_agorot
from fin.storage import ACTUAL

_WIDTH = 13
_MISSING = "-"


def _money(agorot: int | None) -> str:
    return _MISSING if agorot is None else format_ils(agorot)


def _row(spent: int | None, budget: int | None, remaining: int | None, label: str) -> str:
    cells = (_money(spent), _money(budget), _money(remaining))
    return "  " + "".join(f"{cell:>{_WIDTH}}" for cell in cells) + f"  {label}"


def _month_block(month: MonthSummary, actual: bool) -> list[str]:
    header = "  " + "".join(f"{name:>{_WIDTH}}" for name in ("spent", "budget", "remaining"))
    lines = [f"{month.month}  ({month.transactions} transactions)", header + "  bucket"]
    for line in month.buckets:
        lines.append(
            _row(line.spent_agorot, line.budget_agorot, line.remaining_agorot, line.bucket)
        )
    budget = month.budget_agorot
    remaining = None if budget is None else budget - month.spent_agorot
    lines.append(_row(month.spent_agorot, budget, remaining, "TOTAL"))
    if actual:
        lines.append(
            f"  income: {_money(month.net_income_agorot)}"
            f"   received from people: {_money(month.transfers_in_agorot)}"
            f"   cash flow: {_money(month.cash_flow_agorot)}"
        )
        if month.investments_agorot:
            lines.append(f"  investments (net, not counted): {_money(month.investments_agorot)}")
        if month.family_support_agorot:
            lines.append(f"  family support (not counted): {_money(month.family_support_agorot)}")
    else:
        lines.append(
            f"  net income: {_money(month.net_income_agorot)}"
            f"   cash flow: {_money(month.cash_flow_agorot)}"
        )
    return lines


def render_monthly_report(
    summary: PeriodSummary, income_reference: IncomeReference | None = None
) -> str:
    """Render the period summary with its assumptions spelled out.

    The income reference is shown only when no month of the period has its own
    net income figure, and is labeled with the period it actually covers.
    """
    if not summary.months:
        return "No transactions in the selected period."
    actual = summary.source == ACTUAL
    lines: list[str] = []
    for month in summary.months:
        lines.extend(_month_block(month, actual))
        lines.append("")
    count = len(summary.months)
    first, last = summary.months[0].month, summary.months[-1].month
    with_income = summary.months_with_income
    lines.append(f"AVERAGES over {count} months ({first} to {last})")
    lines.append(f"  mean monthly spend:      {_money(summary.mean_spent_agorot)}")
    lines.append(
        f"  mean net income:         {_money(summary.mean_net_income_agorot)}"
        f"  ({len(with_income)} months with income data)"
    )
    if actual:
        received = mean_agorot(sum(m.transfers_in_agorot for m in summary.months), count)
        lines.append(f"  mean received from people: {_money(received)}")
    lines.append(
        f"  mean cash flow:          {_money(summary.mean_cash_flow_agorot)}"
        f"  (same {len(with_income)} months)"
    )
    if not with_income and income_reference is not None:
        ref = income_reference
        lines.append(
            f"  reference net income:    {format_ils(ref.mean_net_agorot)}"
            f"  (mean of {ref.months} months, {ref.first_month} to {ref.last_month};"
            " a different period from the spending above)"
        )
    lines.append("  mean monthly spend per bucket:")
    for bucket, mean in summary.bucket_means:
        lines.append(f"    {format_ils(mean):>{_WIDTH}}  {bucket}")
    lines.append("")
    lines.append("ASSUMPTIONS")
    lines.extend(_actual_assumptions(summary) if actual else _ledger_assumptions(summary))
    lines.append("  - Every listed month counts equally in the averages, including partial months.")
    lines.append("  - Decision support only, not licensed financial advice.")
    return "\n".join(lines)


def _actual_assumptions(summary: PeriodSummary) -> list[str]:
    lines = [
        "  - Source: actual = bank and card ledgers together. A card bill whose detail is in"
        " a card ledger is not counted again.",
        "  - Card purchases count in the month of purchase (installments when billed);"
        " bank movements count in the month they happen.",
        "  - Spend is the full amount charged. Money received from people is shown"
        " separately and is not netted against any category.",
        "  - Cash flow = income + received from people - spend. Investments and family"
        " support are left out: the plan has to work without them.",
        "  - The first and last month may be partial, depending on the export dates.",
    ]
    uncategorized = sum(m.uncategorized for m in summary.months)
    if uncategorized:
        lines.append(f"  - {uncategorized} transactions are not categorized yet.")
    estimated = sum(m.estimated for m in summary.months)
    if estimated:
        lines.append(
            f"  - {estimated} transactions are categorized by an estimate rule, not a known fact."
        )
    unmatched = sum(m.unmatched_card_payments for m in summary.months)
    if unmatched:
        lines.append(
            f"  - {unmatched} card bills have no matching card detail and count as spending"
            " without a breakdown."
        )
    return lines


def _ledger_assumptions(summary: PeriodSummary) -> list[str]:
    lines = []
    if summary.source:
        lines.append(
            f"  - Source: {summary.source} only. Other sources are not mixed in,"
            " to avoid double counting."
        )
    lines.append("  - Spend is my share of each expense, not the full amount charged.")
    lines.append("  - A month is the budget period a row was filed under, not the calendar month.")
    quarantined = [(m.month, m.quarantined) for m in summary.months if m.quarantined]
    if quarantined:
        detail = ", ".join(f"{month}: {count}" for month, count in quarantined)
        lines.append(f"  - Quarantined rows are excluded from all sums ({detail}).")
    missing_income = [m.month for m in summary.months if m.net_income_agorot is None]
    if missing_income:
        lines.append(f"  - No net income recorded for: {', '.join(missing_income)}.")
    return lines
