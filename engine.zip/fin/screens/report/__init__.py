"""Reports built on numbers computed in code."""
