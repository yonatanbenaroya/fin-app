"""Plain-text rendering of the current-state baseline. Formatting only, no math."""

from fin.logic import DECLARED, RESERVE_LINE, Baseline, format_ils

_WIDTH = 13


def _cells(*values: str) -> str:
    return "".join(f"{value:>{_WIDTH}}" for value in values)


def render_baseline(baseline: Baseline | None) -> str:
    """Render the baseline with its assumptions spelled out."""
    if baseline is None:
        return "No full month of bank and card data yet: nothing to build a baseline from."
    b = baseline
    lines = [
        "CURRENT BASELINE: a typical month from now on",
        f"  window: {b.months} full months ({b.first_month} to {b.last_month})",
        "",
        "  " + _cells("baseline", "basis", "window mean", "last month"),
        "  "
        + _cells(
            format_ils(b.income_agorot),
            b.income_basis,
            format_ils(b.income_window_mean_agorot),
            format_ils(b.income_last_month_agorot),
        )
        + "  net income",
        "  " + _cells(format_ils(b.received_agorot), "mean", "", "") + "  received from people",
        "",
    ]
    for line in b.lines:
        lines.append(
            "  "
            + _cells(
                format_ils(line.amount_agorot),
                line.basis,
                format_ils(line.window_mean_agorot),
                format_ils(line.last_month_agorot),
            )
            + f"  {line.bucket}"
        )
    lines.append("  " + _cells(format_ils(b.spend_agorot), "", "", "") + "  TOTAL spend")
    lines.append("")
    lines.append(f"  monthly cash flow:                      {format_ils(b.cash_flow_agorot)}")
    lines.append(
        "  monthly cash flow without money received:"
        f" {format_ils(b.cash_flow_without_received_agorot)}"
    )
    if b.one_offs:
        lines.append("")
        lines.append("  one-time expenses left out of the window mean:")
        for item in b.one_offs:
            note = f"  ({item.note})" if item.note else ""
            lines.append(
                f"    {item.month}  {format_ils(item.amount_agorot):>{_WIDTH}}  {item.bucket}{note}"
            )
    lines.append("")
    lines.append("ASSUMPTIONS")
    declared = [line.bucket for line in b.lines if line.basis == DECLARED]
    if b.income_basis == DECLARED:
        declared.insert(0, "net income")
    if declared:
        lines.append(
            f"  - Declared by you, not measured: {', '.join(declared)}."
            " The measured figures are shown beside them."
        )
    else:
        lines.append("  - Nothing is declared: every figure is the mean of the window.")
    lines.append(
        "  - Every other bucket is its mean over the window. The month of the newest"
        " transaction is treated as partial and left out."
    )
    lines.append(
        "  - Money received from people is a mean of the past, not a promise; the second"
        " cash flow line leaves it out."
    )
    lines.append(
        "  - Investments and family support are left out: the plan has to work without them."
    )
    if any(line.bucket == RESERVE_LINE for line in b.lines):
        lines.append(
            "  - One-time expenses are left out of the means; the declared reserve stands in"
            " for irregular costs of that kind (a move, a trip, repairs, annual fees)."
        )
    else:
        lines.append(
            "  - Irregular costs that did not happen in the window (annual fees, repairs,"
            " trips) are not in the baseline, and no reserve is declared for them."
        )
    lines.append("  - Decision support only, not licensed financial advice.")
    return "\n".join(lines)
