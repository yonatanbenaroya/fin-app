"""Plain-text comparison of what-if scenarios. Formatting only, no math."""

from collections.abc import Sequence

from fin.logic import ALREADY, GoalStatus, ResolvedScenario, format_ils
from fin.screens.report.goals_text import GoalsReport, cash_flow_line

BASELINE_NAME = "current baseline"


def _signed(agorot: int) -> str:
    return ("+" if agorot >= 0 else "-") + format_ils(abs(agorot))


def _goal(status: GoalStatus, last_month: str) -> str:
    target = f" (by {status.target_month})" if status.dated else ""
    if status.reached == ALREADY:
        state = "already covered"
    elif status.dated and status.required_monthly_agorot == 0:
        state = "on track"
    elif status.reached and not status.dated:
        state = f"reached in {status.reached}"
    else:
        state = f"{format_ils(status.required_monthly_agorot)} a month still missing"
        if not status.dated:
            state = f"not reached by {last_month}; {state}"
    smaller = status.minimum_required_monthly_agorot
    if smaller is not None and status.reached != ALREADY and status.required_monthly_agorot:
        state += f"  [smaller amount: {format_ils(smaller)}]"
    return f"      {status.name}{target}: {state}"


def _block(name: str, report: GoalsReport) -> list[str]:
    last = report.projection[-1]
    if report.overdraft_limit_agorot is None:
        limit = ""
    elif report.limit_breach_month:
        limit = f"   credit limit: crossed in {report.limit_breach_month}"
    else:
        limit = "   credit limit: not crossed"
    lines = [
        f"  {name}",
        f"      first month cash flow: {format_ils(report.projection[0].flow_agorot)}"
        f"   balance in {last.month}: {format_ils(last.balance_agorot)}{limit}",
    ]
    lines.append(f"      monthly cash flow: {cash_flow_line(report.projection)}")
    lines.extend(_goal(status, last.month) for status in report.statuses)
    return lines


def render_scenarios(
    base: GoalsReport | None, scenarios: Sequence[tuple[ResolvedScenario, GoalsReport]]
) -> str:
    """Render every scenario next to the current baseline, with the assumptions."""
    if base is None:
        return "No full month of bank data with a balance yet: nothing to project from."
    first, last = base.projection[0], base.projection[-1]
    lines = [
        "WHAT IF: scenarios against the current baseline",
        f"  projection {first.month} to {last.month}, from a bank balance of"
        f" {format_ils(base.start_balance_agorot)} ({base.balance_date})",
    ]
    if first.flow_agorot < 0:
        lines.append(
            "  To stop the balance from falling, the monthly cash flow has to improve by"
            f" {format_ils(-first.flow_agorot)}."
        )
    lines.append("")
    lines.extend(_block(BASELINE_NAME, base))
    for scenario, report in scenarios:
        lines.append("")
        lines.extend(_block(scenario.name, report))
        change = report.projection[0].flow_agorot - first.flow_agorot
        lines.append(f"      change in the first month: {_signed(change)}")
        for item in scenario.adjustments:
            span = ""
            if item.first_month or item.last_month:
                span = f"  ({item.first_month or 'start'} to {item.last_month or 'end'})"
            lines.append(f"        {_signed(item.monthly_agorot):>12} a month  {item.label}{span}")
        for event in scenario.events:
            lines.append(
                f"        {_signed(event.amount_agorot or 0):>12} once     {event.label}"
                f"  ({event.month})"
            )
    if not scenarios:
        lines.append("")
        lines.append("No scenarios are defined (see config/scenarios.yaml).")
    lines.append("")
    lines.append("ASSUMPTIONS")
    lines.extend(
        [
            "  - A scenario shows what the projection would look like if its changes held"
            " every month. It is not a forecast and not a recommendation.",
            '  - "median" and "second_lowest" are levels each bucket really had in the baseline'
            " window. A scenario applies them to all buckets at once, which no single past"
            " month necessarily did.",
            "  - The plan has to keep the monthly cash flow positive; a scenario that ends"
            " any month at zero or below fails that rule, however small the gap.",
            "  - Declared buckets (such as rent) change only when a scenario sets them explicitly.",
            "  - Everything else is as in `fin goals`: money received from people is counted"
            " unless the scenario drops it; no family support, no interest on a growing"
            " overdraft.",
            "  - Decision support only, not licensed financial advice.",
        ]
    )
    return "\n".join(lines)
