"""Automatic sync while `fin web` runs: at start, every few minutes, after an import.

It runs rounds of the account's log in a background thread and keeps a status
for the Settings screen: when the last round ran, how many transactions and
settings changes came in, and an error code. No content is kept or printed.
"""

import threading
from datetime import UTC, datetime
from typing import Any

from fin.sync import Account, describe

INTERVAL_SECONDS = 300


class Syncer:
    def __init__(self, account: Account, interval: float = INTERVAL_SECONDS) -> None:
        self.account = account
        self.interval = interval
        self._wake = threading.Event()
        self._stop = threading.Event()
        state = account.state()
        self._status: dict[str, Any] = {
            "last_sync": state.get("last_sync"),
            "received": state.get("last_transactions", 0),
            "changes": state.get("last_changes", 0),
            "sent": False,
            "error": None,
            "running": False,
        }

    def status(self) -> dict[str, Any]:
        return {"configured": True, "signed_in": self.account.signed_in(), **self._status}

    def run_now(self) -> dict[str, Any]:
        """One round now (waits for a round already running), then the status."""
        if self.account.signed_in():
            self._status["running"] = True
            try:
                result = self.account.sync()
                self._status.update(
                    last_sync=result.at,
                    received=result.transactions,
                    changes=result.changes,
                    sent=result.sent,
                    error=None,
                )
            except Exception as exc:  # noqa: BLE001 - reported as a code, never as text
                self._status.update(error=describe(exc), attempted=_now())
            finally:
                self._status["running"] = False
        return self.status()

    def nudge(self) -> None:
        """Ask the background thread for a round soon (after an import)."""
        self._wake.set()

    def start(self) -> threading.Thread:
        def loop() -> None:
            while not self._stop.is_set():
                self.run_now()
                self._wake.wait(self.interval)
                self._wake.clear()

        thread = threading.Thread(target=loop, name="fin-sync", daemon=True)
        thread.start()
        return thread

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")
