"""The screens box: the command line and the text reports (and later the web app).

It may use the logic, storage and sync boxes through their doors. It never opens the
database or runs SQL. Nothing imports from it.
"""

from fin.screens.cli import main

__all__ = [
    "main",
]
